/* ============================================================================
   NexZap PRO v5.0 — Controlador Operacional Frontend
   - Motor de Reestruturacao Semantica de Alto Nivel + Auditoria de Coesao e Coerencia IA
   - Previa Rica de Links (OpenGraph Card do WhatsApp) no Painel e no Disparo Real
   - Sistema de Login, Senha e Autorizacao pelo Administrador (Gabriel)
   - PIX Recorrente Gratuito (Padrao Oficial EMVCo Banco Central — 0% Taxa)
============================================================================ */

let appData = {
  chips: [],
  contacts: [],
  campaigns: [],
  autoreply_flows: [],
  recent_logs: [],
  autoreply_logs: [],
  warmup_logs: [],
  users: [],
  pix_config: {},
  warmup_state: { is_running: false, status_text: "Aquecedor em espera" },
  queue_state: { status_text: "Pronto" }
};

let activeVarIdx = 0;
let activeGroupVarIdx = 0;
let selectedChipIds = new Set([1]);
let qrModalTimer = null;
let qrActiveChipId = null;
let autoReplyStepsDraft = [];
let autoReplyInitialized = false;
let pixConfigInitialized = false;

let variationsState = Array(15).fill("");
let groupVariationsState = Array(15).fill("");
let linkMetaCache = {};

const VARIATION_STYLE_LABELS = [
  "V1 — Original Lapidado (Fidelidade Total)",
  "V2 — Executivo Consultivo",
  "V3 — Cordialidade Estrategica",
  "V4 — Direto ao Ponto e Objetivo",
  "V5 — Abordagem Empatica e Humana",
  "V6 — Relacionamento VIP",
  "V7 — Conexao Rapida e Fluida",
  "V8 — Proposta de Valor Clara",
  "V9 — Parceria e Proximidade",
  "V10 — Convite Exclusivo",
  "V11 — Dinamico e Moderno",
  "V12 — Formalidade Elegante",
  "V13 — Conversacional Natural",
  "V14 — Foco em Oportunidade",
  "V15 — Sintese Executiva de Alto Impacto"
];

function deduplicateClientVariablesAndGreetings(rawText) {
  if (!rawText) return "";
  let s = String(rawText);

  // 1. Manter no maximo 1 ocorrencia de {{saudacao_horario}} / {{saudacao}} em toda a mensagem
  const saudRegex = /\{\{\s*saudacao(?:[ _]horario)?\s*\}\}/gi;
  let saudCount = 0;
  s = s.replace(saudRegex, (match) => {
    saudCount++;
    return saudCount === 1 ? match : "";
  });

  // 2. Se a primeira linha ja possui {{saudacao_horario}}, remover "Bom dia / Boa tarde / Boa noite" literal duplicado na abertura
  const nlIdx = s.indexOf("\n");
  let firstLine = nlIdx >= 0 ? s.slice(0, nlIdx) : s;
  const restLines = nlIdx >= 0 ? s.slice(nlIdx) : "";
  if (/\{\{\s*saudacao(?:[ _]horario)?\s*\}\}/i.test(firstLine)) {
    firstLine = firstLine.replace(/[,;.!?\s]*\b(bom dia|boa tarde|boa noite)\b[!?.]*/gi, "");
  }

  // 3. Evitar dois "Bom dia / Boa tarde / Boa noite" literais na mesma linha de abertura
  firstLine = firstLine.replace(
    /^([^\n]*?\b(?:bom dia|boa tarde|boa noite)\b[^\n]{0,80}?)[,;.!?\s]+\b(?:bom dia|boa tarde|boa noite)\b[!?.]*/i,
    "$1"
  );

  // 4. Evitar duplicacao de {{primeiro nome}} / {{nome}} na mesma linha de abertura
  let nameCount = 0;
  firstLine = firstLine.replace(/\{\{\s*(?:primeiro[ _]nome|nome)\s*\}\}/gi, (match) => {
    nameCount++;
    return nameCount === 1 ? match : "";
  });

  s = firstLine.trim() + restLines;
  return s;
}

function enforceClientCohesionAndCoherence(rawText) {
  if (!rawText) return "";
  let s = deduplicateClientVariablesAndGreetings(String(rawText).trim());
  s = s.replace(/[ \t]+/g, " ");
  s = s.replace(/,\s*,+/g, ",");
  s = s.replace(/,\s*([!?.])/g, "$1");
  s = s.replace(/([!?.]){2,}/g, "$1");
  s = s.replace(/\.\s*,/g, ".");
  s = s.replace(/\s+([,.;:!?])/g, "$1");
  s = s.replace(/([,!?])([A-Za-zÀ-ÿ\{])/g, "$1 $2");
  s = s.replace(/\b(\w+)\s+\1\b/gi, "$1");
  s = s.replace(/(^|[\n.!?]\s+)([a-zà-ÿ])/g, (m, p1, p2) => p1 + p2.toUpperCase());
  s = s.replace(/\n{3,}/g, "\n\n");
  return s.trim();
}

function buildClientSide15Variations(baseText) {
  const clean = enforceClientCohesionAndCoherence(baseText || "");
  if (!clean) return Array(15).fill("");

  const hasFirstNameInGreeting = /^(oi|olá|ola|opa|bom dia|boa tarde|boa noite|\{\{saudacao[^\}]*\}\})[^\n.!?]{0,30}\{(\{primeiro[ _]nome\}|\{nome\})\}/i.test(clean);

  const openingsWithName = [
    "Oi, {{primeiro nome}}, tudo bem?",
    "Olá, {{primeiro nome}}! Tudo certo com você?",
    "{{saudacao_horario}}, {{primeiro nome}}! Como você está?",
    "Olá, {{primeiro nome}}, espero que esteja tudo ótimo por aí!",
    "Oi, {{primeiro nome}}! Tudo tranquilo?",
    "{{saudacao_horario}}, {{primeiro nome}}, tudo bem por aí?",
    "Opa, {{primeiro nome}}, tudo joia com você?",
    "Olá, {{primeiro nome}}! Espero que seu dia esteja excelente.",
    "Oi, {{primeiro nome}}, como vão as coisas?",
    "{{saudacao_horario}}, {{primeiro nome}}! Tudo certo?",
    "Olá, {{primeiro nome}}, tudo bem com você?",
    "Oi, {{primeiro nome}}! Passando para falar com você.",
    "{{saudacao_horario}}, {{primeiro nome}}, espero que esteja bem!",
    "Olá, {{primeiro nome}}, como estão as coisas por aí?",
    "Oi, {{primeiro nome}}! Tudo em ordem por aí?"
  ];

  const openingsPlain = [
    "Oi, tudo bem?",
    "Olá! Tudo certo com você?",
    "{{saudacao_horario}}! Como você está?",
    "Olá, espero que esteja tudo ótimo por aí!",
    "Oi! Tudo tranquilo por aí?",
    "{{saudacao_horario}}, tudo bem?",
    "Opa, tudo joia com você?",
    "Olá! Espero que seu dia esteja excelente.",
    "Oi, como vão as coisas?",
    "{{saudacao_horario}}! Tudo certo?",
    "Olá, tudo bem com você?",
    "Oi! Passando para falar com você.",
    "{{saudacao_horario}}, espero que esteja bem!",
    "Olá, como estão as coisas por aí?",
    "Oi! Tudo em ordem por aí?"
  ];

  const chipIntros = [
    "Me chamo {{nome do chip}}",
    "Aqui quem fala é {{nome do chip}}",
    "Sou {{nome do chip}}",
    "Quem fala aqui com você é {{nome do chip}}",
    "Aqui é {{nome do chip}}",
    "Meu nome é {{nome do chip}}",
    "{{nome do chip}} falando por aqui",
    "Sou {{nome do chip}}, tudo certo?",
    "Aqui é {{nome do chip}}, prazer em falar com você",
    "Me chamo {{nome do chip}} e estou entrando em contato direto",
    "Quem te escreve aqui é {{nome do chip}}",
    "Aqui quem fala é {{nome do chip}}, tudo bem?",
    "Sou {{nome do chip}}, passando para conversar com você",
    "Me chamo {{nome do chip}}, falando diretamente aqui pelo WhatsApp",
    "Aqui é {{nome do chip}}"
  ];

  const discourseSwaps = [
    [
      /\b(estou entrando em contato|entro em contato|passando por aqui|vim falar com você|vim falar com voce)\b/i,
      [
        "estou entrando em contato",
        "resolvi te escrever diretamente",
        "estou passando por aqui",
        "faço este contato rápido",
        "tomo a liberdade de te enviar esta mensagem",
        "escrevo para você hoje",
        "estou te chamando aqui",
        "passo por aqui rapidamente",
        "envio este contato direto",
        "decidi falar diretamente com você"
      ]
    ],
    [
      /\b(vi que|notei que|reparei que|percebi que)\b/i,
      ["notei que", "identifiquei que", "percebi que", "observei que", "reparei que", "vi aqui que", "constatei que"]
    ],
    [
      /\b(estamos juntos no grupo|está no grupo|esta no grupo|participa do grupo|faz parte do grupo|no mesmo grupo)\b/i,
      [
        "fazemos parte do mesmo grupo",
        "acompanhamos o mesmo grupo",
        "participamos juntos do grupo",
        "estamos conectados lá no grupo",
        "compartilhamos o mesmo grupo",
        "vi sua participação lá no grupo"
      ]
    ],
    [
      /\b(queria|gostaria de|quero|preciso)\s+(falar|conversar)\s+com\s+(você|voce)\b/i,
      [
        "gostaria muito de conversar com você",
        "queria trocar uma ideia rápida com você",
        "fiz questão de falar diretamente com você",
        "quero conversar brevemente com você",
        "gostaria de alinhar alguns pontos com você",
        "resolvi falar diretamente com você",
        "tenho interesse em dialogar com você",
        "queria bater um papo objetivo com você"
      ]
    ],
    [
      /\b(queria|gostaria de|quero|preciso)\s+(mostrar|apresentar|compartilhar|enviar|mandar)\b/i,
      [
        "gostaria muito de apresentar",
        "queria compartilhar",
        "fiz questão de trazer",
        "separei para mostrar",
        "quero dividir",
        "preparei para apresentar",
        "resolvi compartilhar",
        "queria mostrar em primeira mão"
      ]
    ],
    [
      /\b(falar com você|falar com voce|conversar com você|conversar com voce|bater um papo|trocar uma ideia)\b/i,
      [
        "conversar com você",
        "trocar uma ideia rápida com você",
        "alinhar alguns pontos com você",
        "dialogar rapidamente com você",
        "falar diretamente com você",
        "bater um papo objetivo com você"
      ]
    ],
    [
      /\b(condição especial|condicao especial|oferta especial|oportunidade|novidade|proposta|benefício|beneficio)\b/i,
      [
        "condição exclusiva",
        "oportunidade diferenciada",
        "proposta personalizada",
        "vantagem estratégica",
        "condição preparada especialmente",
        "oportunidade de alto valor",
        "novidade exclusiva"
      ]
    ],
    [
      /\b(podemos conversar|consegue falar|tem um tempinho|pode falar|me avisa|fico no aguardo)\b/i,
      [
        "conseguimos conversar rapidamente por aqui",
        "teria alguns instantes para alinharmos",
        "quando puder visualizar, me dê um retorno por aqui",
        "fico à inteira disposição para conversarmos",
        "assim que tiver um momento, me avise por gentileza",
        "podemos trocar uma ideia rápida hoje"
      ]
    ]
  ];

  const connectors = [
    "",
    "Pensando nisso, ",
    "Por esse motivo, ",
    "Inclusive, ",
    "Com esse objetivo, ",
    "Nesse sentido, ",
    "Diante disso, ",
    "Especialmente para você, ",
    "De forma bem objetiva, ",
    "Sendo assim, ",
    "Para facilitar sua análise, ",
    "Valorizando o seu tempo, ",
    "De maneira direta e transparente, ",
    "Buscando agregar valor ao seu dia a dia, ",
    "Com foco no que realmente importa, "
  ];

  const closings = [
    "",
    "\n\nFico à disposição caso queira tirar qualquer dúvida por aqui.",
    "\n\nQuando conseguir visualizar, me dê um breve retorno!",
    "\n\nSerá um prazer conversarmos a respeito. Me avise o que achou!",
    "\n\nSe fizer sentido para você, podemos alinhar os próximos passos por aqui.",
    "\n\nQualquer dúvida, estou acompanhando pessoalmente por este número.",
    "\n\nAssim que tiver um minutinho, me dê um alô para conversarmos.",
    "\n\nAguardo seu retorno quando for mais conveniente para você.",
    "\n\nSe preferir, basta me responder diretamente nesta conversa!",
    "\n\nConte comigo no que precisar. Fico no aguardo do seu feedback!",
    "\n\nMe avise assim que conseguir conferir os detalhes!",
    "\n\nEstou online por aqui caso queira trocar uma ideia rápida.",
    "\n\nFico atento ao seu retorno. Um excelente dia para você!",
    "\n\nDê uma olhada com calma e me diga como posso te ajudar.",
    "\n\nPodemos conversar rapidinho sobre isso hoje?"
  ];

  const linkCallouts = [
    "Confira diretamente na prévia abaixo:",
    "Acesse os detalhes completos pelo link oficial:",
    "Deixei o acesso completo disponível aqui para você:",
    "Veja a apresentação diretamente neste link:",
    "Toque no cartão do link abaixo para abrir:",
    "Disponibilizei todos os detalhes neste endereço:"
  ];

  const out = [clean];
  const openingRegex = /^(?:oi|olá|ola|opa|bom dia|boa tarde|boa noite|\{\{saudacao[^\}]*\}\})(?:[\s,!.]*(?:oi|olá|ola|opa|bom dia|boa tarde|boa noite|\{\{saudacao[^\}]*\}\}|\{\{(?:primeiro[ _]nome|nome)\}\}))*(?:\s*[,!.]?\s*(?:tudo\s+(?:bem|certo|bom|joia|tranquilo|ótimo|otimo|em ordem)(?:\s+por\s+aí|\s+com\s+você)?|como\s+vai|como\s+você\s+está|como\s+estão\s+as\s+coisas)\s*\??)?(?:[\s,!.]*(?:bom dia|boa tarde|boa noite|\{\{saudacao[^\}]*\}\})[!?.]*)?/i;
  const introRegex = /(?:me chamo|meu nome é|aqui é|aqui e|aqui quem fala é|sou o|sou a|sou|quem fala aqui é)\s+\{\{nome[ _]do[ _]chip\}\}/i;

  for (let i = 1; i < 15; i++) {
    let txt = clean;

    if (openingRegex.test(txt)) {
      const chosenOpen = hasFirstNameInGreeting ? openingsWithName[i % openingsWithName.length] : openingsPlain[i % openingsPlain.length];
      txt = txt.replace(openingRegex, chosenOpen);
    }

    if (introRegex.test(txt)) {
      txt = txt.replace(introRegex, chipIntros[i % chipIntros.length]);
    }

    discourseSwaps.forEach(([regex, opts], sIdx) => {
      if (regex.test(txt)) {
        txt = txt.replace(regex, opts[(i + sIdx) % opts.length]);
      }
    });

    if (/(\{\{link(?:_unico| unico)?\}\}|https?:\/\/\S+)/i.test(txt) && i % 2 === 0) {
      const callout = linkCallouts[i % linkCallouts.length];
      if (!txt.toLowerCase().includes(callout.toLowerCase())) {
        txt = txt.replace(/\s*(\{\{link(?:_unico| unico)?\}\}|https?:\/\/\S+)/i, `\n\n${callout}\n$1`);
      }
    }

    const paragraphs = txt.split("\n\n").map(p => p.trim()).filter(Boolean);
    if (paragraphs.length >= 2) {
      const conn = connectors[i % connectors.length];
      const p1 = paragraphs[1];
      if (conn && !/^(\{\{link|https?:\/\/|me chamo|aqui|sou|oi|olá)/i.test(p1)) {
        paragraphs[1] = conn + p1.charAt(0).toLowerCase() + p1.slice(1);
        txt = paragraphs.join("\n\n");
      }
    }

    txt = enforceClientCohesionAndCoherence(txt);
    if (out.includes(txt)) {
      const end = closings[i % closings.length];
      if (end && !txt.toLowerCase().includes(end.trim().toLowerCase())) {
        txt = enforceClientCohesionAndCoherence(txt + end);
      }
      if (out.includes(txt)) {
        const pref = connectors[(i + 3) % connectors.length];
        if (pref) {
          txt = enforceClientCohesionAndCoherence(pref + txt.charAt(0).toLowerCase() + txt.slice(1));
        }
      }
    }
    out.push(txt);
  }
  return out;
}

document.addEventListener("DOMContentLoaded", () => {
  checkAuthSession();
  build15VariationTabs();
  buildGroup15VariationTabs();
  const editor = document.getElementById("msg-editor");
  if (editor) editor.value = "";
  const grpEditor = document.getElementById("group-dispatch-message");
  if (grpEditor) grpEditor.value = "";
  fetchOverview();
  setInterval(fetchOverview, 1800);
});

function build15VariationTabs() {
  const container = document.getElementById("var-tabs-container");
  if (!container) return;
  container.innerHTML = "";
  for (let i = 0; i < 15; i++) {
    const btn = document.createElement("button");
    btn.className = "var-tab" + (i === activeVarIdx ? " active" : "");
    btn.textContent = `V${i + 1}`;
    btn.onclick = () => selectVarTab(i, btn);
    container.appendChild(btn);
  }
}

function buildGroup15VariationTabs() {
  const container = document.getElementById("group-var-tabs-container");
  if (!container) return;
  container.innerHTML = "";
  for (let i = 0; i < 15; i++) {
    const btn = document.createElement("button");
    btn.className = "var-tab group-var-tab" + (i === activeGroupVarIdx ? " active" : "");
    btn.textContent = `V${i + 1}`;
    btn.onclick = () => selectGroupVarTab(i, btn);
    container.appendChild(btn);
  }
}

function showToast(msg) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.style.display = "block";
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => {
    t.style.display = "none";
  }, 3600);
}

function switchTab(tabId, btn) {
  document.querySelectorAll(".tab-view").forEach(el => el.classList.remove("active"));
  document.querySelectorAll(".side-nav-link").forEach(el => el.classList.remove("active"));
  const target = document.getElementById(tabId);
  if (target) target.classList.add("active");
  if (btn) btn.classList.add("active");
}

function toggleSidebar() {
  const sb = document.getElementById("app-sidebar");
  const icon = document.getElementById("sidebar-toggle-icon");
  if (!sb) return;
  const isCollapsed = sb.classList.toggle("collapsed");
  if (icon) {
    icon.innerHTML = isCollapsed
      ? '<polyline points="9 18 15 12 9 6"></polyline>'
      : '<polyline points="15 18 9 12 15 6"></polyline>';
  }
}

function downloadPortableInstaller(includeDb = true) {
  const flag = includeDb ? "1" : "0";
  showToast("Gerando pacote instalador portatil (.ZIP) para outras maquinas...");
  window.location.href = `/api/system/export-installer?include_db=${flag}`;
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const _domHtmlCache = {};

function updateHtmlPreservingScrollAndFocus(elOrId, newHtml) {
  const el = typeof elOrId === "string" ? document.getElementById(elOrId) : elOrId;
  if (!el) return false;

  // Se o usuario estiver com o cursor/foco digitando ou selecionando dentro deste container, NAO recriar o DOM!
  const active = document.activeElement;
  if (active && el.contains(active) && active !== document.body && /^(INPUT|TEXTAREA|SELECT)$/i.test(active.tagName)) {
    return false;
  }

  const cacheKey = el.id || "";
  if (cacheKey && _domHtmlCache[cacheKey] === newHtml) {
    return false;
  }
  if (cacheKey) {
    _domHtmlCache[cacheKey] = newHtml;
  }

  const scrollParent = el.closest(".table-scroll, .sent-feed, .wa-chat-list-scroll, .wa-messages-stream") || el;
  const prevTop = scrollParent ? scrollParent.scrollTop : 0;
  const prevElTop = el.scrollTop || 0;

  el.innerHTML = newHtml;

  if (scrollParent) scrollParent.scrollTop = prevTop;
  if (el !== scrollParent) el.scrollTop = prevElTop;
  return true;
}

function getCurrentLoggedUserObj() {
  try {
    const raw = localStorage.getItem("nexzap_auth_user");
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return null;
}

function renderTemplateClientSide(template, contact, overrideLink = "") {
  // REGRA INVARIAVEL: Se o Nome Social estiver preenchido, respeitar invariavelmente o Nome Social!
  let rawFullName = (contact && (contact.social_name || contact.name)) ? String(contact.social_name || contact.name).trim() : "";
  if (/^(membro|cliente|sem nome|contato)\b/i.test(rawFullName)) {
    rawFullName = "";
  }
  const firstName = rawFullName ? rawFullName.split(" ")[0] : "";
  const company = (contact && contact.company) ? contact.company : (contact && contact.group_name ? contact.group_name : "");
  const city = (contact && contact.city) ? contact.city : "";
  const role = (contact && contact.role) ? contact.role : "";
  const custom1 = (contact && contact.custom1) ? contact.custom1 : "";
  let campLink = (overrideLink || document.getElementById("camp-link")?.value || "").trim();
  if (campLink && !/^https?:\/\//i.test(campLink)) {
    campLink = "https://" + campLink;
  }
  const campOffer = (document.getElementById("camp-offer")?.value || custom1 || "").trim();

  let activeChipName = (contact && contact.assigned_chip_name) ? contact.assigned_chip_name : "";
  if (!activeChipName && appData.chips && appData.chips.length > 0) {
    const firstSelected = appData.chips.find(ch => selectedChipIds.has(ch.id)) || appData.chips[0];
    activeChipName = firstSelected ? firstSelected.name : "Gabriel";
  }
  if (!activeChipName) activeChipName = "Gabriel";

  let uniqueLink = "";
  if (campLink) {
    uniqueLink = `${campLink}#atendimento-${encodeURIComponent((firstName || "vip").toLowerCase())}`;
  }

  const hr = new Date().getHours();
  const greeting = hr < 12 ? "Bom dia" : (hr < 18 ? "Boa tarde" : "Boa noite");

  let rendered = (template || "")
    .replace(/\{\{primeiro_nome\}\}/gi, firstName)
    .replace(/\{\{primeiro nome\}\}/gi, firstName)
    .replace(/\{\{nome_do_chip\}\}/gi, activeChipName)
    .replace(/\{\{nome do chip\}\}/gi, activeChipName)
    .replace(/\{\{chip\}\}/gi, activeChipName)
    .replace(/\{\{atendente\}\}/gi, activeChipName)
    .replace(/\{\{nome\}\}/gi, rawFullName)
    .replace(/\{\{empresa\}\}/gi, company)
    .replace(/\{\{cidade\}\}/gi, city)
    .replace(/\{\{cargo\}\}/gi, role)
    .replace(/\{\{produto\}\}/gi, custom1 || campOffer)
    .replace(/\{\{custom1\}\}/gi, custom1 || campOffer)
    .replace(/\{\{link\}\}/gi, campLink)
    .replace(/\{\{link_unico\}\}/gi, uniqueLink)
    .replace(/\{\{link unico\}\}/gi, uniqueLink)
    .replace(/\{\{saudacao_horario\}\}/gi, greeting)
    .replace(/\{\{saudacao horario\}\}/gi, greeting)
    .replace(/\{\{saudacao\}\}/gi, greeting.toLowerCase());

  if (campLink && !rendered.includes(campLink) && !rendered.includes(uniqueLink) && !/https?:\/\/\S+/i.test(rendered)) {
    rendered = `${rendered.trim()}\n\nAcesse os detalhes completos aqui:\n${campLink}`;
  }

  rendered = rendered.replace(/,\s*,/g, ",");
  rendered = rendered.replace(/\b(Oi|Olá|Ola|Opa|Bom dia|Boa tarde|Boa noite)\s*,\s*([!?.])/gi, "$1$2");
  rendered = rendered.replace(/\s+([,!?.;:])/g, "$1");
  // Eliminar qualquer saudacao de horario duplicada apos renderizacao (ex: "Boa noite, Paulo, tudo bem? Boa noite")
  rendered = rendered.replace(
    /^(\s*(?:Bom dia|Boa tarde|Boa noite)\b[^\n]{0,90}?)[,;.!?\s]+\b(?:Bom dia|Boa tarde|Boa noite)\b[!?.]*/i,
    "$1"
  );
  return rendered.trim();
}

function extractFirstUrlFromText(text) {
  const m = String(text || "").match(/https?:\/\/[^\s"'<>]+/i);
  return m ? m[0] : "";
}

function getLinkPreviewMetaInstant(url) {
  const cleanUrl = String(url || "").split("#")[0].trim();
  if (!cleanUrl) return null;
  if (linkMetaCache[cleanUrl]) return linkMetaCache[cleanUrl];

  let domain = "link.com.br";
  let slugTitle = "Acesso Oficial";
  try {
    const u = new URL(cleanUrl);
    domain = u.hostname.replace(/^www\./i, "");
    const pathClean = u.pathname.replace(/^\/+|\/+$/g, "").replace(/[-_]/g, " ");
    slugTitle = pathClean
      ? `${domain.split(".")[0].toUpperCase()} — ${pathClean.charAt(0).toUpperCase() + pathClean.slice(1)}`
      : `Pagina Oficial • ${domain.toUpperCase()}`;
  } catch (e) {}

  const fallback = {
    url: cleanUrl,
    domain: domain,
    title: slugTitle,
    description: `Toque no cartao para abrir ${domain} e conferir o conteudo completo.`
  };
  linkMetaCache[cleanUrl] = fallback;

  // Buscar metadados OpenGraph reais no servidor de forma assincrona
  fetch("/api/link/preview-meta", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url: cleanUrl })
  })
    .then(r => r.json())
    .then(data => {
      if (data && data.ok) {
        linkMetaCache[cleanUrl] = data;
        updateLivePreview();
        updateGroupLivePreview();
      }
    })
    .catch(() => {});

  return fallback;
}

function buildWhatsAppRichPreviewHtml(renderedText) {
  const foundUrl = extractFirstUrlFromText(renderedText);
  const badgeEl = document.getElementById("link-preview-status-badge");
  if (badgeEl) badgeEl.style.display = foundUrl ? "inline-block" : "none";

  let linkCardHtml = "";
  if (foundUrl) {
    const meta = getLinkPreviewMetaInstant(foundUrl);
    if (meta) {
      linkCardHtml = `
        <div class="wa-rich-link-card">
          <div class="wa-rich-link-domain">
            <span>${escapeHtml(meta.domain)}</span>
            <span style="font-size:9.5px; color:var(--primary);">Previa OpenGraph</span>
          </div>
          <div class="wa-rich-link-title">${escapeHtml(meta.title)}</div>
          <div class="wa-rich-link-desc">${escapeHtml(meta.description)}</div>
        </div>
      `;
    }
  }

  const formattedBody = escapeHtml(renderedText).replace(
    /(https?:\/\/[^\s<]+)/gi,
    '<span style="color:#0284c7; text-decoration:underline; font-weight:600;">$1</span>'
  );

  return `
    <div class="wa-preview-bubble">
      ${linkCardHtml}
      <div style="white-space:pre-wrap;">${formattedBody}</div>
    </div>
  `;
}

/* ============================================================================
   SINCRONIZAÇÃO COM SERVIDOR (/api/overview)
============================================================================ */
async function fetchOverview() {
  try {
    const logged = getCurrentLoggedUserObj();
    const viewerParam = logged && logged.username ? `?viewer_user=${encodeURIComponent(logged.username)}` : "";
    const res = await fetch(`/api/overview${viewerParam}`);
    if (!res.ok) return;
    appData = await res.json();

    const validChipIds = new Set((appData.chips || []).map(c => c.id));
    if (!window._chipsInitDone && appData.chips.length > 0) {
      selectedChipIds = new Set(validChipIds);
      window._chipsInitDone = true;
    } else {
      selectedChipIds = new Set([...selectedChipIds].filter(id => validChipIds.has(id)));
    }

    if (!autoReplyInitialized) {
      if (appData.autoreply_flows && appData.autoreply_flows.length > 0) {
        loadAutoReplyFlowObjectIntoEditor(appData.autoreply_flows[0]);
      } else {
        renderAutoReplyStepsEditor();
      }
      autoReplyInitialized = true;
    }
    renderAutoReplyFlowsCatalog();

    renderAll();
  } catch (e) {
    console.error("Erro ao sincronizar overview:", e);
  }
}

function renderAll() {
  renderWorkspaceContacts();
  updateLivePreview();
  renderWorkspaceChips();
  renderMultiCampaignsMonitor();
  renderCrmView();
  renderDirectChipSelector();
  renderGroupExtractorChipSelector();
  renderSidebarAndMonitorChipSelectors();
  renderAutoReplyFeed();
  renderChipsTab();
  renderWarmupTab();
  renderAccessAndPixTab();
  renderAutoUpdateTopbarState();
}

function renderAutoUpdateTopbarState() {
  const ota = appData.auto_update_state || {};
  const ver = appData.app_version || ota.version || "5.7.0";
  const topTag = document.getElementById("topbar-app-version-tag");
  if (topTag) topTag.textContent = `PRO v${ver.replace(/\.0$/, "")}`;

  const pill = document.getElementById("btn-auto-update-pill");
  if (pill) {
    pill.textContent = `Auto-Update Nativo (v${ver})`;
    if (ota.status_text) pill.title = ota.status_text;
  }

  const adminBadge = document.getElementById("admin-ota-version-badge");
  if (adminBadge) adminBadge.textContent = `v${ver} • OTA Ativo`;

  const adminStatus = document.getElementById("admin-ota-status-label");
  if (adminStatus && ota.status_text) {
    adminStatus.textContent = ota.status_text;
  }
}

async function triggerNativeAutoUpdateCheck() {
  const srvInput = document.getElementById("admin-ota-server-url");
  const customUrl = srvInput ? srvInput.value.trim() : "";
  showToast("Verificando e sincronizando atualizacoes automaticas (OTA) do sistema...");
  try {
    const res = await fetch("/api/system/auto-update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(srvInput ? { server_url: customUrl } : {})
    });
    const data = await res.json();
    if (data.ok) {
      showToast(data.status_text || `Auto-Updater sincronizado na versao v${data.version}!`);
      await fetchOverview();
      if (data.updated_files && data.updated_files > 0) {
        setTimeout(() => window.location.reload(), 1200);
      }
    }
  } catch (e) {
    showToast("Auto-Updater Nativo verificado localmente.");
  }
}

async function exportCloudOtaPackage() {
  showToast("Criptografando e baixando pacote OTA (update-manifest.json + update-bundle.nxcrypt)...");
  window.location.href = "/api/system/download-cloud-package-zip";
}

function getPlanPricingFromConfig() {
  const cfg = appData.pix_config || {};
  const toNum = (v, def) => {
    const n = parseFloat(String(v || def).replace(",", "."));
    return isNaN(n) ? def : n;
  };
  return {
    p1: toNum(cfg.plan_1_price || cfg.monthly_amount, 150.0),
    p3: toNum(cfg.plan_3_price, 360.0),
    p5: toNum(cfg.plan_5_price, 525.0),
    extra: toNum(cfg.extra_seat_price, 95.0)
  };
}

function computeClientPlanQuote(planCode, extraSeats) {
  const prices = getPlanPricingFromConfig();
  const code = String(planCode || "plan_1").toLowerCase();
  let baseSeats = 1;
  let basePrice = prices.p1;
  let baseName = "Plano Individual (1 Login)";
  if (code === "plan_5") {
    baseSeats = 5;
    basePrice = prices.p5;
    baseName = "Plano Coordenacao (5 Logins)";
  } else if (code === "plan_3") {
    baseSeats = 3;
    basePrice = prices.p3;
    baseName = "Plano Trio / Equipe (3 Logins)";
  }
  const ext = Math.max(0, Math.min(50, parseInt(extraSeats || 0, 10) || 0));
  const totalSeats = baseSeats + ext;
  const totalPrice = basePrice + ext * prices.extra;
  const label = ext > 0 ? `${baseName} + ${ext} Adicional(is) (${totalSeats} Logins)` : baseName;
  return {
    plan_code: code,
    base_seats: baseSeats,
    extra_seats: ext,
    total_seats: totalSeats,
    monthly_amount: totalPrice.toFixed(2),
    plan_label: label
  };
}

function recalculateReqPlanSummary() {
  const code = document.getElementById("req-plan-code")?.value || "plan_1";
  const ext = parseInt(document.getElementById("req-extra-logins")?.value || "0", 10) || 0;
  const quote = computeClientPlanQuote(code, ext);
  const badge = document.getElementById("req-plan-total-badge");
  if (badge) {
    badge.textContent = `${quote.total_seats} Login(s) • R$ ${quote.monthly_amount.replace(".", ",")} / mes`;
  }
  const helper = document.getElementById("req-plan-helper-text");
  if (helper) {
    helper.textContent = quote.total_seats > 1
      ? `Contrato com ${quote.total_seats} vagas (1 Login Titular + ${quote.total_seats - 1} Sub-Login(s) de Equipe gerenciados automaticamente por voce na Aba 7).`
      : "Contrato Individual (1 Login Titular). Voce pode fazer upgrade ou adicionar logins extras a qualquer momento na Aba 7.";
  }
}

/* ============================================================================
   ABA 1: BASE DE CONTATOS E MULTI-CAMPANHAS SIMULTÂNEAS
============================================================================ */
function getCrmStagesList() {
  const defaultStages = [
    { key: "novo", label: "1. Novo Lead", fixed: true, color: "#64748b" },
    { key: "enviado", label: "2. Mensagem Enviada", fixed: true, color: "#d97706" },
    { key: "respondeu", label: "3. Respondeu", fixed: true, color: "#0284c7" },
    { key: "qualificado", label: "4. Qualificado", fixed: false, color: "#059669" },
    { key: "convertido", label: "5. Convertido", fixed: false, color: "#047857" }
  ];
  const palette = ["#64748b", "#d97706", "#0284c7", "#059669", "#047857", "#7c3aed", "#db2777"];
  const fromServer = appData.crm_stages;
  if (!Array.isArray(fromServer) || fromServer.length < 3) return defaultStages;
  return fromServer.map((st, idx) => ({
    key: st.key || `etapa_${idx + 1}`,
    label: st.label || `Etapa ${idx + 1}`,
    fixed: idx < 3,
    color: palette[idx % palette.length]
  }));
}

function getStageBadgeHtml(stage) {
  const stages = getCrmStagesList();
  const found = stages.find(s => s.key === stage);
  const clsMap = {
    novo: "badge-pending",
    enviado: "badge-warn",
    respondeu: "badge-sent"
  };
  const cls = clsMap[stage] || "badge-sent";
  const label = found ? found.label.replace(/^\d+\.\s*/, "") : (stage || "Novo Lead");
  return `<span class="badge ${cls}">${escapeHtml(label)}</span>`;
}

function renderTagsPillsHtml(tagsStr) {
  const tags = String(tagsStr || "lead").split(",").map(t => t.trim()).filter(Boolean);
  return tags.map(t => `<span class="tag-pill">${escapeHtml(t)}</span>`).join("");
}

function buildChipAssignSelectHtml(contact) {
  const assignedId = parseInt(contact.assigned_chip_id || 0, 10);
  const options = [
    `<option value="0" ${assignedId === 0 ? "selected" : ""}>Auto (Fixar no 1o contato)</option>`
  ];
  for (const ch of appData.chips) {
    const sel = ch.id === assignedId ? "selected" : "";
    options.push(`<option value="${ch.id}" ${sel}>Fixo: ${escapeHtml(ch.name)} (+${escapeHtml(ch.phone)})</option>`);
  }
  const highlightStyle = assignedId > 0
    ? "border-color:var(--primary); background:var(--primary-soft); color:var(--primary-hover); font-weight:700;"
    : "";
  return `
    <select class="select" style="padding:3px 6px; font-size:11px; ${highlightStyle}"
      onchange="updateCrmContact(${contact.id}, { assigned_chip_id: parseInt(this.value, 10) })">
      ${options.join("")}
    </select>
  `;
}

let campaignMediaState = {
  media_type: "texto",
  media_filename: "",
  media_mime: "",
  media_base64: ""
};

const FORMAT_LABELS_MAP = {
  texto: "Texto",
  imagem: "Imagem + Legenda Variavel",
  video: "Video + Legenda Variavel",
  audio: "Audio (Formato Conversa) + Legenda",
  documento: "Documento + Legenda Variavel",
  respostas_rapidas: "Respostas Rapidas",
  pix: "Cobranca PIX + Legenda Variavel",
  convite_grupo: "Convite para Grupo + Legenda",
  contato: "Cartao de Contato",
  link_banner: "Link com Banner (OpenGraph)",
  figurinha: "Figurinha (Sticker)",
  lista: "Mensagem em Lista"
};

function selectCampaignMessageFormat(fmt) {
  campaignMediaState.media_type = fmt || "texto";
  document.querySelectorAll("#camp-media-type-toolbar .camp-fmt-btn").forEach(btn => {
    const isAct = btn.getAttribute("data-fmt") === campaignMediaState.media_type;
    btn.className = isAct ? "btn btn-primary btn-sm camp-fmt-btn" : "btn btn-outline btn-sm camp-fmt-btn";
  });

  const badge = document.getElementById("camp-media-active-badge");
  if (badge) {
    badge.textContent = `Formato: ${FORMAT_LABELS_MAP[campaignMediaState.media_type] || fmt}`;
  }

  const uploadRow = document.getElementById("camp-media-upload-row");
  const uploadLbl = document.getElementById("camp-media-upload-label");
  const fileInput = document.getElementById("camp-media-file-input");
  const recTimer = document.getElementById("camp-timer-recording");
  const typTimer = document.getElementById("camp-timer-typing");

  const needsFile = ["imagem", "video", "audio", "documento", "figurinha"].includes(campaignMediaState.media_type);
  if (uploadRow) uploadRow.style.display = needsFile ? "block" : "none";

  if (fileInput) {
    if (campaignMediaState.media_type === "imagem") fileInput.accept = "image/*";
    else if (campaignMediaState.media_type === "video") fileInput.accept = "video/mp4,video/*";
    else if (campaignMediaState.media_type === "audio") fileInput.accept = "audio/ogg,audio/mpeg,audio/mp3,audio/wav,audio/*";
    else if (campaignMediaState.media_type === "figurinha") fileInput.accept = "image/webp,image/png,image/*";
    else fileInput.accept = ".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip,*/*";
  }

  if (uploadLbl) {
    const lblByFmt = {
      imagem: "Selecione a Imagem (.JPG, .PNG, .WEBP) — Sera enviada com a Legenda Variavel abaixo:",
      video: "Selecione o Video (.MP4) — Sera enviado como video na conversa com a Legenda Variavel abaixo:",
      audio: "Selecione o Audio (.OGG, .MP3, .WAV) — Sera enviado como audio na conversa (+ Legenda opcional):",
      documento: "Selecione o Documento (.PDF, .DOCX, .XLSX) — Sera enviado com a Legenda Variavel abaixo:",
      figurinha: "Selecione a Imagem/Figurinha (.WEBP, .PNG) — Sera enviada na conversa:"
    };
    uploadLbl.textContent = lblByFmt[campaignMediaState.media_type] || "Selecione o Arquivo:";
  }

  if (campaignMediaState.media_type === "audio") {
    if (recTimer && parseFloat(recTimer.value || "0") <= 0) recTimer.value = "3";
  } else {
    if (recTimer) recTimer.value = "0";
    if (typTimer && parseFloat(typTimer.value || "0") <= 0) typTimer.value = "2";
  }

  const editor = document.getElementById("msg-editor");
  if (editor && !editor.value.trim()) {
    if (campaignMediaState.media_type === "pix") {
      const pKey = appData.pix_config?.pix_key || "SUA-CHAVE-PIX";
      editor.value = `Oi, {{primeiro nome}}, tudo bem? Me chamo {{nome do chip}}.\n\nSegue a chave PIX oficial para confirmacao: ${pKey}`;
      onEditorInput();
    } else if (campaignMediaState.media_type === "convite_grupo") {
      editor.value = `Oi, {{primeiro nome}}, tudo bem? Me chamo {{nome do chip}}.\n\nGostaria de te convidar para entrar no nosso grupo oficial pelo link abaixo:\n{{link}}`;
      onEditorInput();
    } else if (campaignMediaState.media_type === "lista") {
      editor.value = `Oi, {{primeiro nome}}, tudo bem? Me chamo {{nome do chip}}.\n\nEscolha uma das opcoes abaixo respondendo com o numero:\n1 - Quero participar\n2 - Quero saber mais detalhes\n3 - Falar com a coordenacao`;
      onEditorInput();
    }
  }
  updateLivePreview();
}

function onCampaignMediaFileSelected(inputEl) {
  const file = inputEl?.files?.[0];
  const stEl = document.getElementById("camp-media-file-status");
  if (!file) return;

  if (file.size > 16 * 1024 * 1024) {
    showToast("Escolha um arquivo de ate 16 MB para envio rapido via WhatsApp Web.");
    inputEl.value = "";
    return;
  }

  const reader = new FileReader();
  reader.onload = (ev) => {
    const dataUrl = String(ev.target?.result || "");
    const b64 = dataUrl.includes(",") ? dataUrl.split(",", 1)[1] : dataUrl;
    campaignMediaState.media_filename = file.name;
    campaignMediaState.media_mime = file.type || "";
    campaignMediaState.media_base64 = b64;
    const kb = Math.max(1, Math.round(file.size / 1024));
    if (stEl) {
      stEl.textContent = `Anexado: ${file.name} (${kb} KB)`;
      stEl.style.color = "var(--primary)";
    }
    updateLivePreview();
    showToast(`Arquivo "${file.name}" anexado para disparo no formato ${campaignMediaState.media_type.toUpperCase()}!`);
  };
  reader.readAsDataURL(file);
}

function clearCampaignMediaFile() {
  campaignMediaState.media_filename = "";
  campaignMediaState.media_mime = "";
  campaignMediaState.media_base64 = "";
  const fileInput = document.getElementById("camp-media-file-input");
  if (fileInput) fileInput.value = "";
  const stEl = document.getElementById("camp-media-file-status");
  if (stEl) {
    stEl.textContent = "Nenhum arquivo anexado";
    stEl.style.color = "var(--text-secondary)";
  }
  updateLivePreview();
}

function downloadCampaignVeridicalReportCsv(campaignId = 0) {
  showToast("Gerando Relatorio Veridico Auditado (.CSV) de todos os envios...");
  window.location.href = `/api/campaigns/report-csv?campaign_id=${campaignId || 0}`;
}

function renderWorkspaceContacts() {
  const countEl = document.getElementById("lbl-contact-count");
  if (countEl) countEl.textContent = appData.contacts.length;

  const filterStage = (document.getElementById("workspace-filter-stage")?.value || "").trim();
  const filterTag = (document.getElementById("workspace-filter-tag")?.value || "").trim().toLowerCase();

  const filtered = appData.contacts.filter(c => {
    if (filterStage && c.crm_stage !== filterStage) return false;
    if (filterTag) {
      const hay = `${c.tags || ""} ${c.city || ""} ${c.social_name || ""} ${c.name || ""}`.toLowerCase();
      if (!hay.includes(filterTag)) return false;
    }
    return true;
  });

  const tbody = document.getElementById("contacts-tbody");
  if (!tbody) return;

  if (filtered.length === 0) {
    updateHtmlPreservingScrollAndFocus(tbody, `
      <tr>
        <td colspan="4" style="text-align:center; padding:20px; color:var(--text-muted);">
          Nenhum contato na base. Clique em "+ Subir Contatos" acima para importar sua planilha .CSV ou lista.
        </td>
      </tr>
    `);
    return;
  }

  const rowsHtml = filtered.map(c => {
    const dispName = (c.social_name && c.social_name.trim()) ? c.social_name.trim() : c.name;
    const socialBadge = (c.social_name && c.social_name.trim())
      ? `<span class="badge badge-sent" style="font-size:9px; padding:1px 5px; margin-left:4px;">Nome Social</span>`
      : "";
    return `
      <tr>
        <td>
          <div style="font-weight:700;">${escapeHtml(dispName)}${socialBadge}</div>
          <div style="font-size:11px; color:var(--text-muted); font-family:monospace;">+${escapeHtml(c.phone)} ${c.city ? `• ${escapeHtml(c.city)}` : ""}</div>
          <div style="margin-top:2px;">${renderTagsPillsHtml(c.tags)}</div>
        </td>
        <td>${buildChipAssignSelectHtml(c)}</td>
        <td>${getStageBadgeHtml(c.crm_stage)}</td>
        <td style="text-align:right;">
          <button class="btn btn-outline btn-sm" onclick="deleteContact(${c.id})" style="padding:2px 7px;">X</button>
        </td>
      </tr>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(tbody, rowsHtml);
}

function selectVarTab(idx, btnElement) {
  activeVarIdx = idx;
  document.querySelectorAll("#var-tabs-container .var-tab").forEach(b => b.classList.remove("active"));
  if (btnElement) btnElement.classList.add("active");

  const styleLbl = VARIATION_STYLE_LABELS[idx] || `V${idx + 1}`;
  const ind = document.getElementById("active-var-indicator");
  if (ind) ind.textContent = `Editando / Visualizando: ${styleLbl}`;

  const cohStyle = document.getElementById("cohesion-style-label");
  if (cohStyle) cohStyle.textContent = `Estilo Ativo: ${styleLbl}`;

  const editor = document.getElementById("msg-editor");
  if (editor) editor.value = variationsState[idx] || "";
  updateLivePreview();
}

function onEditorInput() {
  const editor = document.getElementById("msg-editor");
  if (!editor) return;
  const val = editor.value;
  if (activeVarIdx === 0) {
    variationsState = buildClientSide15Variations(val);
    const ind = document.getElementById("active-var-indicator");
    if (ind) {
      ind.textContent = val.trim()
        ? "15 Variacoes de Alto Nivel (V1..V15) geradas com Coesao e Coerencia!"
        : "Digite em V1 para gerar V1..V15 com Coesao & Coerencia";
    }
  } else {
    variationsState[activeVarIdx] = enforceClientCohesionAndCoherence(val);
  }
  updateLivePreview();
}

function insertVariable(tag) {
  const editor = document.getElementById("msg-editor");
  if (!editor) return;
  const start = editor.selectionStart || 0;
  const end = editor.selectionEnd || 0;
  const current = editor.value;
  editor.value = current.slice(0, start) + tag + current.slice(end);
  onEditorInput();
  editor.focus();
}

function updateLivePreview() {
  const previewBox = document.getElementById("live-preview-box");
  if (!previewBox) return;
  const sampleContact = appData.contacts[0] || {
    name: "Paulo",
    company: "",
    city: "",
    role: "",
    custom1: ""
  };
  const currentTemplate = variationsState[activeVarIdx] || "";
  if (!currentTemplate.trim()) {
    const badgeEl = document.getElementById("link-preview-status-badge");
    if (badgeEl) badgeEl.style.display = "none";
    previewBox.innerHTML = `<div style="font-size:11.5px; color:var(--text-muted);">Digite sua mensagem no campo acima para ver a previa real, analise de coesao/coerencia e o Card de Previa do Link no WhatsApp.</div>`;
    return;
  }
  const rendered = renderTemplateClientSide(currentTemplate, sampleContact);
  previewBox.innerHTML = buildWhatsAppRichPreviewHtml(rendered);
}

async function generate15Variations() {
  const editorVal = (document.getElementById("msg-editor")?.value || "").trim();
  const baseText = editorVal || variationsState[activeVarIdx] || variationsState[0] || "";
  if (!baseText.trim()) {
    showToast("Digite a sua mensagem no campo antes de gerar as 15 variacoes.");
    return;
  }
  const res = await fetch("/api/ai/generate-variations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ base_template: baseText, count: 15 })
  });
  const data = await res.json();
  if (data.variations && data.variations.length >= 15) {
    variationsState = data.variations.slice(0, 15);
    const editor = document.getElementById("msg-editor");
    if (editor) editor.value = variationsState[activeVarIdx];
    if (data.analysis) {
      const scoreBadge = document.getElementById("cohesion-score-badge");
      const diagText = document.getElementById("cohesion-diag-text");
      if (scoreBadge) scoreBadge.textContent = `Coesao & Coerencia IA: ${data.analysis.overall_score || 99}% (Diversidade: ${data.analysis.lexical_diversity || 98}%)`;
      if (diagText && data.analysis.diagnostics) diagText.textContent = data.analysis.diagnostics.join(" • ");
    }
    updateLivePreview();
    showToast("15 variacoes de alto nivel (V1 a V15) com analise de coesao e coerencia geradas!");
  }
}

function toggleAllChips(selectAll) {
  if (selectAll) {
    appData.chips.forEach(c => selectedChipIds.add(c.id));
  } else {
    selectedChipIds.clear();
  }
  renderWorkspaceChips();
}

function renderWorkspaceChips() {
  const container = document.getElementById("workspace-chip-list");
  if (!container) return;

  const counterEl = document.getElementById("selected-chips-counter");
  if (counterEl) counterEl.textContent = selectedChipIds.size;

  if (!appData.chips || appData.chips.length === 0) {
    updateHtmlPreservingScrollAndFocus(container, `
      <div style="text-align:center; color:var(--text-muted); padding:10px; font-size:11.5px;">
        Nenhum chip cadastrado. Clique em "4. Central de Chips" ou "+ Cadastrar Novo Chip Real".
      </div>
    `);
    return;
  }

  const html = appData.chips.map(c => {
    const checked = selectedChipIds.has(c.id) ? "checked" : "";
    const isConnected = c.live_wa_status === "connected";
    const statusBadge = isConnected
      ? `<span class="badge badge-sent">WhatsApp Conectado</span>`
      : `<button class="btn btn-outline btn-sm" onclick="openQrModal(${c.id})" style="padding:2px 7px; font-size:10.5px;">Conectar QR</button>`;

    return `
      <div class="chip-row-check">
        <label style="display:flex; align-items:center; gap:7px; cursor:pointer; font-weight:600;">
          <input type="checkbox" ${checked} onchange="toggleChipSelection(${c.id}, this.checked)" />
          <span>${escapeHtml(c.name)}</span>
          <span style="font-size:10.5px; color:var(--text-muted); font-family:monospace;">(+${escapeHtml(c.phone)})</span>
        </label>
        <div style="display:flex; align-items:center; gap:6px;">
          <span style="font-size:10.5px; color:var(--text-secondary);">${c.sent_today}/${c.daily_limit}</span>
          ${statusBadge}
        </div>
      </div>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(container, html);
}

function toggleChipSelection(id, isChecked) {
  if (isChecked) selectedChipIds.add(id);
  else selectedChipIds.delete(id);
  const counterEl = document.getElementById("selected-chips-counter");
  if (counterEl) counterEl.textContent = selectedChipIds.size;
}

async function launchNewCampaign() {
  const chipIds = Array.from(selectedChipIds);
  if (chipIds.length === 0) {
    showToast("Selecione pelo menos 1 chip para disparar esta campanha.");
    return;
  }
  if (appData.contacts.length === 0) {
    showToast("Sua base de contatos esta vazia. Suba seus contatos ou extraia de um grupo primeiro.");
    return;
  }

  const typedMsg = (document.getElementById("msg-editor")?.value || "").trim();
  const baseMsg = (variationsState[0] || typedMsg).trim();
  const hasMediaFile = Boolean(campaignMediaState.media_base64);

  if (!baseMsg && !hasMediaFile) {
    showToast("Digite a sua mensagem/legenda ou anexe um arquivo de midia antes de iniciar o disparo!");
    return;
  }

  const activeVariations = baseMsg
    ? (variationsState.filter(v => v && v.trim()).length >= 15
        ? variationsState
        : buildClientSide15Variations(baseMsg))
    : [""];

  const name = (document.getElementById("camp-name")?.value || `Campanha #${Date.now().toString().slice(-3)}`).trim();
  const targetTag = (document.getElementById("camp-target-tag")?.value || "").trim();
  const targetStage = (document.getElementById("camp-target-stage")?.value || "").trim();
  const campaignLink = (document.getElementById("camp-link")?.value || "").trim();
  const campaignOffer = (document.getElementById("camp-offer")?.value || "").trim();
  const chipMode = document.getElementById("camp-chip-mode")?.value || "sticky_random";
  const minDelay = parseInt(document.getElementById("delay-min")?.value || "3", 10);
  const maxDelay = parseInt(document.getElementById("delay-max")?.value || "7", 10);
  const scheduleAt = document.getElementById("schedule-time")?.value || "";

  const timerWait = parseFloat(document.getElementById("camp-timer-wait")?.value || "0") || 0;
  const timerTyping = parseFloat(document.getElementById("camp-timer-typing")?.value || "2") || 0;
  const timerRecording = parseFloat(document.getElementById("camp-timer-recording")?.value || "0") || 0;

  const res = await fetch("/api/campaigns/create", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: name,
      chip_ids: chipIds,
      chip_mode: chipMode,
      target_tag: targetTag,
      target_stage: targetStage,
      campaign_link: campaignLink,
      campaign_offer: campaignOffer,
      base_template: baseMsg,
      variations: activeVariations,
      min_delay_sec: minDelay,
      max_delay_sec: maxDelay,
      schedule_at: scheduleAt,
      start_now: !scheduleAt,
      media_type: campaignMediaState.media_type || "texto",
      media_filename: campaignMediaState.media_filename || "",
      media_mime: campaignMediaState.media_mime || "",
      media_base64: campaignMediaState.media_base64 || "",
      timer_wait_sec: timerWait,
      timer_typing_sec: timerTyping,
      timer_recording_sec: timerRecording
    })
  });
  const data = await res.json();
  if (data.ok) {
    const nextNum = (appData.campaigns.length || 1) + 2;
    const nameInput = document.getElementById("camp-name");
    if (nameInput) nameInput.value = `Campanha Comercial #0${nextNum}`;

    showToast(`Campanha "${name}" (${(campaignMediaState.media_type || "texto").toUpperCase()}) iniciada!`);
    fetchOverview();
  }
}

async function controlCampaign(campaignId, action) {
  await fetch("/api/campaigns/control", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ campaign_id: campaignId, action: action })
  });
  fetchOverview();
}

function renderMultiCampaignsMonitor() {
  const statusMain = document.getElementById("status-main-text");
  if (statusMain && appData.queue_state) {
    statusMain.textContent = appData.queue_state.status_text;
  }

  const campaigns = appData.campaigns || [];
  const runningCount = campaigns.filter(c => c.status === "running").length;
  const activeLbl = document.getElementById("lbl-active-campaigns");
  if (activeLbl) activeLbl.textContent = runningCount;

  const listEl = document.getElementById("multi-campaigns-list");
  if (listEl) {
    if (campaigns.length === 0) {
      updateHtmlPreservingScrollAndFocus(listEl, `
        <div style="text-align:center; color:var(--text-muted); padding:16px; font-size:12px; border:1px dashed var(--border); border-radius:8px;">
          Nenhuma campanha em execucao. Configure sua mensagem na Coluna 2 e clique em "Iniciar Disparo da Campanha".
        </div>
      `);
    } else {
      const campHtml = campaigns.map(c => {
        const total = c.total_contacts || 0;
        const sent = c.sent_count || 0;
        const failed = c.failed_count || 0;
        const processed = sent + failed;
        const pct = total > 0 ? Math.min(100, Math.round((processed / total) * 100)) : 0;
        let chipIds = [];
        try { chipIds = JSON.parse(c.chip_ids_json || "[1]"); } catch (e) { chipIds = [1]; }

        const fmtTag = (c.media_type && c.media_type !== "texto") ? ` • [${c.media_type.toUpperCase()}]` : "";
        const segTag = c.target_tag ? `Tag: ${c.target_tag}` : "Todas as Tags";

        let statusBadge = `<span class="badge badge-pending">${escapeHtml(c.status)}</span>`;
        if (c.status === "running") statusBadge = `<span class="badge badge-sent">Em Operacao (${pct}%)</span>`;
        else if (c.status === "paused") statusBadge = `<span class="badge badge-warn">Pausada</span>`;
        else if (c.status === "completed") statusBadge = `<span class="badge badge-sent">Concluida (${sent} enviados reais)</span>`;

        return `
          <div class="multi-camp-card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
              <strong style="font-size:12.5px; color:var(--text-main);">${escapeHtml(c.name)}${escapeHtml(fmtTag)}</strong>
              ${statusBadge}
            </div>
            <div style="font-size:11px; color:var(--text-secondary); display:flex; justify-content:space-between; flex-wrap:wrap; gap:4px;">
              <span>${chipIds.length} chip(s) • ${escapeHtml(segTag)}</span>
              <span><strong style="color:var(--primary);">${sent} enviados reais</strong> ${failed > 0 ? `• <span style="color:var(--danger);">${failed} nao enviados</span>` : ""} / ${total} total</span>
            </div>
            <div class="progress-track">
              <div class="progress-fill" style="width:${pct}%;"></div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:7px; gap:6px; flex-wrap:wrap;">
              <button class="btn btn-outline btn-sm" onclick="downloadCampaignVeridicalReportCsv(${c.id})" style="font-size:10px; padding:2px 8px;">
                Relatorio Veridico (.CSV)
              </button>
              <div style="display:flex; gap:5px;">
                ${c.status === "running" ? `<button class="btn btn-outline btn-sm" onclick="controlCampaign(${c.id}, 'pause')">Pausar</button>` : ""}
                ${c.status === "paused" ? `<button class="btn btn-primary btn-sm" onclick="controlCampaign(${c.id}, 'resume')">Retomar</button>` : ""}
                <button class="btn btn-danger btn-sm" onclick="controlCampaign(${c.id}, 'delete')">Excluir</button>
              </div>
            </div>
          </div>
        `;
      }).join("");
      updateHtmlPreservingScrollAndFocus(listEl, campHtml);
    }
  }

  const realSentLogs = (appData.recent_logs || []).filter(l => l.status === "sent");
  const totalSentEl = document.getElementById("lbl-sent-total");
  if (totalSentEl) totalSentEl.textContent = `${realSentLogs.length} enviados reais / ${(appData.recent_logs || []).length} registros`;

  const feedEl = document.getElementById("sent-feed-list");
  if (!feedEl) return;

  if (!appData.recent_logs || appData.recent_logs.length === 0) {
    updateHtmlPreservingScrollAndFocus(feedEl, `
      <div style="text-align:center; color:var(--text-muted); padding:24px 12px; font-size:12px;">
        Nenhum disparo registrado ainda. Conecte seu chip via QR Code e inicie uma campanha para acompanhar os envios reais aqui.
      </div>
    `);
    return;
  }

  const logsHtml = appData.recent_logs.map(log => {
    const isSent = log.status === "sent";
    const borderCol = isSent ? "var(--primary)" : "var(--danger)";
    const statusPill = isSent
      ? `<span class="badge badge-sent" style="font-size:9.5px;">ENVIADO REAL</span>`
      : `<span class="badge badge-warn" style="font-size:9.5px;">NAO ENVIADO (CHIP DESCONECTADO)</span>`;
    return `
      <div class="sent-card" style="border-left-color:${borderCol};">
        <div class="sent-card-meta">
          <span>Para: <strong>${escapeHtml(log.contact_name)}</strong> (+${escapeHtml(log.contact_phone)})</span>
          <span>${statusPill} • Var V${log.variation_index}</span>
        </div>
        <div style="font-size:10.5px; color:var(--text-secondary); margin-bottom:3px;">${escapeHtml(log.chip_name)}</div>
        <div class="sent-card-body">${escapeHtml(log.rendered_message)}</div>
        <div style="margin-top:4px; font-size:10.5px; color:var(--text-muted); display:flex; justify-content:space-between;">
          <span>Data/Hora: ${escapeHtml(log.created_at || "")} • Intervalo: ${log.delay_applied}s</span>
          <span>Hash: #${escapeHtml(log.uniqueness_hash)}</span>
        </div>
      </div>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(feedEl, logsHtml);
}

/* ============================================================================
   ABA 2: CRM, ETIQUETAS PERSONALIZADAS, NOME SOCIAL INVARIÁVEL E CIDADE
============================================================================ */
let crmCustomStagesLoaded = false;

function toggleCrmCustomStagesEditor() {
  const box = document.getElementById("crm-custom-stages-editor-box");
  if (!box) return;
  box.style.display = box.style.display === "none" ? "block" : "none";
}

function syncStageSelectorsAcrossApp() {
  const stages = getCrmStagesList();
  const stageSelectIds = ["workspace-filter-stage", "camp-target-stage", "crm-search-stage"];
  stageSelectIds.forEach(selId => {
    const sel = document.getElementById(selId);
    if (!sel || document.activeElement === sel) return;
    const prevVal = sel.value;
    const firstOpt = selId === "camp-target-stage" ? "Todos os Contatos" : "Todos os Estagios";
    const optsHtml = [`<option value="">${firstOpt}</option>`].concat(
      stages.map(s => `<option value="${escapeHtml(s.key)}">${escapeHtml(s.label)}</option>`)
    ).join("");
    if (sel.innerHTML !== optsHtml) {
      sel.innerHTML = optsHtml;
      sel.value = prevVal;
    }
  });

  if (!crmCustomStagesLoaded && Array.isArray(appData.crm_stages) && appData.crm_stages.length >= 4) {
    const s4 = document.getElementById("crm-stage-4-label");
    const s5 = document.getElementById("crm-stage-5-label");
    const s6 = document.getElementById("crm-stage-6-label");
    const s7 = document.getElementById("crm-stage-7-label");
    const tagsIn = document.getElementById("crm-custom-tags-input");
    if (s4 && appData.crm_stages[3]) s4.value = appData.crm_stages[3].label || "4. Qualificado";
    if (s5 && appData.crm_stages[4]) s5.value = appData.crm_stages[4].label || "5. Convertido";
    if (s6 && appData.crm_stages[5]) s6.value = appData.crm_stages[5].label || "";
    if (s7 && appData.crm_stages[6]) s7.value = appData.crm_stages[6].label || "";
    if (tagsIn && Array.isArray(appData.crm_custom_tags)) {
      tagsIn.value = appData.crm_custom_tags.join(", ");
    }
    crmCustomStagesLoaded = true;
  }
}

async function saveCustomCrmStagesAndTags() {
  const s4 = (document.getElementById("crm-stage-4-label")?.value || "4. Qualificado").trim();
  const s5 = (document.getElementById("crm-stage-5-label")?.value || "5. Convertido").trim();
  const s6 = (document.getElementById("crm-stage-6-label")?.value || "").trim();
  const s7 = (document.getElementById("crm-stage-7-label")?.value || "").trim();
  const rawTags = (document.getElementById("crm-custom-tags-input")?.value || "").split(",").map(t => t.trim()).filter(Boolean);

  const stagesPayload = [
    { key: "novo", label: "1. Novo Lead", fixed: true },
    { key: "enviado", label: "2. Mensagem Enviada", fixed: true },
    { key: "respondeu", label: "3. Respondeu", fixed: true },
    { key: "qualificado", label: s4 || "4. Qualificado", fixed: false },
    { key: "convertido", label: s5 || "5. Convertido", fixed: false }
  ];
  if (s6) stagesPayload.push({ key: "etapa_6", label: s6, fixed: false });
  if (s7) stagesPayload.push({ key: "etapa_7", label: s7, fixed: false });

  const res = await fetch("/api/crm/save-custom-config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ crm_stages: stagesPayload, crm_custom_tags: rawTags })
  });
  const data = await res.json();
  if (data.ok) {
    crmCustomStagesLoaded = false;
    showToast(data.detail || "Etiquetas e Colunas personalizadas do CRM salvas!");
    fetchOverview();
  }
}

function exportFilteredCrmContactsCsv() {
  const tagOrCity = (document.getElementById("crm-search-tag")?.value || "").trim();
  const stage = (document.getElementById("crm-search-stage")?.value || "").trim();
  showToast("Exportando planilha .CSV (Respeitando Nome Social e Cidade como Etiqueta)...");
  window.location.href = `/api/contacts/export-csv?tag=${encodeURIComponent(tagOrCity)}&stage=${encodeURIComponent(stage)}`;
}

function renderCrmView() {
  syncStageSelectorsAcrossApp();
  const board = document.getElementById("crm-kanban-board");
  if (!board) return;

  const stages = getCrmStagesList();

  const boardHtml = stages.map(st => {
    const items = appData.contacts.filter(c => (c.crm_stage || "novo") === st.key);
    return `
      <div class="crm-column">
        <div class="crm-col-header" style="border-bottom-color:${st.color};">
          <span style="color:${st.color};">${escapeHtml(st.label)}</span>
          <span class="badge badge-pending">${items.length}</span>
        </div>
        <div class="crm-col-list">
          ${items.map(c => {
            const dispName = (c.social_name && c.social_name.trim()) ? c.social_name.trim() : c.name;
            return `
              <div class="crm-lead-card">
                <div style="font-weight:700; color:var(--text-main);">${escapeHtml(dispName)}</div>
                <div style="font-size:10.5px; color:var(--text-secondary); margin:2px 0 5px;">
                  ${escapeHtml(c.city || c.company || "Sem cidade")}
                </div>
                <div>${renderTagsPillsHtml(c.tags)}</div>
              </div>
            `;
          }).join("")}
        </div>
      </div>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(board, boardHtml);

  const searchTag = (document.getElementById("crm-search-tag")?.value || "").trim().toLowerCase();
  const searchStage = (document.getElementById("crm-search-stage")?.value || "").trim();

  const filtered = appData.contacts.filter(c => {
    if (searchStage && c.crm_stage !== searchStage) return false;
    if (searchTag) {
      const hay = `${c.social_name || ""} ${c.name || ""} ${c.city || ""} ${c.company || ""} ${c.tags || ""} ${c.custom1 || ""}`.toLowerCase();
      if (!hay.includes(searchTag)) return false;
    }
    return true;
  });

  const tbody = document.getElementById("crm-contacts-tbody");
  if (!tbody) return;

  const stageOptionsForRow = (currStage) => stages.map(s =>
    `<option value="${escapeHtml(s.key)}" ${currStage === s.key ? "selected" : ""}>${escapeHtml(s.label)}</option>`
  ).join("");

  const tbodyHtml = filtered.map(c => {
    const dispName = (c.social_name && c.social_name.trim()) ? c.social_name.trim() : c.name;
    return `
      <tr>
        <td>
          <div style="font-weight:700;">${escapeHtml(dispName)}</div>
          <div style="font-size:11px; color:var(--text-muted); font-family:monospace;">+${escapeHtml(c.phone)}</div>
          <input type="text" class="input" value="${escapeHtml(c.social_name || "")}"
            placeholder="Nome Social (Respeitado 100%)"
            style="padding:3px 6px; font-size:10.5px; margin-top:3px; border-color:var(--primary-border);"
            onchange="updateCrmContact(${c.id}, { social_name: this.value })" />
        </td>
        <td style="min-width:190px;">
          ${buildChipAssignSelectHtml(c)}
        </td>
        <td>
          <input type="text" class="input" value="${escapeHtml(c.city || "")}"
            placeholder="Cidade (Vira Etiqueta)"
            style="padding:4px 7px; font-size:11.5px; font-weight:700;"
            onchange="updateCrmContact(${c.id}, { city: this.value })" />
          <div style="font-size:10.5px; color:var(--text-secondary); margin-top:2px;">${escapeHtml(c.company || "")}</div>
        </td>
        <td>
          <input type="text" class="input" value="${escapeHtml(c.custom1 || "")}"
            style="padding:4px 7px; font-size:11.5px;"
            onchange="updateCrmContact(${c.id}, { custom1: this.value })" />
        </td>
        <td>
          <input type="text" class="input" value="${escapeHtml(c.tags || "")}"
            style="padding:4px 7px; font-size:11.5px;"
            onchange="updateCrmContact(${c.id}, { tags: this.value })" />
        </td>
        <td>
          <select class="select" style="padding:4px 7px; font-size:11.5px;"
            onchange="updateCrmContact(${c.id}, { crm_stage: this.value })">
            ${stageOptionsForRow(c.crm_stage || "novo")}
          </select>
        </td>
        <td>
          <button class="btn btn-danger btn-sm" onclick="deleteContact(${c.id})">Excluir</button>
        </td>
      </tr>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(tbody, tbodyHtml);
}

async function updateCrmContact(contactId, payload) {
  await fetch("/api/crm/update-contact", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: contactId, ...payload })
  });
  showToast("Contato atualizado no CRM (Nome Social e Cidade sincronizados)!");
  fetchOverview();
}

/* ============================================================================
   ABA 3: MÚLTIPLOS FLUXOS DE RESPOSTAS AUTOMÁTICAS (POR RESPOSTA + ENVIO ÚNICO)
============================================================================ */
function renderAutoReplyFlowsCatalog() {
  const listEl = document.getElementById("autoreply-flows-catalog-list");
  if (!listEl) return;
  const flows = appData.autoreply_flows || [];
  if (flows.length === 0) {
    updateHtmlPreservingScrollAndFocus(listEl, `
      <div style="text-align:center; color:var(--text-muted); font-size:11.5px; padding:10px;">
        Nenhum fluxo automatico salvo ainda. Preencha os campos abaixo e clique em "Salvar Fluxo Automatico" para criar quantos fluxos desejar!
      </div>
    `);
    return;
  }

  const html = flows.map(f => {
    const kwText = (f.trigger_keywords && f.trigger_keywords !== "*")
      ? `Se responder: "${f.trigger_keywords}"`
      : "Qualquer Resposta (Padrao)";
    const isAct = Number(f.is_active) === 1;
    return `
      <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; padding:7px 10px; background:var(--bg-card); border:1px solid ${isAct ? "var(--primary)" : "var(--border)"}; border-radius:7px;">
        <div style="min-width:0; flex:1;">
          <div style="font-size:12px; font-weight:800; color:var(--text-main);">
            ${escapeHtml(f.name)}
            <span class="badge ${isAct ? "badge-sent" : "badge-pending"}" style="font-size:9.5px; margin-left:5px;">
              ${isAct ? "Ativo (Envio Unico 1/1)" : "Pausado"}
            </span>
          </div>
          <div style="font-size:10.5px; color:var(--text-secondary);">
            ${escapeHtml(kwText)} • Etiqueta: <strong>${escapeHtml(f.auto_tag || "respondeu")}</strong> • Acionado: <strong>${f.triggered_count || 0}x</strong>
          </div>
        </div>
        <div style="display:flex; gap:5px; flex-shrink:0;">
          <button type="button" class="btn btn-outline btn-sm" onclick="loadAutoReplyFlowById(${f.id})">Editar</button>
          <button type="button" class="btn btn-outline btn-sm" onclick="toggleAutoReplyFlowActive(${f.id})">${isAct ? "Pausar" : "Ativar"}</button>
          <button type="button" class="btn btn-danger btn-sm" onclick="deleteAutoReplyFlow(${f.id})">X</button>
        </div>
      </div>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(listEl, html);
}

function startNewAutoReplyFlowForm() {
  const idEl = document.getElementById("ar-flow-id");
  const nameEl = document.getElementById("ar-flow-name");
  const kwEl = document.getElementById("ar-flow-keywords");
  const linkEl = document.getElementById("ar-flow-link");
  const tagEl = document.getElementById("ar-flow-tag");
  if (idEl) idEl.value = "0";
  if (nameEl) nameEl.value = "";
  if (kwEl) kwEl.value = "";
  if (linkEl) linkEl.value = "";
  if (tagEl) tagEl.value = "respondeu";
  autoReplyStepsDraft = [{ step_order: 1, step_title: "Resposta Automatica Unica", delay_sec: 2, base_text: "", variations: [] }];
  renderAutoReplyStepsEditor();
  showToast("Formulario limpo para criar um Novo Fluxo Automatico!");
}

function loadAutoReplyFlowObjectIntoEditor(flowObj) {
  if (!flowObj) return;
  const idEl = document.getElementById("ar-flow-id");
  const nameEl = document.getElementById("ar-flow-name");
  const kwEl = document.getElementById("ar-flow-keywords");
  const linkEl = document.getElementById("ar-flow-link");
  const tagEl = document.getElementById("ar-flow-tag");
  if (idEl) idEl.value = String(flowObj.id || 0);
  if (nameEl) nameEl.value = flowObj.name || "";
  if (kwEl) kwEl.value = flowObj.trigger_keywords || "";
  if (linkEl) linkEl.value = flowObj.flow_link || "";
  if (tagEl) tagEl.value = flowObj.auto_tag || "respondeu";
  try {
    autoReplyStepsDraft = JSON.parse(flowObj.steps_json || "[]");
  } catch (e) {
    autoReplyStepsDraft = [];
  }
  renderAutoReplyStepsEditor();
}

function loadAutoReplyFlowById(flowId) {
  const found = (appData.autoreply_flows || []).find(f => f.id === flowId);
  if (found) {
    loadAutoReplyFlowObjectIntoEditor(found);
    showToast(`Editando fluxo "${found.name}"`);
  }
}

async function toggleAutoReplyFlowActive(flowId) {
  await fetch("/api/autoreply/toggle", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ flow_id: flowId })
  });
  fetchOverview();
}

async function deleteAutoReplyFlow(flowId) {
  await fetch("/api/autoreply/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ flow_id: flowId })
  });
  showToast("Fluxo automatico removido.");
  fetchOverview();
}

async function resetAutoReplyOnceLocks() {
  const res = await fetch("/api/autoreply/reset-once", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({})
  });
  const data = await res.json();
  showToast(data.detail || "Trava de envio unico reiniciada para novos testes!");
}

function renderAutoReplyStepsEditor() {
  const container = document.getElementById("autoreply-steps-container");
  if (!container) return;

  if (!autoReplyStepsDraft || autoReplyStepsDraft.length === 0) {
    autoReplyStepsDraft = [
      {
        step_order: 1,
        step_title: "",
        delay_sec: 2,
        base_text: "",
        variations: []
      }
    ];
  }

  container.innerHTML = autoReplyStepsDraft.map((st, idx) => {
    const varCount = (st.variations && st.variations.length) ? st.variations.length : 6;
    return `
      <div class="autoreply-step-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:7px;">
          <div style="display:flex; align-items:center; gap:8px; width:72%;">
            <span class="badge badge-sent">Etapa ${idx + 1}</span>
            <input type="text" class="input" value="${escapeHtml(st.step_title || "")}" placeholder="Titulo da Etapa ${idx + 1} (Ex: Resposta para Interesse)"
              oninput="autoReplyStepsDraft[${idx}].step_title = this.value"
              style="font-weight:700; padding:5px 8px;" />
          </div>
          <div style="display:flex; align-items:center; gap:6px;">
            <span class="badge badge-pending">${varCount} Variacoes IA</span>
            ${autoReplyStepsDraft.length > 1 ? `<button class="btn btn-danger btn-sm" onclick="removeAutoReplyStep(${idx})">Remover</button>` : ""}
          </div>
        </div>
        <textarea class="textarea" style="min-height:74px;" placeholder="Digite aqui a mensagem de resposta automatica unica da Etapa ${idx + 1}..."
          oninput="autoReplyStepsDraft[${idx}].base_text = this.value; autoReplyStepsDraft[${idx}].variations = null;">${escapeHtml(st.base_text || "")}</textarea>
      </div>
    `;
  }).join("");
}

function addAutoReplyStep() {
  const nextOrder = autoReplyStepsDraft.length + 1;
  autoReplyStepsDraft.push({
    step_order: nextOrder,
    step_title: "",
    delay_sec: 3,
    base_text: "",
    variations: null
  });
  renderAutoReplyStepsEditor();
}

function removeAutoReplyStep(idx) {
  autoReplyStepsDraft.splice(idx, 1);
  renderAutoReplyStepsEditor();
}

async function saveAutoReplyFlow() {
  const flowId = parseInt(document.getElementById("ar-flow-id")?.value || "0", 10) || 0;
  const name = (document.getElementById("ar-flow-name")?.value || "Fluxo Automatico IA").trim();
  const triggerKeywords = (document.getElementById("ar-flow-keywords")?.value || "").trim();
  const flowLink = (document.getElementById("ar-flow-link")?.value || "").trim();
  const autoTag = (document.getElementById("ar-flow-tag")?.value || "respondeu").trim();

  const validSteps = (autoReplyStepsDraft || []).filter(s => s.base_text && s.base_text.trim());
  if (validSteps.length === 0) {
    showToast("Digite o texto da resposta automatica na Etapa 1 antes de salvar.");
    return;
  }

  const res = await fetch("/api/autoreply/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      flow_id: flowId,
      name: name,
      trigger_keywords: triggerKeywords,
      flow_link: flowLink,
      auto_tag: autoTag,
      steps: autoReplyStepsDraft
    })
  });
  const data = await res.json();
  if (data.ok) {
    const idEl = document.getElementById("ar-flow-id");
    if (idEl && data.flow_id) idEl.value = String(data.flow_id);
    showToast(`Fluxo "${name}" salvo e ativo (Envio Unico 1/1 por pessoa)!`);
    fetchOverview();
  }
}

function renderDirectChipSelector() {
  const chipSel = document.getElementById("direct-chip-select");
  if (!chipSel || document.activeElement === chipSel) return;
  const currentChip = chipSel.value;
  const newHtml = (appData.chips || []).map(ch => {
    const statusLbl = ch.live_wa_status === "connected" ? "Conectado" : "Desconectado";
    return `<option value="${ch.id}">${escapeHtml(ch.name)} (+${escapeHtml(ch.phone)}) — [${statusLbl}]</option>`;
  }).join("");
  if (chipSel.innerHTML !== newHtml) {
    chipSel.innerHTML = newHtml;
    if (currentChip) chipSel.value = currentChip;
  }
}

async function sendDirectRealMessage() {
  const chipId = parseInt(document.getElementById("direct-chip-select")?.value || "1", 10);
  const phone = (document.getElementById("direct-phone-input")?.value || "").trim();
  const message = (document.getElementById("direct-msg-input")?.value || "").trim();

  if (!phone) {
    showToast("Digite o numero de WhatsApp de destino com DDD (ex: 5511999998888).");
    return;
  }

  showToast("Enviando mensagem real via WhatsApp Web...");
  const res = await fetch("/api/whatsapp/send-direct", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chip_id: chipId, phone: phone, message: message })
  });
  const data = await res.json();
  if (data.ok) {
    showToast("Mensagem enviada com sucesso no WhatsApp real!");
    fetchOverview();
  } else {
    showToast(data.error || data.detail || "Falha ao enviar. Verifique se o chip esta conectado via QR Code.");
  }
}

function renderAutoReplyFeed() {
  const feed = document.getElementById("autoreply-feed-list");
  if (!feed) return;
  const logs = appData.autoreply_logs || [];
  if (logs.length === 0) {
    updateHtmlPreservingScrollAndFocus(feed, `
      <div style="text-align:center; color:var(--text-muted); padding:24px; font-size:12px;">
        Nenhuma resposta automatica disparada ainda. Assim que um contato responder em um chip conectado, o registro de envio unico (1/1) aparecera aqui.
      </div>
    `);
    return;
  }
  const html = logs.map(l => `
    <div class="sent-card">
      <div class="sent-card-meta">
        <span>Contato: <strong>${escapeHtml(l.contact_name)}</strong> (+${escapeHtml(l.contact_phone)})</span>
        <span>${escapeHtml(l.chip_name)}</span>
      </div>
      <div class="sent-card-body">${escapeHtml(l.rendered_message)}</div>
    </div>
  `).join("");
  updateHtmlPreservingScrollAndFocus(feed, html);
}

/* ============================================================================
   ABA 4 & 5: CENTRAL DE CHIPS (1 A 100) E AQUECIMENTO COORDENADO ENTRE CHIPS
============================================================================ */
function renderChipsTab() {
  const grid = document.getElementById("chips-cards-grid");
  if (!grid) return;

  const activeTotal = (appData.chips || []).length;
  const connectedTotal = (appData.chips || []).filter(c => c.live_wa_status === "connected").length;
  const countBadge = document.getElementById("lbl-chips-active-count");
  if (countBadge) {
    countBadge.textContent = `${activeTotal} / 100 cadastrados (${connectedTotal} conectados agora)`;
  }

  if (activeTotal === 0) {
    updateHtmlPreservingScrollAndFocus(grid, `
      <div style="grid-column: 1 / -1; text-align:center; padding:42px 20px; border:1px dashed var(--border-strong); border-radius:10px; color:var(--text-secondary);">
        <div style="font-size:14px; font-weight:700; color:var(--text-main); margin-bottom:6px;">Nenhum chip cadastrado ainda</div>
        <div style="font-size:12.5px; margin-bottom:14px;">Clique no botao abaixo para cadastrar seu primeiro chip real (Slot #1) e ler o QR Code.</div>
        <button class="btn btn-primary" onclick="openChipModal()">+ Cadastrar Novo Chip Real</button>
      </div>
    `);
    return;
  }

  const html = appData.chips.map((c, idx) => {
    const isConnected = c.live_wa_status === "connected";
    const statusText = isConnected ? "WhatsApp Conectado" : "Desconectado (Ler QR)";
    const statusBadgeClass = isConnected ? "badge-sent" : "badge-warn";

    return `
      <div class="panel" style="padding:14px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
          <span style="font-size:11px; font-weight:700; color:var(--text-secondary);">CHIP ATIVO ${idx + 1} DE ${activeTotal} • Slot #${c.id} (Usado em {{nome do chip}})</span>
          <span class="badge ${statusBadgeClass}">${statusText}</span>
        </div>

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:6px; margin-bottom:9px;">
          <div>
            <label style="font-size:10.5px; font-weight:600; color:var(--text-secondary); display:block; margin-bottom:2px;">Nome do Chip / Operador</label>
            <input type="text" id="edit-chip-name-${c.id}" class="input" value="${escapeHtml(c.name)}" style="padding:5px 8px; font-weight:700;" onkeydown="if(event.key==='Enter') updateChipDetails(${c.id})" />
          </div>
          <div>
            <label style="font-size:10.5px; font-weight:600; color:var(--text-secondary); display:block; margin-bottom:2px;">Numero WhatsApp</label>
            <input type="text" id="edit-chip-phone-${c.id}" class="input" value="${escapeHtml(c.phone)}" style="padding:5px 8px; font-family:monospace;" onkeydown="if(event.key==='Enter') updateChipDetails(${c.id})" />
          </div>
        </div>

        <div style="background:var(--bg-subtle); border:1px solid var(--border); border-radius:8px; padding:8px; margin-bottom:10px; font-size:11.5px;">
          <div style="display:flex; justify-content:space-between; margin-bottom:3px;">
            <span style="color:var(--text-secondary);">Maturacao:</span>
            <strong>Dia ${c.warmup_day} de 30 (Limite: ${c.daily_limit}/dia)</strong>
          </div>
          <div style="display:flex; justify-content:space-between;">
            <span style="color:var(--text-secondary);">Enviadas / Recebidas Hoje:</span>
            <strong>${c.sent_today} env / ${c.received_today || 0} rec</strong>
          </div>
        </div>

        <div style="display:flex; gap:6px;">
          <button class="btn btn-outline btn-sm" onclick="updateChipDetails(${c.id})">Salvar Nome</button>
          <button class="btn btn-primary" style="flex:1;" onclick="openQrModal(${c.id})">
            ${isConnected ? "Ver Sessao WhatsApp" : "Conectar QR Code"}
          </button>
          <button class="btn btn-danger btn-sm" onclick="deleteChip(${c.id})">X</button>
        </div>
      </div>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(grid, html);
}

async function updateChipDetails(chipId) {
  const nameEl = document.getElementById(`edit-chip-name-${chipId}`);
  const phoneEl = document.getElementById(`edit-chip-phone-${chipId}`);
  const name = (nameEl?.value || "").trim();
  const phone = (phoneEl?.value || "").trim();
  if (!name) {
    showToast("Informe o nome do chip (ex: Gabriel, Michelle).");
    return;
  }
  if (nameEl) nameEl.blur();
  if (phoneEl) phoneEl.blur();
  await fetch("/api/chips/update", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: chipId, name: name, phone: phone })
  });
  showToast(`Chip atualizado para "${name}" (+${phone})!`);
  fetchOverview();
}

function renderWarmupTab() {
  const banner = document.getElementById("warmup-status-banner");
  const btnStart = document.getElementById("btn-warmup-start");
  const btnStop = document.getElementById("btn-warmup-stop");

  if (appData.warmup_state) {
    if (banner) banner.textContent = appData.warmup_state.status_text;
    if (btnStart) btnStart.style.display = appData.warmup_state.is_running ? "none" : "inline-flex";
    if (btnStop) btnStop.style.display = appData.warmup_state.is_running ? "inline-flex" : "none";
  }

  const tbody = document.getElementById("warmup-tbody");
  if (tbody) {
    const rowsHtml = appData.chips.map(c => {
      const isConnected = c.live_wa_status === "connected";
      return `
        <tr>
          <td><strong>${escapeHtml(c.name)}</strong><br/><span style="font-size:11px; color:var(--text-muted); font-family:monospace;">+${escapeHtml(c.phone)}</span></td>
          <td>${isConnected ? `<span class="badge badge-sent">Conectado</span>` : `<span class="badge badge-warn">Desconectado</span>`}</td>
          <td><span class="badge badge-pending">Dia ${c.warmup_day} / 30</span></td>
          <td><strong>${c.sent_today}</strong> env / <strong>${c.received_today || 0}</strong> rec</td>
          <td>
            <button class="btn btn-outline btn-sm" onclick="openQrModal(${c.id})">Conectar QR</button>
          </td>
        </tr>
      `;
    }).join("");
    updateHtmlPreservingScrollAndFocus(tbody, rowsHtml);
  }

  const wFeed = document.getElementById("warmup-feed-list");
  if (wFeed) {
    const logs = appData.warmup_logs || [];
    if (logs.length === 0) {
      updateHtmlPreservingScrollAndFocus(wFeed, `
        <div style="text-align:center; color:var(--text-muted); padding:28px; font-size:12px;">
          Conecte 2, 3 ou mais chips via QR Code e clique em "Iniciar Aquecimento Real" para que eles conversem em dialogos coordenados em duplas no WhatsApp.
        </div>
      `);
    } else {
      const feedHtml = logs.map(l => `
        <div class="sent-card">
          <div class="sent-card-meta">
            <span>De: <strong>${escapeHtml(l.chip_name)}</strong></span>
            <span>Para: <strong>${escapeHtml(l.contact_name)}</strong> (+${escapeHtml(l.contact_phone)})</span>
          </div>
          <div class="sent-card-body">${escapeHtml(l.rendered_message)}</div>
        </div>
      `).join("");
      updateHtmlPreservingScrollAndFocus(wFeed, feedHtml);
    }
  }
}

async function controlWarmup(action) {
  await fetch("/api/warmup/control", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: action })
  });
  fetchOverview();
}

/* ============================================================================
   MODAL DE QR CODE AO VIVO E IMPORTADOR DE ARQUIVOS .CSV / .TXT
============================================================================ */
async function openQrModal(chipId) {
  qrActiveChipId = chipId;
  const modal = document.getElementById("modal-qr");
  const placeholder = document.getElementById("qr-loading-placeholder");
  const img = document.getElementById("qr-live-image");
  const title = document.getElementById("qr-modal-title");
  const badge = document.getElementById("qr-modal-badge");

  if (modal) modal.style.display = "flex";
  if (placeholder) placeholder.style.display = "block";
  if (img) img.style.display = "none";
  if (title) title.textContent = `Conexao Real WhatsApp Web — Chip #${chipId}`;
  if (badge) {
    badge.className = "badge badge-warn";
    badge.textContent = "Iniciando sessao...";
  }

  await fetch("/api/chips/open-whatsapp", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chip_id: chipId })
  });

  if (qrModalTimer) clearInterval(qrModalTimer);
  pollQrLiveFrame();
  qrModalTimer = setInterval(pollQrLiveFrame, 1400);
}

async function pollQrLiveFrame() {
  if (!qrActiveChipId) return;
  try {
    const res = await fetch(`/api/chips/qr-live?chip_id=${qrActiveChipId}`);
    if (!res.ok) return;
    const data = await res.json();

    const placeholder = document.getElementById("qr-loading-placeholder");
    const img = document.getElementById("qr-live-image");
    const badge = document.getElementById("qr-modal-badge");
    const subtitle = document.getElementById("qr-modal-subtitle");

    const imgSrc = data.screenshot || (data.screenshot_b64 ? "data:image/jpeg;base64," + data.screenshot_b64 : null);
    if (imgSrc && img) {
      img.src = imgSrc;
      img.style.display = "block";
      if (placeholder) placeholder.style.display = "none";
    }

    const st = data.state || data.status;
    if (st === "connected") {
      if (badge) {
        badge.className = "badge badge-sent";
        badge.textContent = "WhatsApp Conectado!";
      }
      if (subtitle) subtitle.textContent = "Sessao autenticada e pronta para realizar disparos reais.";
    } else if (st === "qr_ready") {
      if (badge) {
        badge.className = "badge badge-warn";
        badge.textContent = "Escaneie o QR Code abaixo";
      }
      if (subtitle) subtitle.textContent = "Aponte a camera do seu WhatsApp para o QR Code na tela.";
    }
  } catch (e) {
    console.error("Erro ao capturar QR:", e);
  }
}

function closeQrModal() {
  qrActiveChipId = null;
  if (qrModalTimer) {
    clearInterval(qrModalTimer);
    qrModalTimer = null;
  }
  closeModal("modal-qr");
}

function openImportModal() {
  document.getElementById("modal-import").style.display = "flex";
}

function onImportCsvFileSelected(inputEl) {
  const file = inputEl?.files?.[0];
  if (!file) return;
  const stEl = document.getElementById("import-csv-file-status");
  const area = document.getElementById("import-raw-text");

  const reader = new FileReader();
  reader.onload = (ev) => {
    let text = String(ev.target?.result || "");
    if (area) area.value = text;
    const lineCount = text.split(/\r?\n/).filter(l => l.trim()).length;
    if (stEl) {
      stEl.textContent = `Planilha "${file.name}" carregada (${lineCount} linha(s)). Clique em "Importar Respeitando Nome Social e Cidade" abaixo!`;
      stEl.style.color = "var(--primary)";
      stEl.style.fontWeight = "700";
    }
    showToast(`Planilha "${file.name}" carregada! Clique em Importar para salvar.`);
  };
  reader.readAsText(file, "UTF-8");
}

function openChipModal() {
  document.getElementById("modal-chip").style.display = "flex";
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = "none";
}

async function processAiImport() {
  const rawText = document.getElementById("import-raw-text").value;
  const defaultTag = document.getElementById("import-default-tag")?.value || "importado";
  if (!rawText.trim()) {
    showToast("Selecione um arquivo .CSV/.TXT ou cole pelo menos 1 contato para importar.");
    return;
  }
  const res = await fetch("/api/contacts/ai-import", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ raw_text: rawText, default_tag: defaultTag })
  });
  const data = await res.json();
  if (data.ok) {
    closeModal("modal-import");
    const st = data.ai_stats || {};
    const socialInfo = st.social_names_applied > 0 ? ` • ${st.social_names_applied} Nome(s) Social(is) aplicado(s)` : "";
    const cityInfo = st.city_tags_applied > 0 ? ` • ${st.city_tags_applied} Cidade(s) convertida(s) em Etiqueta` : "";
    showToast(`${data.imported} contato(s) importado(s)${socialInfo}${cityInfo}!`);
    fetchOverview();
  }
}

async function saveNewChip() {
  const name = document.getElementById("new-chip-name").value || "Novo Chip";
  const phone = document.getElementById("new-chip-phone").value || "5511999999999";
  const day = parseInt(document.getElementById("new-chip-day").value || "1", 10);

  const res = await fetch("/api/chips/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, phone, warmup_day: day, open_whatsapp_now: false })
  });
  const data = await res.json();
  closeModal("modal-chip");
  await fetchOverview();
  if (data.chip_id) {
    selectedChipIds.add(data.chip_id);
    openQrModal(data.chip_id);
  }
}

async function deleteChip(id) {
  await fetch("/api/chips/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  selectedChipIds.delete(id);
  fetchOverview();
}

async function deleteContact(id) {
  await fetch("/api/contacts/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  fetchOverview();
}

async function clearAllContacts() {
  await fetch("/api/contacts/clear-all", { method: "POST" });
  showToast("Base de contatos limpa. Suba seus contatos reais quando desejar.");
  fetchOverview();
}

async function clearSystemLogs() {
  await fetch("/api/system/clear-logs", { method: "POST" });
  showToast("Historico de campanhas e logs limpo.");
  fetchOverview();
}

/* ============================================================================
   AGRUPAMENTO DE JANELAS EM 1 ÚNICO BLOCO NA BARRA DE TAREFAS DO WINDOWS
============================================================================ */
async function regroupTaskbarWindows(minimize = false) {
  const res = await fetch("/api/system/regroup-taskbar", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ minimize: minimize })
  });
  const data = await res.json();
  showToast(data.detail || "Janelas externas do Chrome encerradas! Tudo rodando 100% interno e leve dentro do programa.");
  refreshWhatsAppMonitorNow(true);
}

/* ============================================================================
   ABA 6: GRUPOS DE WHATSAPP (EXTRAÇÃO DIRETA DA LISTA, EXPORTAÇÃO E DISPARO)
============================================================================ */
let extractedGroupMembersState = [];
let currentExtractedGroupName = "";
let currentExtractedGroupTag = "";

function selectGroupVarTab(idx, btnElement) {
  activeGroupVarIdx = idx;
  document.querySelectorAll("#group-var-tabs-container .group-var-tab").forEach(b => b.classList.remove("active"));
  if (btnElement) btnElement.classList.add("active");

  const styleLbl = VARIATION_STYLE_LABELS[idx] || `V${idx + 1}`;
  const ind = document.getElementById("group-active-var-indicator");
  if (ind) ind.textContent = `Editando / Visualizando: ${styleLbl}`;

  const grpCohStyle = document.getElementById("group-cohesion-style-label");
  if (grpCohStyle) grpCohStyle.textContent = `Estilo Ativo: ${styleLbl}`;

  const editor = document.getElementById("group-dispatch-message");
  if (editor) editor.value = groupVariationsState[idx] || "";
  updateGroupLivePreview();
}

function onGroupEditorInput() {
  const editor = document.getElementById("group-dispatch-message");
  if (!editor) return;
  const val = editor.value;
  if (activeGroupVarIdx === 0) {
    groupVariationsState = buildClientSide15Variations(val);
    const ind = document.getElementById("group-active-var-indicator");
    if (ind) {
      ind.textContent = val.trim()
        ? "15 Variacoes de Alto Nivel (V1..V15) geradas com Coesao & Coerencia!"
        : "Digite sua mensagem para gerar V1..V15";
    }
  } else {
    groupVariationsState[activeGroupVarIdx] = enforceClientCohesionAndCoherence(val);
  }
  updateGroupLivePreview();
}

function insertGroupVariable(tag) {
  const editor = document.getElementById("group-dispatch-message");
  if (!editor) return;
  const start = editor.selectionStart || 0;
  const end = editor.selectionEnd || 0;
  const current = editor.value;
  editor.value = current.slice(0, start) + tag + current.slice(end);
  onGroupEditorInput();
  editor.focus();
}

function updateGroupLivePreview() {
  const previewBox = document.getElementById("group-live-preview-box");
  if (!previewBox) return;
  const currentTemplate = groupVariationsState[activeGroupVarIdx] || "";
  if (!currentTemplate.trim()) {
    previewBox.innerHTML = `<div style="font-size:11.5px; color:var(--text-muted);">Digite sua mensagem acima para visualizar a previa real com o 1o contato do grupo e o Card de Previa do Link no WhatsApp.</div>`;
    return;
  }
  const firstWithRealName = (extractedGroupMembersState || []).find(m => m.name && m.name.trim()) || extractedGroupMembersState[0] || {
    name: "Paulo",
    group_name: currentExtractedGroupName || "Grupo"
  };
  const customLink = (document.getElementById("group-dispatch-link")?.value || "").trim();
  const rendered = renderTemplateClientSide(currentTemplate, firstWithRealName, customLink);
  previewBox.innerHTML = buildWhatsAppRichPreviewHtml(rendered);
}

async function generateGroup15Variations(notify = true) {
  const editorVal = (document.getElementById("group-dispatch-message")?.value || "").trim();
  const baseText = editorVal || groupVariationsState[activeGroupVarIdx] || groupVariationsState[0] || "";
  if (!baseText.trim()) {
    if (notify) showToast("Digite sua mensagem no campo antes de gerar as 15 variacoes.");
    return;
  }
  const res = await fetch("/api/ai/generate-variations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ base_template: baseText, count: 15 })
  });
  const data = await res.json();
  if (data.variations && data.variations.length >= 15) {
    groupVariationsState = data.variations.slice(0, 15);
    const editor = document.getElementById("group-dispatch-message");
    if (editor) editor.value = groupVariationsState[activeGroupVarIdx];
    updateGroupLivePreview();
    if (notify) showToast("15 variacoes (V1 a V15) geradas a partir da sua mensagem!");
  }
}

function renderGroupExtractorChipSelector() {
  const sel = document.getElementById("group-extractor-chip-select");
  if (!sel) return;
  const prevVal = sel.value;
  sel.innerHTML = (appData.chips || []).map(c => {
    const st = c.live_wa_status === "connected" ? "Conectado" : "Desconectado";
    return `<option value="${c.id}">${escapeHtml(c.name)} (+${escapeHtml(c.phone)}) — [${st}]</option>`;
  }).join("");
  if (prevVal && Array.from(sel.options).some(o => o.value === prevVal)) {
    sel.value = prevVal;
  }
}

async function scanWhatsappGroups(filterGroups = false) {
  const chipId = parseInt(document.getElementById("group-extractor-chip-select")?.value || "1", 10);
  const listEl = document.getElementById("whatsapp-groups-list");
  if (listEl) {
    listEl.innerHTML = `<div style="text-align:center; color:var(--text-secondary); padding:14px; font-size:12px;">Lendo todos os grupos diretamente do banco interno do WhatsApp Web...</div>`;
  }

  const res = await fetch("/api/groups/list", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chip_id: chipId, filter_groups: filterGroups })
  });
  const data = await res.json();
  if (!data.ok) {
    showToast(data.detail || "Conecte o chip via QR Code primeiro.");
    if (listEl) {
      listEl.innerHTML = `<div style="text-align:center; color:var(--danger); padding:14px; font-size:12px;">${escapeHtml(data.detail || "Chip desconectado. Conecte via QR Code primeiro.")}</div>`;
    }
    return;
  }

  const groups = data.groups || [];
  if (groups.length === 0) {
    if (listEl) {
      listEl.innerHTML = `<div style="text-align:center; color:var(--text-muted); padding:14px; font-size:12px;">Nenhum grupo encontrado nesta conta do WhatsApp. Verifique se o chip escolhido possui grupos.</div>`;
    }
    return;
  }

  if (listEl) {
    listEl.innerHTML = groups.map(g => {
      const safeName = JSON.stringify(g.name || "").replace(/"/g, "&quot;");
      const safeId = JSON.stringify(g.id || "").replace(/"/g, "&quot;");
      const countBadge = g.members_count > 0
        ? `<span class="badge badge-sent" style="margin-left:6px;">${g.members_count} membros</span>`
        : "";
      return `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:7px 8px; border-bottom:1px solid var(--border); gap:8px;">
          <div style="min-width:0; flex:1;">
            <div style="font-size:12.5px; font-weight:700; color:var(--text-main); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
              ${escapeHtml(g.name)} ${countBadge}
            </div>
            <div style="font-size:10.5px; color:var(--text-muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
              ${escapeHtml(g.preview || "Grupo do WhatsApp")}
            </div>
          </div>
          <div style="display:flex; gap:5px; flex-shrink:0;">
            <button class="btn btn-primary btn-sm" onclick="extractContactsFromGroup(${safeName}, ${safeId})">2. Extrair Todos os Contatos</button>
          </div>
        </div>
      `;
    }).join("");
  }
  showToast(`${groups.length} grupo(s) carregado(s) diretamente do WhatsApp! Clique em "2. Extrair Todos os Contatos" no grupo desejado.`);
}

async function extractContactsFromGroup(groupName = "", groupId = "") {
  const chipId = parseInt(document.getElementById("group-extractor-chip-select")?.value || "1", 10);
  showToast(`Extraindo todos os contatos e nomes reais do grupo "${groupName || "selecionado"}"...`);

  const res = await fetch("/api/groups/extract", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chip_id: chipId,
      group_name: groupName,
      group_id: groupId,
      save_to_crm: false
    })
  });
  const data = await res.json();
  if (!data.ok) {
    showToast(data.detail || "Nao foi possivel extrair contatos. Verifique se o chip esta conectado.");
    return;
  }

  extractedGroupMembersState = data.members || [];
  currentExtractedGroupName = data.group_name || groupName || "Grupo WhatsApp";
  currentExtractedGroupTag = data.group_tag || currentExtractedGroupName;

  const countBadge = document.getElementById("lbl-extracted-group-count");
  if (countBadge) countBadge.textContent = `${extractedGroupMembersState.length} extraidos`;

  const grpNameLbl = document.getElementById("lbl-current-group-name");
  if (grpNameLbl) grpNameLbl.textContent = `${currentExtractedGroupName} (${extractedGroupMembersState.length} contatos)`;

  const dispName = document.getElementById("group-dispatch-name");
  const dispTag = document.getElementById("group-dispatch-tag");
  if (dispName) dispName.value = currentExtractedGroupName;
  if (dispTag) dispTag.value = currentExtractedGroupTag;

  renderExtractedGroupMembersTable();
  updateGroupLivePreview();
  showToast(`${extractedGroupMembersState.length} contato(s) extraido(s) do grupo "${currentExtractedGroupName}"!`);
}

function renderExtractedGroupMembersTable() {
  const tbody = document.getElementById("extracted-group-contacts-tbody");
  if (!tbody) return;
  if (!extractedGroupMembersState || extractedGroupMembersState.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4" style="text-align:center; color:var(--text-muted); padding:24px;">
          Nenhum participante extraido ainda. Clique em "1. Carregar Lista de Grupos do Chip" e depois em "2. Extrair Todos os Contatos".
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = extractedGroupMembersState.map(m => {
    const displayName = m.name && m.name.trim()
      ? `<strong>${escapeHtml(m.name)}</strong>`
      : `<span style="color:var(--text-muted); font-size:11px;">Sem nome publico no WhatsApp</span>`;
    return `
      <tr>
        <td>${displayName}</td>
        <td style="font-family:monospace; font-weight:700; color:var(--primary);">+${escapeHtml(m.phone)}</td>
        <td>${escapeHtml(m.group_name)}</td>
        <td><span class="tag-pill">${escapeHtml(m.tag || currentExtractedGroupTag)}</span></td>
      </tr>
    `;
  }).join("");
}

function exportGroupContactsCsv() {
  if (!extractedGroupMembersState || extractedGroupMembersState.length === 0) {
    showToast("Extraia os contatos de um grupo primeiro antes de baixar a planilha .CSV.");
    return;
  }
  const tagVal = (document.getElementById("group-dispatch-tag")?.value || currentExtractedGroupTag || "Grupo").trim();
  const header = "Nome;Telefone;Grupo;Etiqueta\r\n";
  const rows = extractedGroupMembersState.map(m =>
    `"${(m.name || "").replace(/"/g, '""')}";"${m.phone}";"${(m.group_name || "").replace(/"/g, '""')}";"${tagVal.replace(/"/g, '""')}"`
  ).join("\r\n");

  const blob = new Blob(["\uFEFF" + header + rows], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `contatos_${tagVal.replace(/[^a-zA-Z0-9_-]+/g, "_")}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast(`Planilha CSV com ${extractedGroupMembersState.length} contatos baixada com sucesso!`);
}

function exportGroupContactsTxt() {
  if (!extractedGroupMembersState || extractedGroupMembersState.length === 0) {
    showToast("Extraia os contatos de um grupo primeiro antes de baixar o arquivo .TXT.");
    return;
  }
  const tagVal = (document.getElementById("group-dispatch-tag")?.value || currentExtractedGroupTag || "Grupo").trim();
  const lines = extractedGroupMembersState.map(m =>
    `${m.name || ""}, ${m.phone}, ${m.group_name}, , ${tagVal}`
  ).join("\r\n");

  const blob = new Blob([lines], { type: "text/plain;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `contatos_${tagVal.replace(/[^a-zA-Z0-9_-]+/g, "_")}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast(`Lista TXT com ${extractedGroupMembersState.length} contatos baixada!`);
}

async function saveExtractedGroupToCrm() {
  if (!extractedGroupMembersState || extractedGroupMembersState.length === 0) {
    showToast("Extraia os contatos de um grupo primeiro para salva-los no CRM.");
    return;
  }
  const chipId = parseInt(document.getElementById("group-extractor-chip-select")?.value || "1", 10);
  const tagVal = (document.getElementById("group-dispatch-tag")?.value || currentExtractedGroupTag || currentExtractedGroupName || "Grupo").trim();

  const res = await fetch("/api/groups/extract", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chip_id: chipId,
      group_name: currentExtractedGroupName,
      group_tag: tagVal,
      save_to_crm: true
    })
  });
  const data = await res.json();
  if (data.ok) {
    showToast(`${extractedGroupMembersState.length} contato(s) salvos no CRM com a etiqueta "${tagVal}"!`);
    fetchOverview();
  }
}

async function launchGroupDirectDispatch() {
  const mode = document.getElementById("group-dispatch-mode")?.value || "members_pv";
  const groupName = (document.getElementById("group-dispatch-name")?.value || currentExtractedGroupName || "Grupo WhatsApp").trim();
  const groupTag = (document.getElementById("group-dispatch-tag")?.value || currentExtractedGroupTag || groupName).trim();
  const link = (document.getElementById("group-dispatch-link")?.value || "").trim();
  const minDelay = parseInt(document.getElementById("group-delay-min")?.value || "3", 10);
  const maxDelay = parseInt(document.getElementById("group-delay-max")?.value || "7", 10);
  const typedMsg = (document.getElementById("group-dispatch-message")?.value || "").trim();
  const baseMsg = (groupVariationsState[0] || typedMsg).trim();
  const extractorChipId = parseInt(document.getElementById("group-extractor-chip-select")?.value || "1", 10);

  if (!baseMsg) {
    showToast("Digite a sua mensagem no campo antes de iniciar o disparo!");
    return;
  }

  if (mode === "members_pv" && (!extractedGroupMembersState || extractedGroupMembersState.length === 0)) {
    showToast("Extraia os contatos de um grupo na Coluna 1 antes de disparar no privado dos membros!");
    return;
  }

  const activeVariations = groupVariationsState.filter(v => v && v.trim()).length >= 15
    ? groupVariationsState
    : buildClientSide15Variations(baseMsg);

  const chipIds = selectedChipIds.size > 0 ? Array.from(selectedChipIds) : [extractorChipId];

  const res = await fetch("/api/groups/dispatch", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      mode: mode,
      chip_id: extractorChipId,
      chip_ids: chipIds,
      group_name: groupName,
      group_tag: groupTag,
      link: link,
      min_delay_sec: minDelay,
      max_delay_sec: maxDelay,
      message: baseMsg,
      variations: activeVariations,
      members: extractedGroupMembersState,
      target_groups: [groupName || "__OPEN__"]
    })
  });
  const data = await res.json();
  if (data.ok) {
    showToast(data.detail || "Disparo de grupo iniciado com sucesso!");
    fetchOverview();
    if (mode === "members_pv") {
      switchTab("tab-workspace", document.querySelectorAll(".side-nav-link")[0]);
    }
  } else {
    showToast(data.detail || "Nao foi possivel concluir o disparo de grupo.");
  }
}

/* ============================================================================
   ABA 7: LOGIN, SENHA, AUTORIZAÇÃO PELO ADMIN E PIX RECORRENTE GRATUITO
============================================================================ */

function checkAuthSession() {
  const gate = document.getElementById("auth-gate-overlay");
  if (!gate) return;
  try {
    const raw = localStorage.getItem("nexzap_auth_user");
    if (raw) {
      const user = JSON.parse(raw);
      if (user && user.username && user.status === "authorized") {
        gate.style.display = "none";
        updateLoggedUserBadge(user);
        return;
      }
    }
  } catch (e) {}
  gate.style.display = "flex";
}

function updateLoggedUserBadge(user) {
  const badge = document.getElementById("logged-user-badge");
  if (!badge || !user) return;
  const fullName = String(user.full_name || user.username || "").trim();
  const roleTag = user.role === "admin" ? "Admin Master" : "Autorizado";
  const alreadyHasAdmin = /administrador|admin/i.test(fullName);
  badge.textContent = alreadyHasAdmin
    ? `Operador: ${fullName}`
    : `Operador: ${fullName} (${roleTag})`;
}

function switchAuthTab(tab) {
  const btnLogin = document.getElementById("btn-auth-tab-login");
  const btnReq = document.getElementById("btn-auth-tab-request");
  const btnChg = document.getElementById("btn-auth-tab-change");
  const formLogin = document.getElementById("auth-form-login");
  const formReq = document.getElementById("auth-form-request");
  const formChg = document.getElementById("auth-form-change");
  const alertEl = document.getElementById("auth-status-alert");
  if (alertEl) alertEl.style.display = "none";

  if (btnLogin) btnLogin.classList.toggle("active", tab === "login");
  if (btnReq) btnReq.classList.toggle("active", tab === "request");
  if (btnChg) btnChg.classList.toggle("active", tab === "change");

  if (formLogin) formLogin.style.display = tab === "login" ? "block" : "none";
  if (formReq) formReq.style.display = tab === "request" ? "block" : "none";
  if (formChg) formChg.style.display = tab === "change" ? "block" : "none";
}

async function submitOwnCredentialsChangeFromGate() {
  const currUser = (document.getElementById("chg-curr-username")?.value || "").trim().toLowerCase();
  const currPass = (document.getElementById("chg-curr-password")?.value || "").trim();
  const newUser = (document.getElementById("chg-new-username")?.value || "").trim().toLowerCase();
  const newPass = (document.getElementById("chg-new-password")?.value || "").trim();
  const alertEl = document.getElementById("auth-status-alert");

  if (!currUser || !currPass) {
    if (alertEl) {
      alertEl.textContent = "Informe seu Login Atual e sua Senha Atual para validar a troca.";
      alertEl.style.display = "block";
    }
    return;
  }
  if (!newUser && !newPass) {
    if (alertEl) {
      alertEl.textContent = "Preencha o Novo Login (Usuario) e/ou a Nova Senha desejada.";
      alertEl.style.display = "block";
    }
    return;
  }

  const res = await fetch("/api/auth/change-own-credentials", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      current_username: currUser,
      current_password: currPass,
      new_username: newUser,
      new_password: newPass
    })
  });
  const data = await res.json();
  if (data.ok && data.user) {
    localStorage.setItem("nexzap_auth_user", JSON.stringify(data.user));
    updateLoggedUserBadge(data.user);
    const loginUserEl = document.getElementById("login-username");
    const loginPassEl = document.getElementById("login-password");
    if (loginUserEl) loginUserEl.value = data.user.username;
    if (loginPassEl && newPass) loginPassEl.value = newPass;
    showToast(data.detail || "Login e senha alterados com sucesso!");
    switchAuthTab("login");
    if (alertEl) {
      alertEl.textContent = data.detail || "Credenciais alteradas com sucesso! Clique em Acessar Plataforma.";
      alertEl.style.display = "block";
    }
    fetchOverview();
  } else if (alertEl) {
    alertEl.textContent = data.error || "Nao foi possivel alterar o login/senha.";
    alertEl.style.display = "block";
  }
}

function fillMasterAdminLogin() {
  const u = document.getElementById("login-username");
  const p = document.getElementById("login-password");
  if (u) u.value = "gabriel";
  if (p) p.value = "admin123";
  submitLogin();
}

let pendingCheckoutUsername = "";

function renderAuthPixCheckout(pixInfo, targetUsername) {
  const box = document.getElementById("auth-pix-checkout-box");
  if (!box) return;
  if (targetUsername) pendingCheckoutUsername = targetUsername;
  if (!pixInfo || !pixInfo.emv_payload) {
    box.style.display = "none";
    return;
  }
  box.style.display = "block";
  const titleEl = document.getElementById("auth-pix-plan-title");
  const amtEl = document.getElementById("auth-pix-amount-badge");
  const bankBadgeEl = document.getElementById("auth-pix-bank-badge");
  const instEl = document.getElementById("auth-pix-instructions");
  const emvEl = document.getElementById("auth-pix-emv-textarea");
  const btnAutoComp = document.getElementById("btn-auth-auto-compensate");

  if (titleEl) titleEl.textContent = pixInfo.plan_title || "Assinatura Mensal Recorrente — PIX";
  if (amtEl) amtEl.textContent = `R$ ${pixInfo.monthly_amount || "97.00"} / mes`;
  if (bankBadgeEl) {
    bankBadgeEl.textContent = pixInfo.selected_bank_name
      ? pixInfo.selected_bank_name.split("(")[0].trim()
      : "Banco Central EMV";
  }
  if (instEl && pixInfo.instructions) instEl.textContent = pixInfo.instructions;
  if (emvEl) emvEl.value = pixInfo.emv_payload;

  if (btnAutoComp) {
    const mode = pixInfo.pix_operation_mode || "both";
    btnAutoComp.style.display = mode === "direct_free" ? "none" : "inline-flex";
  }
}

function copyAuthPixCode() {
  const emvEl = document.getElementById("auth-pix-emv-textarea");
  if (!emvEl || !emvEl.value) return;
  navigator.clipboard.writeText(emvEl.value).catch(() => {});
  showToast("Codigo PIX Copia e Cola copiado! Cole no aplicativo do seu banco.");
}

function validateClientCpfOrCnpj(raw) {
  const d = String(raw || "").replace(/\D/g, "");
  if (d.length === 11) {
    if (/^(\d)\1{10}$/.test(d)) return false;
    for (let t = 9; t < 11; t++) {
      let sum = 0;
      for (let i = 0; i < t; i++) sum += parseInt(d[i], 10) * ((t + 1) - i);
      const rev = ((sum * 10) % 11) % 10;
      if (rev !== parseInt(d[t], 10)) return false;
    }
    return true;
  }
  if (d.length === 14) {
    if (/^(\d)\1{13}$/.test(d)) return false;
    const w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    let s1 = 0;
    for (let i = 0; i < 12; i++) s1 += parseInt(d[i], 10) * w1[i];
    const r1 = s1 % 11;
    const d1 = r1 < 2 ? 0 : 11 - r1;
    if (parseInt(d[12], 10) !== d1) return false;
    let s2 = 0;
    for (let i = 0; i < 13; i++) s2 += parseInt(d[i], 10) * w2[i];
    const r2 = s2 % 11;
    const d2 = r2 < 2 ? 0 : 11 - r2;
    return parseInt(d[13], 10) === d2;
  }
  return false;
}

function formatAndValidateDocInput(inputEl) {
  if (!inputEl) return;
  const d = inputEl.value.replace(/\D/g, "").slice(0, 14);
  if (d.length <= 11) {
    inputEl.value = d
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
  } else {
    inputEl.value = d
      .replace(/^(\d{2})(\d)/, "$1.$2")
      .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
      .replace(/\.(\d{3})(\d)/, ".$1/$2")
      .replace(/(\d{4})(\d)/, "$1-$2");
  }
  if (d.length === 11 || d.length === 14) {
    const ok = validateClientCpfOrCnpj(d);
    inputEl.style.borderColor = ok ? "var(--primary)" : "var(--danger)";
  } else {
    inputEl.style.borderColor = "";
  }
}

function onReqPersonTypeChange() {
  const pType = document.getElementById("req-person-type")?.value || "PF";
  const lblName = document.getElementById("lbl-req-fullname");
  const lblDoc = document.getElementById("lbl-req-doc");
  const docInput = document.getElementById("req-cpf-cnpj");
  if (pType === "PJ") {
    if (lblName) lblName.textContent = "Razao Social Completa da Empresa *";
    if (lblDoc) lblDoc.textContent = "CNPJ (Validacao Oficial Modulo 11) *";
    if (docInput) docInput.placeholder = "00.000.000/0001-00";
  } else {
    if (lblName) lblName.textContent = "Nome Civil Completo (Sem Abreviacoes) *";
    if (lblDoc) lblDoc.textContent = "CPF (Validacao Oficial Modulo 11) *";
    if (docInput) docInput.placeholder = "000.000.000-00";
  }
}

async function lookupCepAuto() {
  const cepEl = document.getElementById("req-cep");
  if (!cepEl) return;
  const digits = cepEl.value.replace(/\D/g, "");
  if (digits.length !== 8) return;
  cepEl.value = `${digits.slice(0, 5)}-${digits.slice(5)}`;
  try {
    const resp = await fetch(`https://viacep.com.br/ws/${digits}/json/`);
    const info = await resp.json();
    if (info && !info.erro) {
      const stEl = document.getElementById("req-street");
      const nbEl = document.getElementById("req-neighborhood");
      const ctEl = document.getElementById("req-city");
      const ufEl = document.getElementById("req-state");
      if (stEl && info.logradouro) stEl.value = info.logradouro;
      if (nbEl && info.bairro) nbEl.value = info.bairro;
      if (ctEl && info.localidade) ctEl.value = info.localidade;
      if (ufEl && info.uf) ufEl.value = info.uf;
    }
  } catch (e) {}
}

function toggleContractPreviewBox() {
  const box = document.getElementById("req-contract-clauses-box");
  if (!box) return;
  box.style.display = box.style.display === "none" ? "block" : "none";
}

async function submitLogin() {
  const username = (document.getElementById("login-username")?.value || "").trim();
  const password = (document.getElementById("login-password")?.value || "").trim();
  const alertEl = document.getElementById("auth-status-alert");

  if (!username || !password) {
    if (alertEl) {
      alertEl.textContent = "Informe seu usuario e senha para entrar.";
      alertEl.style.display = "block";
    }
    return;
  }

  pendingCheckoutUsername = username;
  const res = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  const data = await res.json();

  if (data.ok && data.user) {
    localStorage.setItem("nexzap_auth_user", JSON.stringify(data.user));
    const gate = document.getElementById("auth-gate-overlay");
    if (gate) gate.style.display = "none";
    updateLoggedUserBadge(data.user);
    showToast(`Bem-vindo ao NexZap PRO, ${data.user.full_name || data.user.username}!`);
    fetchOverview();
  } else {
    if (alertEl) {
      alertEl.textContent = data.error || "Falha na autenticacao.";
      alertEl.style.display = "block";
    }
    if (data.pix_info) {
      renderAuthPixCheckout(data.pix_info, username);
    }
  }
}

async function submitAccessRequest() {
  const personType = (document.getElementById("req-person-type")?.value || "PF").trim();
  const fullName = (document.getElementById("req-fullname")?.value || "").trim();
  const cpfCnpj = (document.getElementById("req-cpf-cnpj")?.value || "").trim();
  const rgIe = (document.getElementById("req-rg-ie")?.value || "").trim();
  const birthDate = (document.getElementById("req-birth-date")?.value || "").trim();
  const email = (document.getElementById("req-email")?.value || "").trim();
  const phone = (document.getElementById("req-phone")?.value || "").trim();
  const cep = (document.getElementById("req-cep")?.value || "").trim();
  const street = (document.getElementById("req-street")?.value || "").trim();
  const addressNumber = (document.getElementById("req-number")?.value || "").trim();
  const complement = (document.getElementById("req-complement")?.value || "").trim();
  const neighborhood = (document.getElementById("req-neighborhood")?.value || "").trim();
  const city = (document.getElementById("req-city")?.value || "").trim();
  const state = (document.getElementById("req-state")?.value || "").trim().toUpperCase();
  const username = (document.getElementById("req-username")?.value || "").trim().toLowerCase();
  const password = (document.getElementById("req-password")?.value || "").trim();
  const planCode = (document.getElementById("req-plan-code")?.value || "plan_1").trim();
  const extraLogins = parseInt(document.getElementById("req-extra-logins")?.value || "0", 10) || 0;
  const contractAccepted = Boolean(document.getElementById("req-contract-accept")?.checked);
  const alertEl = document.getElementById("auth-status-alert");

  if (!validateClientCpfOrCnpj(cpfCnpj)) {
    if (alertEl) {
      alertEl.textContent = "CPF ou CNPJ invalido! Digite um CPF (11 digitos) ou CNPJ (14 digitos) verdadeiro e matematicamente valido.";
      alertEl.style.display = "block";
    }
    return;
  }

  const res = await fetch("/api/auth/request-access", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      person_type: personType,
      full_name: fullName,
      cpf_cnpj: cpfCnpj,
      rg_ie: rgIe,
      birth_date: birthDate,
      email: email,
      phone: phone,
      cep: cep,
      street: street,
      address_number: addressNumber,
      complement: complement,
      neighborhood: neighborhood,
      city: city,
      state: state,
      username: username,
      password: password,
      plan_code: planCode,
      extra_logins: extraLogins,
      contract_accepted: contractAccepted
    })
  });
  const data = await res.json();

  if (alertEl) {
    alertEl.textContent = data.detail || data.error || "Solicitacao processada.";
    alertEl.style.display = "block";
  }
  if (data.ok) {
    pendingCheckoutUsername = username;
    showToast("Cadastro Juridico e Contrato Assinados! Realize o PIX para liberacao.");
  }
  if (data.pix_info) {
    renderAuthPixCheckout(data.pix_info, username);
  }
  fetchOverview();
}

async function verifyAutoPixCompensationNow() {
  const userToVerify = (
    pendingCheckoutUsername ||
    document.getElementById("login-username")?.value ||
    document.getElementById("req-username")?.value ||
    ""
  ).trim().toLowerCase();
  const alertEl = document.getElementById("auth-status-alert");

  if (!userToVerify) {
    if (alertEl) {
      alertEl.textContent = "Digite seu Usuario no campo de Login antes de confirmar a compensacao automatica.";
      alertEl.style.display = "block";
    }
    return;
  }

  const res = await fetch("/api/pix/check-auto-compensation", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: userToVerify })
  });
  const data = await res.json();

  if (data.ok && data.user) {
    localStorage.setItem("nexzap_auth_user", JSON.stringify(data.user));
    const gate = document.getElementById("auth-gate-overlay");
    if (gate) gate.style.display = "none";
    updateLoggedUserBadge(data.user);
    showToast(data.detail || "PIX compensado automaticamente! Acesso liberado por +30 dias.");
    fetchOverview();
  } else if (alertEl) {
    alertEl.textContent = data.error || "Nao foi possivel verificar a compensacao automatica.";
    alertEl.style.display = "block";
  }
}

function logoutSystem() {
  localStorage.removeItem("nexzap_auth_user");
  const gate = document.getElementById("auth-gate-overlay");
  if (gate) gate.style.display = "flex";
  showToast("Sessao encerrada. Informe login e senha para entrar.");
}

function onPixModeOrBankChange() {
  const bankSel = document.getElementById("pix-cfg-bank")?.value || "inter";
  const interBox = document.getElementById("bank-fields-inter");
  const mpBox = document.getElementById("bank-fields-mercadopago");
  const efiBox = document.getElementById("bank-fields-efi");
  const feeTag = document.getElementById("pix-bank-fee-tag");

  if (interBox) interBox.style.display = bankSel === "inter" ? "block" : "none";
  if (mpBox) mpBox.style.display = bankSel === "mercadopago" ? "block" : "none";
  if (efiBox) efiBox.style.display = bankSel === "efi" ? "block" : "none";

  if (feeTag) {
    if (bankSel === "inter") feeTag.textContent = "Taxa R$ 0,00 (100% Gratuito)";
    else if (bankSel === "mercadopago") feeTag.textContent = "0,99% por PIX pago • R$ 0 Mensal";
    else feeTag.textContent = "API PIX & PIX Automatico";
  }
}

function renderAccessAndPixTab() {
  const logged = getCurrentLoggedUserObj();
  const isAdmin = !logged || logged.role === "admin" || appData.is_admin_viewer !== false;

  const adminPanel = document.getElementById("admin-only-access-panel");
  const contractorPanel = document.getElementById("contractor-only-access-panel");

  if (!isAdmin) {
    if (adminPanel) adminPanel.style.display = "none";
    if (contractorPanel) contractorPanel.style.display = "block";
    renderContractorExclusivePanel(logged);
    return;
  }

  if (adminPanel) adminPanel.style.display = "grid";
  if (contractorPanel) contractorPanel.style.display = "none";

  const users = appData.users || [];
  const countBadge = document.getElementById("lbl-users-count");
  if (countBadge) countBadge.textContent = `${users.length} usuario(s)`;

  const tbody = document.getElementById("admin-users-tbody");
  if (tbody) {
    const todayStr = new Date().toISOString().slice(0, 10);
    const rowsHtml = users.map(u => {
      const isExpired = u.role !== "admin" && u.expires_at && u.expires_at < todayStr;
      let statusBadge = `<span class="badge badge-sent">Autorizado</span>`;
      if (u.role === "admin") {
        statusBadge = `<span class="badge badge-sent">Admin Master</span>`;
      } else if (u.status === "pending") {
        statusBadge = `<span class="badge badge-warn">Aguardando Sua Autorizacao</span>`;
      } else if (u.status === "blocked") {
        statusBadge = `<span class="badge" style="background:var(--danger-soft); color:var(--danger);">Bloqueado / Inadimplente</span>`;
      } else if (isExpired) {
        statusBadge = `<span class="badge badge-warn">Ciclo Vencido (Inadimplente)</span>`;
      }

      const expText = u.expires_at === "2099-12-31"
        ? "Vitalicio (Ilimitado)"
        : (u.expires_at ? `Vence em: ${escapeHtml(u.expires_at)}` : "Sem vigencia");

      const docText = u.cpf_cnpj ? `Doc Exclusivo: <strong>${escapeHtml(u.cpf_cnpj)}</strong>` : "Doc nao informado";
      const cityUf = u.city ? `${escapeHtml(u.city)}/${escapeHtml(u.state || "")}` : "";
      const payInfo = u.last_payment_at
        ? `<div style="font-size:10px; color:var(--text-secondary); margin-top:3px;">Pago: ${escapeHtml(u.last_payment_at)}</div>`
        : "";

      const isMaster = u.role === "admin";
      const parentId = parseInt(u.parent_user_id || 0, 10);
      const maxQuota = Math.max(1, parseInt(u.max_logins_quota || 1, 10));
      const usedSeats = Math.max(1, parseInt(u.used_logins_count || 1, 10));
      const monthlyVal = u.monthly_contract_value || "150.00";
      let planBadgeHtml = "";
      if (parentId > 0) {
        planBadgeHtml = `<span class="badge badge-pending" style="font-size:9.5px; margin-left:4px;">Sub-Login Equipe (ID Titular #${parentId})</span>`;
      } else if (!isMaster) {
        planBadgeHtml = `<span class="badge badge-sent" style="font-size:9.5px; margin-left:4px;">Contrato: ${usedSeats}/${maxQuota} Logins (R$ ${escapeHtml(monthlyVal)}/mes)</span>`;
      }
      return `
        <tr>
          <td>
            <div style="font-weight:700;">${escapeHtml(u.full_name)} ${planBadgeHtml}</div>
            <div style="font-size:11px; color:var(--text-secondary);">
              Login: <code>${escapeHtml(u.username)}</code> • ${docText}
            </div>
            <div style="font-size:10.5px; color:var(--text-muted);">
              ${u.phone ? `WhatsApp: +${escapeHtml(u.phone)}` : ""} ${cityUf ? `• ${cityUf}` : ""} ${u.bound_hwid ? `• Maquina: <code>${escapeHtml(u.bound_hwid)}</code>` : ""}
            </div>
          </td>
          <td>
            ${statusBadge}
            ${payInfo}
          </td>
          <td style="font-size:11.5px; font-weight:600;">${expText}</td>
          <td>
            <div style="display:flex; gap:5px; flex-wrap:wrap;">
              <button class="btn btn-outline btn-sm" onclick="openEditCredentialsModal(${u.id})" style="border-color:var(--primary); color:var(--primary-hover); font-weight:700;" title="Alterar o Login (Usuario), a Senha e o Nome desta conta">
                Alterar Login / Senha
              </button>
              <button class="btn btn-primary btn-sm" onclick="adminManageUser(${u.id}, 'authorize_30d')" title="Autorizar ou renovar por +30 dias">
                ${u.status === "pending" ? "Autorizar (+30d)" : "Renovar +30d"}
              </button>
              <button class="btn btn-outline btn-sm" onclick="openLegalDossierModal(${u.id})" title="Abrir Contrato Assinado e Ficha Juridica para Protesto / Execucao Judicial">
                Ficha Juridica / Judicializar
              </button>
              <button class="btn btn-outline btn-sm" onclick="adminManageUser(${u.id}, 'authorize_lifetime')">
                Vitalicio
              </button>
              ${!isMaster ? `<button class="btn btn-danger btn-sm" onclick="adminManageUser(${u.id}, 'block')">Bloquear</button>` : ""}
              ${!isMaster ? `<button class="btn btn-outline btn-sm" onclick="adminManageUser(${u.id}, 'delete')">X</button>` : ""}
            </div>
          </td>
        </tr>
      `;
    }).join("");
    updateHtmlPreservingScrollAndFocus(tbody, rowsHtml);
  }

  const pixCfg = appData.pix_config || {};
  if (!pixConfigInitialized && pixCfg) {
    const modeEl = document.getElementById("pix-cfg-mode");
    const bankEl = document.getElementById("pix-cfg-bank");
    const keyEl = document.getElementById("pix-cfg-key");
    const amtEl = document.getElementById("pix-cfg-amount");
    const p3El = document.getElementById("pix-cfg-plan3-amount");
    const p5El = document.getElementById("pix-cfg-plan5-amount");
    const extEl = document.getElementById("pix-cfg-extra-seat-amount");
    const otaUrlEl = document.getElementById("admin-ota-server-url");
    const nameEl = document.getElementById("pix-cfg-name");
    const cityEl = document.getElementById("pix-cfg-city");
    const titleEl = document.getElementById("pix-cfg-title");
    const interCid = document.getElementById("bank-inter-cid");
    const interCsec = document.getElementById("bank-inter-csec");
    const mpToken = document.getElementById("bank-mp-token");
    const efiCid = document.getElementById("bank-efi-cid");
    const efiCsec = document.getElementById("bank-efi-csec");

    if (modeEl && pixCfg.pix_operation_mode) modeEl.value = pixCfg.pix_operation_mode;
    if (bankEl && pixCfg.selected_bank) bankEl.value = pixCfg.selected_bank;
    if (keyEl) keyEl.value = pixCfg.pix_key || "";
    if (amtEl) amtEl.value = pixCfg.plan_1_price || pixCfg.monthly_amount || "150.00";
    if (p3El) p3El.value = pixCfg.plan_3_price || "360.00";
    if (p5El) p5El.value = pixCfg.plan_5_price || "525.00";
    if (extEl) extEl.value = pixCfg.extra_seat_price || "95.00";
    if (otaUrlEl) otaUrlEl.value = pixCfg.auto_update_server_url || "";
    if (nameEl) nameEl.value = pixCfg.merchant_name || "GABRIEL NEXZAP PRO";
    if (cityEl) cityEl.value = pixCfg.merchant_city || "SAO PAULO";
    if (titleEl) titleEl.value = pixCfg.plan_title || "Assinatura Mensal Recorrente — NexZap PRO";
    if (interCid) interCid.value = pixCfg.bank_inter_client_id || "";
    if (interCsec) interCsec.value = pixCfg.bank_inter_client_secret || "";
    if (mpToken) mpToken.value = pixCfg.bank_mp_access_token || "";
    if (efiCid) efiCid.value = pixCfg.bank_efi_client_id || "";
    if (efiCsec) efiCsec.value = pixCfg.bank_efi_client_secret || "";

    const instEmail = document.getElementById("inst-smtp-email");
    const instPass = document.getElementById("inst-smtp-password");
    const instHost = document.getElementById("inst-smtp-host");
    const instWaPhone = document.getElementById("inst-wa-phone");
    const instWaChip = document.getElementById("inst-wa-chip-id");
    if (instEmail) instEmail.value = pixCfg.institutional_smtp_email || pixCfg.inst_smtp_email || "";
    if (instPass) instPass.value = pixCfg.institutional_smtp_password || pixCfg.inst_smtp_password || "";
    if (instHost) instHost.value = pixCfg.institutional_smtp_host || pixCfg.inst_smtp_host || "smtp.gmail.com";
    if (instWaPhone) instWaPhone.value = pixCfg.institutional_wa_phone || pixCfg.inst_wa_phone || "";
    if (instWaChip && (pixCfg.institutional_wa_chip_id !== undefined || pixCfg.inst_wa_chip_id !== undefined)) {
      instWaChip.value = String(pixCfg.institutional_wa_chip_id || pixCfg.inst_wa_chip_id || "1");
    }

    onPixModeOrBankChange();
    recalculateReqPlanSummary();
    pixConfigInitialized = true;
  }

  const instWaSel = document.getElementById("inst-wa-chip-id");
  if (instWaSel && document.activeElement !== instWaSel) {
    const curVal = instWaSel.value || String(pixCfg.institutional_wa_chip_id || pixCfg.inst_wa_chip_id || "1");
    let opts = "";
    if ((appData.chips || []).length > 0) {
      opts = [`<option value="0">Desativado (Enviar Apenas por E-mail)</option>`].concat(
        (appData.chips || []).map(c => {
          const st = c.live_wa_status === "connected" ? "Conectado" : "Ler QR";
          return `<option value="${c.id}">#${c.id} ${escapeHtml(c.name)} (+${escapeHtml(c.phone || "")}) • [${st}]</option>`;
        })
      ).join("");
    } else {
      opts = `
        <option value="1">Chip #1 — WhatsApp Institucional (Clique em Salvar & Conectar QR)</option>
        <option value="0">Desativado (Enviar Apenas por E-mail)</option>
      `;
    }
    if (instWaSel.innerHTML !== opts) {
      instWaSel.innerHTML = opts;
      instWaSel.value = curVal;
    }
  }

  const valBox = document.getElementById("bank-validation-status-box");
  if (valBox && pixCfg.bank_validation_status) {
    valBox.textContent = pixCfg.bank_validation_status;
  }
  const pillEl = document.getElementById("lbl-bank-validated-pill");
  if (pillEl && pixCfg.bank_validated_bank) {
    pillEl.textContent = `Validado: ${pixCfg.bank_validated_bank.split("(")[0].trim()}`;
  }

  const previewEl = document.getElementById("pix-cfg-emv-preview");
  if (previewEl) {
    previewEl.value = pixCfg.emv_payload || "";
  }
}

let contractorPendingUpgradeState = null;

function renderContractorExclusivePanel(loggedUser) {
  const users = appData.users || [];
  const me = users.find(u => loggedUser && u.username.toLowerCase() === loggedUser.username.toLowerCase()) || users[0] || loggedUser || {};
  const pixCfg = appData.pix_config || {};
  const parentId = parseInt(me.parent_user_id || 0, 10);
  const isSubLogin = parentId > 0;
  const maxQuota = Math.max(1, parseInt(me.max_logins_quota || 1, 10));
  const subLogins = users.filter(u => parseInt(u.parent_user_id || 0, 10) === parseInt(me.id || 0, 10));
  const usedSeats = 1 + subLogins.length;
  const monthlyContractVal = me.monthly_contract_value || pixCfg.monthly_amount || "150.00";

  const summaryCard = document.getElementById("contractor-contract-summary-card");
  if (summaryCard) {
    const docType = (me.cpf_cnpj && me.cpf_cnpj.length > 14) ? "CNPJ (Organizacao)" : "CPF (Pessoa Fisica)";
    const quotaBadge = isSubLogin
      ? `<span class="badge badge-pending">Sub-Login de Equipe (Vinculado ao Titular)</span>`
      : `<span class="badge badge-sent">${usedSeats} de ${maxQuota} Logins Utilizados • R$ ${escapeHtml(monthlyContractVal)}/mes</span>`;
    updateHtmlPreservingScrollAndFocus(summaryCard, `
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; margin-bottom:4px;">
        <strong>${isSubLogin ? "Membro da Equipe (Sub-Login):" : "Titular do Contrato:"} ${escapeHtml(me.full_name || me.username || "Contratante")}</strong>
        ${quotaBadge}
      </div>
      <div><strong>Documento Vinculado (${docType}):</strong> <code>${escapeHtml(me.cpf_cnpj || "Uso Exclusivo Nominal")}</code></div>
      <div><strong>Seu Login de Acesso:</strong> <code>${escapeHtml(me.username || "")}</code></div>
      <div><strong>Vigencia da Assinatura:</strong> <strong style="color:var(--primary);">${escapeHtml(me.expires_at || "Ativa")}</strong></div>
      <div style="margin-top:6px; font-size:11px; color:var(--text-secondary);">
        ${isSubLogin
          ? "Sua conta faz parte do pacote de logins do Titular do Contrato. Aqui voce pode alterar sua propria senha pessoal."
          : "Como Titular do Contrato (CPF ou CNPJ), voce pode gerir os sub-logins da sua equipe abaixo, substituir membros ou fazer upgrade de vagas via PIX."}
      </div>
    `);
  }

  const teamPanel = document.getElementById("contractor-team-sublogins-panel");
  const upgBox = document.getElementById("contractor-upgrade-plan-box");
  if (teamPanel) teamPanel.style.display = isSubLogin ? "none" : "block";
  if (upgBox) upgBox.style.display = isSubLogin ? "none" : "block";

  if (!isSubLogin) {
    const upgSel = document.getElementById("contractor-upgrade-plan-code");
    const upgExt = document.getElementById("contractor-upgrade-extra-seats");
    if (upgSel && document.activeElement !== upgSel && !upgSel.dataset.userTouched) {
      upgSel.value = me.plan_code || "plan_1";
    }
    if (upgExt && document.activeElement !== upgExt && !upgExt.dataset.userTouched) {
      upgExt.value = String(me.extra_logins_quota || 0);
    }
    onContractorUpgradePlanInput(false);

    const seatsBadge = document.getElementById("contractor-seats-usage-badge");
    if (seatsBadge) {
      seatsBadge.textContent = `${usedSeats} de ${maxQuota} Vaga(s) Utilizada(s)`;
    }

    const subTbody = document.getElementById("contractor-sublogins-tbody");
    if (subTbody) {
      const titularRowHtml = `
        <tr style="background:var(--primary-soft);">
          <td><span class="badge badge-sent">1. Titular (Principal)</span></td>
          <td><strong>${escapeHtml(me.full_name || me.username)}</strong></td>
          <td><code>${escapeHtml(me.username)}</code></td>
          <td>${escapeHtml(me.email || "")} ${me.phone ? `• +${escapeHtml(me.phone)}` : ""}</td>
          <td><span class="badge badge-sent">Ativo (Vence: ${escapeHtml(me.expires_at || "Ativo")})</span></td>
          <td><span style="font-size:11px; color:var(--text-secondary);">Conta Gestora do Contrato</span></td>
        </tr>
      `;
      const subsRowsHtml = subLogins.map((sub, idx) => {
        const isBlocked = sub.status === "blocked";
        const stBadge = isBlocked
          ? `<span class="badge" style="background:var(--danger-soft); color:var(--danger);">Bloqueado pelo Titular</span>`
          : `<span class="badge badge-sent">Autorizado (Vence: ${escapeHtml(sub.expires_at || me.expires_at || "")})</span>`;
        return `
          <tr>
            <td><span class="badge badge-pending">Vaga #${idx + 2} (Sub-Login)</span></td>
            <td><strong>${escapeHtml(sub.full_name || sub.username)}</strong></td>
            <td><code>${escapeHtml(sub.username)}</code></td>
            <td>${escapeHtml(sub.email || "-")} ${sub.phone ? `• +${escapeHtml(sub.phone)}` : ""}</td>
            <td>${stBadge}</td>
            <td>
              <div style="display:flex; gap:6px; flex-wrap:wrap;">
                ${isBlocked
                  ? `<button class="btn btn-primary btn-sm" onclick="contractorManageTeamSublogin(${sub.id}, 'unblock')">Reativar</button>`
                  : `<button class="btn btn-outline btn-sm" onclick="contractorManageTeamSublogin(${sub.id}, 'block')">Bloquear</button>`
                }
                <button class="btn btn-danger btn-sm" onclick="contractorManageTeamSublogin(${sub.id}, 'delete')" title="Excluir este sub-login e liberar a vaga imediatamente para cadastrar outro membro">
                  Excluir e Liberar Vaga
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join("");
      const emptyHintHtml = subLogins.length === 0
        ? `<tr><td colspan="6" style="text-align:center; color:var(--text-secondary); padding:14px; font-size:11.5px;">
             ${maxQuota > 1
               ? `Voce possui ${maxQuota - 1} vaga(s) livre(s) no seu contrato! Preencha os campos acima para criar os sub-logins da sua equipe.`
               : `Seu plano atual e o Individual (1 Login). Para adicionar membros da sua equipe, selecione o Plano 2 (3 Logins), Plano 3 (5 Logins) ou +Adicionais acima e gere o PIX!`}
           </td></tr>`
        : "";
      updateHtmlPreservingScrollAndFocus(subTbody, titularRowHtml + subsRowsHtml + emptyHintHtml);
    }
  }

  if (!contractorPendingUpgradeState) {
    const amtPill = document.getElementById("contractor-pix-amount-pill");
    if (amtPill) amtPill.textContent = `R$ ${monthlyContractVal} / mes`;

    const titleEl = document.getElementById("contractor-pix-plan-title");
    if (titleEl) titleEl.textContent = pixCfg.plan_title || "Assinatura Mensal Recorrente — NexZap PRO";

    const emvBox = document.getElementById("contractor-pix-emv-box");
    if (emvBox) emvBox.value = pixCfg.emv_payload || "Solicite a chave PIX ao Administrador para renovacao.";
  }
}

function onContractorUpgradePlanInput(markTouched = true) {
  const upgSel = document.getElementById("contractor-upgrade-plan-code");
  const upgExt = document.getElementById("contractor-upgrade-extra-seats");
  if (markTouched) {
    if (upgSel) upgSel.dataset.userTouched = "1";
    if (upgExt) upgExt.dataset.userTouched = "1";
  }
  const code = upgSel?.value || "plan_1";
  const ext = parseInt(upgExt?.value || "0", 10) || 0;
  const quote = computeClientPlanQuote(code, ext);
  const badge = document.getElementById("contractor-upgrade-preview-badge");
  if (badge) {
    badge.textContent = `${quote.total_seats} Login(s) • R$ ${quote.monthly_amount.replace(".", ",")}/mes`;
  }
}

async function contractorGenerateUpgradePix(confirmPay = false) {
  const logged = getCurrentLoggedUserObj();
  if (!logged || !logged.username) return;
  const code = document.getElementById("contractor-upgrade-plan-code")?.value || "plan_3";
  const ext = parseInt(document.getElementById("contractor-upgrade-extra-seats")?.value || "0", 10) || 0;

  const res = await fetch("/api/contractor/upgrade-plan", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      titular_username: logged.username,
      plan_code: code,
      extra_logins: ext,
      confirm_payment: confirmPay
    })
  });
  const data = await res.json();
  if (!data.ok) {
    showToast(data.error || "Falha ao processar upgrade de plano.");
    return;
  }

  if (!confirmPay && data.pix_info) {
    contractorPendingUpgradeState = { plan_code: code, extra_logins: ext };
    const amtPill = document.getElementById("contractor-pix-amount-pill");
    if (amtPill) amtPill.textContent = `R$ ${data.plan_details.monthly_amount} / mes`;
    const titleEl = document.getElementById("contractor-pix-plan-title");
    if (titleEl) titleEl.textContent = `Upgrade: ${data.plan_details.plan_label}`;
    const emvBox = document.getElementById("contractor-pix-emv-box");
    if (emvBox) emvBox.value = data.pix_info.emv_payload || "";
    showToast(data.detail || "PIX de Upgrade gerado! Copie o codigo e depois clique em '2. Ja Paguei'.");
  } else if (confirmPay) {
    contractorPendingUpgradeState = null;
    showToast(data.detail || "Upgrade confirmado e novas vagas liberadas imediatamente!");
    fetchOverview();
  }
}

async function contractorCreateTeamSublogin() {
  const logged = getCurrentLoggedUserObj();
  if (!logged || !logged.username) return;

  const fullName = (document.getElementById("sublogin-new-fullname")?.value || "").trim();
  const username = (document.getElementById("sublogin-new-username")?.value || "").trim().toLowerCase();
  const email = (document.getElementById("sublogin-new-email")?.value || "").trim();
  const phone = (document.getElementById("sublogin-new-phone")?.value || "").trim();

  if (!username || username.length < 3) {
    showToast("Informe um Login (minimo 3 caracteres) para o membro da sua equipe.");
    return;
  }

  const res = await fetch("/api/contractor/manage-sublogin", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      titular_username: logged.username,
      action: "create",
      full_name: fullName || username,
      username: username,
      email: email,
      phone: phone
    })
  });
  const data = await res.json();
  if (data.ok) {
    if (document.getElementById("sublogin-new-fullname")) document.getElementById("sublogin-new-fullname").value = "";
    if (document.getElementById("sublogin-new-username")) document.getElementById("sublogin-new-username").value = "";
    if (document.getElementById("sublogin-new-email")) document.getElementById("sublogin-new-email").value = "";
    if (document.getElementById("sublogin-new-phone")) document.getElementById("sublogin-new-phone").value = "";
    showToast(data.detail || "Sub-login criado e codigo de criacao de senha enviado!");
    fetchOverview();
  } else {
    showToast(data.error || "Nao foi possivel criar o sub-login.");
  }
}

async function contractorManageTeamSublogin(subUserId, action) {
  const logged = getCurrentLoggedUserObj();
  if (!logged || !logged.username) return;

  const res = await fetch("/api/contractor/manage-sublogin", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      titular_username: logged.username,
      action: action,
      sub_user_id: subUserId
    })
  });
  const data = await res.json();
  if (data.ok) {
    showToast(data.detail || "Sub-login atualizado com sucesso!");
    fetchOverview();
  } else {
    showToast(data.error || "Erro ao gerir sub-login.");
  }
}

async function contractorChangeOwnPassword() {
  const logged = getCurrentLoggedUserObj();
  if (!logged || !logged.username) {
    showToast("Faca login novamente para alterar sua senha.");
    return;
  }
  const currPass = (document.getElementById("contractor-curr-pass")?.value || "").trim();
  const newPass = (document.getElementById("contractor-new-pass")?.value || "").trim();
  if (!currPass || !newPass || newPass.length < 4) {
    showToast("Informe sua Senha Atual e uma Nova Senha (minimo 4 caracteres).");
    return;
  }

  const res = await fetch("/api/auth/change-own-credentials", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      current_username: logged.username,
      current_password: currPass,
      new_username: logged.username,
      new_password: newPass
    })
  });
  const data = await res.json();
  if (data.ok) {
    document.getElementById("contractor-curr-pass").value = "";
    document.getElementById("contractor-new-pass").value = "";
    showToast("Sua senha pessoal foi atualizada com sucesso!");
  } else {
    showToast(data.error || "Falha ao atualizar sua senha.");
  }
}

function contractorCopyPixPayload() {
  const emvBox = document.getElementById("contractor-pix-emv-box");
  if (!emvBox || !emvBox.value) return;
  navigator.clipboard.writeText(emvBox.value).catch(() => {});
  showToast("Codigo PIX Copia e Cola copiado! Realize o pagamento no app do seu banco.");
}

async function contractorConfirmPixRenewal() {
  const logged = getCurrentLoggedUserObj();
  if (!logged || !logged.username) return;
  if (contractorPendingUpgradeState) {
    await contractorGenerateUpgradePix(true);
    return;
  }
  const res = await fetch("/api/pix/check-auto-compensation", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: logged.username })
  });
  const data = await res.json();
  if (data.ok && data.user) {
    localStorage.setItem("nexzap_auth_user", JSON.stringify(data.user));
    showToast(data.detail || "Pagamento PIX confirmado! Sua assinatura foi renovada por +30 dias.");
    fetchOverview();
  } else {
    showToast(data.error || "Nao foi possivel confirmar o pagamento automaticamente.");
  }
}

async function validateSelectedBankNow() {
  const mode = document.getElementById("pix-cfg-mode")?.value || "both";
  const bank = document.getElementById("pix-cfg-bank")?.value || "inter";
  const pixKey = (document.getElementById("pix-cfg-key")?.value || "").trim();
  const interCid = (document.getElementById("bank-inter-cid")?.value || "").trim();
  const interCsec = (document.getElementById("bank-inter-csec")?.value || "").trim();
  const mpToken = (document.getElementById("bank-mp-token")?.value || "").trim();
  const efiCid = (document.getElementById("bank-efi-cid")?.value || "").trim();
  const efiCsec = (document.getElementById("bank-efi-csec")?.value || "").trim();

  const res = await fetch("/api/pix/validate-bank", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      pix_operation_mode: mode,
      pix_selected_bank: bank,
      pix_key: pixKey,
      bank_inter_client_id: interCid,
      bank_inter_client_secret: interCsec,
      bank_inter_pix_key: pixKey,
      bank_mp_access_token: mpToken,
      bank_mp_pix_key: pixKey,
      bank_efi_client_id: efiCid,
      bank_efi_client_secret: efiCsec,
      bank_efi_pix_key: pixKey
    })
  });
  const data = await res.json();
  if (data.ok && data.validation) {
    appData.pix_config = data.pix_config || appData.pix_config;
    renderAccessAndPixTab();
    showToast(data.validation.status_message || "Banco validado e homologado com sucesso!");
  } else {
    showToast(data.error || "Falha ao validar banco. Verifique os campos informados.");
  }
}

async function adminCreateUser() {
  const fullName = (document.getElementById("admin-new-fullname")?.value || "").trim();
  const cpfCnpj = (document.getElementById("admin-new-doc")?.value || "").trim();
  const username = (document.getElementById("admin-new-username")?.value || "").trim().toLowerCase();
  const email = (document.getElementById("admin-new-email")?.value || "").trim();
  const phone = (document.getElementById("admin-new-phone")?.value || "").trim();
  const planCode = (document.getElementById("admin-new-plan-code")?.value || "plan_1").trim();
  const extraLogins = parseInt(document.getElementById("admin-new-extra-logins")?.value || "0", 10) || 0;
  const days = parseInt(document.getElementById("admin-new-days")?.value || "30", 10);

  if (!username) {
    showToast("Informe o Login (Usuario) para autorizar o acesso e enviar o codigo.");
    return;
  }

  const res = await fetch("/api/auth/manage-user", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "create",
      full_name: fullName || username,
      cpf_cnpj: cpfCnpj,
      username: username,
      email: email,
      phone: phone,
      plan_code: planCode,
      extra_logins: extraLogins,
      days: days
    })
  });
  const data = await res.json();
  if (data.ok) {
    if (data.license_key) {
      const outEl = document.getElementById("remote-key-output");
      if (outEl) outEl.value = data.license_key;
    }
    showToast(data.detail || `Usuario "${username}" autorizado! Codigo enviado para o cliente criar a propria senha.`);
    fetchOverview();
  } else {
    showToast(data.error || "Falha ao autorizar usuario.");
  }
}

function toggleInstitutionalConfigBox() {
  const box = document.getElementById("institutional-config-collapse") || document.getElementById("institutional-channel-config-box");
  if (!box) return;
  box.style.display = box.style.display === "none" ? "block" : "none";
}

async function saveInstitutionalChannelConfig(openQrNow = false) {
  const smtpEmail = (document.getElementById("inst-smtp-email")?.value || "").trim();
  const smtpPass = (document.getElementById("inst-smtp-password")?.value || "").trim();
  const smtpHost = (document.getElementById("inst-smtp-host")?.value || "smtp.gmail.com").trim();
  const waPhone = (document.getElementById("inst-wa-phone")?.value || "").trim();
  const waChipId = (document.getElementById("inst-wa-chip-id")?.value || "1").trim();

  const res = await fetch("/api/auth/save-institutional-channel", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      inst_smtp_email: smtpEmail,
      inst_smtp_password: smtpPass,
      inst_smtp_host: smtpHost,
      inst_smtp_port: "587",
      inst_wa_phone: waPhone,
      inst_wa_chip_id: waChipId,
      institutional_smtp_email: smtpEmail,
      institutional_smtp_password: smtpPass,
      institutional_smtp_host: smtpHost,
      institutional_smtp_port: "587",
      institutional_wa_phone: waPhone,
      institutional_wa_chip_id: waChipId,
      open_qr_now: Boolean(openQrNow)
    })
  });
  const data = await res.json();
  if (data.ok) {
    if (data.pix_config) appData.pix_config = data.pix_config;
    await fetchOverview();
    if (openQrNow) {
      const cid = parseInt(waChipId || "1", 10) || 1;
      openQrModal(cid);
      showToast(`Numero do WhatsApp Institucional salvo! Escaneie o QR Code do Chip #${cid} na janela aberta.`);
    } else {
      showToast(data.detail || "E-mail Institucional e Numero do WhatsApp Institucional salvos com sucesso!");
    }
  } else {
    showToast("Erro ao salvar canais institucionais.");
  }
}

async function testInstitutionalChannelNow() {
  await saveInstitutionalChannelConfig(false);
  const testEmail = (document.getElementById("admin-new-email")?.value || document.getElementById("inst-smtp-email")?.value || "").trim();
  const testPhone = (
    document.getElementById("admin-new-phone")?.value ||
    document.getElementById("inst-wa-phone")?.value ||
    ""
  ).trim();
  showToast("Testando envio pelo E-mail Institucional e WhatsApp Institucional...");
  const res = await fetch("/api/auth/test-institutional-channel", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ test_email: testEmail, test_phone: testPhone })
  });
  const data = await res.json();
  showToast(data.detail || "Teste de canal institucional concluido!");
}

async function adminManageUser(userId, action) {
  await fetch("/api/auth/manage-user", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId, action: action })
  });
  showToast("Status de autorizacao do usuario atualizado!");
  fetchOverview();
}

function openEditCredentialsModal(userId) {
  const users = appData.users || [];
  let targetUser = null;

  if (userId && userId > 0) {
    targetUser = users.find(u => u.id === userId);
  } else {
    try {
      const saved = JSON.parse(localStorage.getItem("nexzap_auth_user") || "null");
      if (saved && saved.id) {
        targetUser = users.find(u => u.id === saved.id) || saved;
      }
    } catch (e) {}
    if (!targetUser) {
      targetUser = users.find(u => u.role === "admin") || users[0];
    }
  }

  if (!targetUser) {
    showToast("Usuario nao localizado.");
    return;
  }

  const idEl = document.getElementById("edit-cred-user-id");
  const nameEl = document.getElementById("edit-cred-fullname");
  const userEl = document.getElementById("edit-cred-username");
  const passEl = document.getElementById("edit-cred-password");
  const titleEl = document.getElementById("edit-cred-modal-title");

  if (idEl) idEl.value = String(targetUser.id || 1);
  if (nameEl) nameEl.value = targetUser.full_name || "";
  if (userEl) userEl.value = targetUser.username || "";
  if (passEl) passEl.value = "";
  if (titleEl) {
    titleEl.textContent = `Alterar Login e Senha — ${targetUser.username}`;
  }

  const modal = document.getElementById("modal-edit-credentials");
  if (modal) modal.classList.add("open");
}

async function saveEditedCredentialsModal() {
  const userId = parseInt(document.getElementById("edit-cred-user-id")?.value || "1", 10);
  const newFullName = (document.getElementById("edit-cred-fullname")?.value || "").trim();
  const newUsername = (document.getElementById("edit-cred-username")?.value || "").trim().toLowerCase();
  const newPassword = (document.getElementById("edit-cred-password")?.value || "").trim();

  if (!newUsername) {
    showToast("O campo de Login (Usuario) nao pode ficar vazio.");
    return;
  }

  const res = await fetch("/api/auth/manage-user", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "update_credentials",
      user_id: userId,
      new_full_name: newFullName,
      new_username: newUsername,
      new_password: newPassword
    })
  });
  const data = await res.json();
  if (data.ok) {
    try {
      const saved = JSON.parse(localStorage.getItem("nexzap_auth_user") || "null");
      if (saved && saved.id === userId && data.user) {
        localStorage.setItem("nexzap_auth_user", JSON.stringify(data.user));
        updateLoggedUserBadge(data.user);
      }
    } catch (e) {}

    closeModal("modal-edit-credentials");
    showToast(`Login atualizado para "${newUsername}"${newPassword ? " e nova senha gravada" : ""}!`);
    fetchOverview();
  } else {
    showToast(data.error || "Erro ao atualizar login/senha.");
  }
}

async function savePixRecurringConfig() {
  const mode = (document.getElementById("pix-cfg-mode")?.value || "both").trim();
  const selectedBank = (document.getElementById("pix-cfg-bank")?.value || "inter").trim();
  const pixKey = (document.getElementById("pix-cfg-key")?.value || "").trim();
  const amount = (document.getElementById("pix-cfg-amount")?.value || "150.00").trim();
  const plan3Amount = (document.getElementById("pix-cfg-plan3-amount")?.value || "360.00").trim();
  const plan5Amount = (document.getElementById("pix-cfg-plan5-amount")?.value || "525.00").trim();
  const extraSeatAmount = (document.getElementById("pix-cfg-extra-seat-amount")?.value || "95.00").trim();
  const otaServerUrl = (document.getElementById("admin-ota-server-url")?.value || "").trim();
  const merchantName = (document.getElementById("pix-cfg-name")?.value || "GABRIEL NEXZAP PRO").trim();
  const merchantCity = (document.getElementById("pix-cfg-city")?.value || "SAO PAULO").trim();
  const planTitle = (document.getElementById("pix-cfg-title")?.value || "Assinatura Mensal Recorrente — NexZap PRO").trim();

  if (!pixKey) {
    showToast("Digite sua Chave PIX (CPF, CNPJ, E-mail, Celular ou Aleatoria) para gerar o codigo oficial.");
    return;
  }

  const res = await fetch("/api/auth/save-pix-config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      pix_operation_mode: mode,
      pix_selected_bank: selectedBank,
      pix_key: pixKey,
      monthly_amount: amount,
      plan_1_price: amount,
      plan_3_price: plan3Amount,
      plan_5_price: plan5Amount,
      extra_seat_price: extraSeatAmount,
      auto_update_server_url: otaServerUrl,
      merchant_name: merchantName,
      merchant_city: merchantCity,
      plan_title: planTitle,
      bank_inter_client_id: (document.getElementById("bank-inter-cid")?.value || "").trim(),
      bank_inter_client_secret: (document.getElementById("bank-inter-csec")?.value || "").trim(),
      bank_mp_access_token: (document.getElementById("bank-mp-token")?.value || "").trim(),
      bank_efi_client_id: (document.getElementById("bank-efi-cid")?.value || "").trim(),
      bank_efi_client_secret: (document.getElementById("bank-efi-csec")?.value || "").trim()
    })
  });
  const data = await res.json();
  if (data.ok && data.pix_config) {
    appData.pix_config = data.pix_config;
    recalculateReqPlanSummary();
    renderAccessAndPixTab();
    showToast("Valores dos Planos (1, 3 e 5 Logins + Adicionais), Banco e PIX salvos com sucesso!");
  }
}

function copyAdminPixPayload() {
  const el = document.getElementById("pix-cfg-emv-preview");
  if (!el || !el.value) {
    showToast("Cadastre sua chave PIX e clique em Salvar primeiro.");
    return;
  }
  navigator.clipboard.writeText(el.value).catch(() => {});
  showToast("Codigo PIX Copia e Cola copiado para a area de transferencia!");
}

function openLegalDossierModal(userId) {
  const users = appData.users || [];
  const u = users.find(x => x.id === userId);
  if (!u) return;

  const pixCfg = appData.pix_config || {};
  const monthlyVal = pixCfg.monthly_amount || "97.00";
  const fullAddr = [
    u.street ? `${u.street}, nº ${u.address_number || "S/N"}` : "",
    u.complement || "",
    u.neighborhood ? `Bairro ${u.neighborhood}` : "",
    u.city ? `${u.city}/${u.state || ""}` : "",
    u.cep ? `CEP: ${u.cep}` : ""
  ].filter(Boolean).join(" — ") || "Endereco nao preenchido (conta criada manualmente)";

  const container = document.getElementById("legal-dossier-printable-content");
  if (container) {
    container.innerHTML = `
      <div style="text-align:center; border-bottom:2px solid #0f172a; padding-bottom:10px; margin-bottom:14px;">
        <div style="font-size:15px; font-weight:800; letter-spacing:0.3px;">
          INSTRUMENTO PARTICULAR DE LICENCIAMENTO RECORRENTE, CONFISSAO DE DIVIDA E FICHA DE QUALIFICACAO PARA EXECUCAO JUDICIAL
        </div>
        <div style="font-size:11px; color:#475569; margin-top:3px;">
          Titulo Executivo Extrajudicial Eletronico — Art. 319 e Art. 784, III e §4º do Codigo de Processo Civil (Lei 14.620/2023)
        </div>
      </div>

      <div style="margin-bottom:12px;">
        <strong style="font-size:12.5px; text-transform:uppercase; color:#059669;">1. Qualificacao Completa do Devedor / Contratante (Art. 319, II do CPC):</strong>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:6px; background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; padding:10px; margin-top:5px;">
          <div><strong>Nome Civil / Razao Social:</strong> ${escapeHtml(u.full_name)}</div>
          <div><strong>CPF / CNPJ Validado:</strong> ${escapeHtml(u.cpf_cnpj || "Nao informado")}</div>
          <div><strong>RG / Inscricao Estadual:</strong> ${escapeHtml(u.rg_ie || "Nao informado")}</div>
          <div><strong>Data de Nasc. / Fundacao:</strong> ${escapeHtml(u.birth_date || "Nao informado")}</div>
          <div><strong>E-mail para Intimacao Judicial:</strong> ${escapeHtml(u.email || "Nao informado")}</div>
          <div><strong>Telefone / WhatsApp:</strong> +${escapeHtml(u.phone || "Nao informado")}</div>
          <div style="grid-column: span 2;"><strong>Endereco Completo para Citacao e Penhora Judicial:</strong> ${escapeHtml(fullAddr)}</div>
        </div>
      </div>

      <div style="margin-bottom:12px;">
        <strong style="font-size:12.5px; text-transform:uppercase; color:#059669;">2. Dados da Obrigacao Financeira, Vigencia e Inadimplencia:</strong>
        <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; padding:10px; margin-top:5px;">
          <div><strong>Credor / Licenciante:</strong> ${escapeHtml(pixCfg.merchant_name || "GABRIEL NEXZAP PRO")} (Chave PIX: ${escapeHtml(pixCfg.pix_key || "Configurada no Painel")})</div>
          <div><strong>Objeto do Contrato:</strong> Licenciamento Mensal Recorrente da Plataforma NexZap PRO (Login: <code>${escapeHtml(u.username)}</code>)</div>
          <div><strong>Valor Liquido Mensal Contratado:</strong> R$ ${escapeHtml(monthlyVal)} (acrescido de multa contratual de 10%, juros de 1% a.m. e correcao monetaria em caso de mora)</div>
          <div><strong>Data de Vencimento / Status Atual:</strong> Vencimento em <strong>${escapeHtml(u.expires_at || "Pendente")}</strong> • Status: <strong>${escapeHtml(u.status.toUpperCase())}</strong></div>
        </div>
      </div>

      <div>
        <strong style="font-size:12.5px; text-transform:uppercase; color:#059669;">3. Comprovacao de Assinatura Eletronica e Auditoria Forense (Art. 784, §4º do CPC):</strong>
        <div style="background:#f1f5f9; border:1px solid #94a3b8; border-radius:6px; padding:10px; margin-top:5px; font-family:monospace; font-size:11px;">
          <div><strong>Aceite Contratual Expresso:</strong> SIM (Termo de Adesao e Confissao de Divida aceito no cadastro)</div>
          <div><strong>Carimbo de Tempo (Timestamp):</strong> ${escapeHtml(u.contract_accepted_at || u.created_at || "Registrado")}</div>
          <div><strong>Endereco IP de Origem:</strong> ${escapeHtml(u.contract_ip || "127.0.0.1")}</div>
          <div><strong>Dispositivo / User-Agent:</strong> ${escapeHtml(u.contract_user_agent || "Navegador Desktop")}</div>
          <div style="word-break:break-all;"><strong>Hash Criptografico SHA-256 da Assinatura:</strong> ${escapeHtml(u.contract_signature_hash || "ASSINATURA-REGISTRADA-NO-BANCO")}</div>
        </div>
      </div>
    `;
  }

  const modal = document.getElementById("modal-legal-dossier");
  if (modal) modal.classList.add("open");
}

function copyLegalDossierText() {
  const el = document.getElementById("legal-dossier-printable-content");
  if (!el) return;
  navigator.clipboard.writeText(el.innerText).catch(() => {});
  showToast("Dossie Juridico copiado! Pronto para colar na peticao ou enviar ao advogado/cartorio.");
}

function printLegalDossier() {
  const el = document.getElementById("legal-dossier-printable-content");
  if (!el) return;
  const w = window.open("", "_blank", "width=860,height=720");
  if (!w) {
    window.print();
    return;
  }
  w.document.write(`
    <html>
      <head>
        <title>Dossie Juridico de Execucao — NexZap PRO</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 28px; color: #0f172a; }
        </style>
      </head>
      <body>${el.innerHTML}</body>
    </html>
  `);
  w.document.close();
  w.focus();
  w.print();
}

/* ============================================================================
   GERADOR E VALIDADOR DE CHAVE DE LIBERAÇÃO REMOTA (QUALQUER MÁQUINA / LUGAR)
============================================================================ */

async function generateAdminRemoteKey() {
  const username = (document.getElementById("remote-key-username")?.value || "").trim().toLowerCase();
  const days = parseInt(document.getElementById("remote-key-days")?.value || "30", 10);
  if (!username) {
    showToast("Digite o Login (usuario) do cliente para gerar a Chave de Liberacao Remota.");
    return;
  }

  const res = await fetch("/api/auth/generate-remote-key", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, days })
  });
  const data = await res.json();
  if (data.ok && data.license_key) {
    const outEl = document.getElementById("remote-key-output");
    if (outEl) outEl.value = data.license_key;
    showToast(data.detail || "Chave de Liberacao Remota gerada com sucesso!");
    fetchOverview();
  } else {
    showToast(data.error || "Erro ao gerar Chave Remota.");
  }
}

function copyAdminRemoteKey() {
  const outEl = document.getElementById("remote-key-output");
  if (!outEl || !outEl.value) {
    showToast("Gere uma Chave Remota primeiro antes de copiar.");
    return;
  }
  navigator.clipboard.writeText(outEl.value).catch(() => {});
  showToast("Chave de Liberacao Remota copiada! Envie para o cliente colar na tela de login.");
}

async function redeemRemoteLicenseKey() {
  const rawKey = (document.getElementById("login-remote-key-input")?.value || "").trim();
  const newPassword = (document.getElementById("login-remote-new-pass")?.value || "").trim();
  const confirmPassword = (document.getElementById("login-remote-confirm-pass")?.value || "").trim();
  const alertEl = document.getElementById("auth-status-alert");

  if (!rawKey) {
    if (alertEl) {
      alertEl.textContent = "Cole o Codigo de Validacao (NEXZAP-...) recebido por E-mail ou WhatsApp.";
      alertEl.style.display = "block";
    }
    return;
  }
  if (!newPassword || newPassword.length < 4) {
    if (alertEl) {
      alertEl.textContent = "Crie a sua Senha Pessoal (minimo de 4 caracteres) no campo abaixo do codigo.";
      alertEl.style.display = "block";
    }
    return;
  }
  if (confirmPassword && newPassword !== confirmPassword) {
    if (alertEl) {
      alertEl.textContent = "A confirmacao de senha nao confere. Digite a mesma senha nos dois campos.";
      alertEl.style.display = "block";
    }
    return;
  }

  const res = await fetch("/api/auth/redeem-remote-key", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      license_key: rawKey,
      new_password: newPassword,
      confirm_password: confirmPassword || newPassword
    })
  });
  const data = await res.json();
  if (data.ok && data.user) {
    localStorage.setItem("nexzap_auth_user", JSON.stringify(data.user));
    const gate = document.getElementById("auth-gate-overlay");
    if (gate) gate.style.display = "none";
    updateLoggedUserBadge(data.user);
    showToast(data.detail || "Codigo validado e sua senha pessoal foi criada com sucesso!");
    fetchOverview();
  } else if (alertEl) {
    alertEl.textContent = data.error || "Codigo de Validacao invalido.";
    alertEl.style.display = "block";
  }
}

/* ============================================================================
   DEMONSTRAÇÃO VISUAL MOSTRANDO A TELA REAL DO PROGRAMA USUAL (PASSO A PASSO)
============================================================================ */

const USUAL_SIDEBAR_MENUS = [
  "1. Multi-Campanhas e Disparos",
  "2. CRM, Etiquetas e Segment...",
  "3. Respostas Automaticas (IA)",
  "4. Central de Chips (1 a 100)",
  "5. Aquecimento Entre Chips",
  "6. Grupos (Extrair e Disparar)",
  "7. Logins e PIX Recorrente"
];

const SIMULATION_VIDEOS_CATALOG = [
  {
    id: 0,
    title: "1. Como Conectar Seus Chips e Agrupar as Telas em 1 Bloco",
    targetTab: "tab-chips",
    targetNavIdx: 3,
    ctaLabel: "Abrir 4. Central de Chips Agora",
    scenes: [
      {
        stepTitle: "Passo 1: Clique em '4. Central de Chips' e depois em '+ Cadastrar Novo Chip Real'",
        caption: "No menu esquerdo, clique em '4. Central de Chips (1 a 100)' e aperte o botao verde '+ Cadastrar Novo Chip Real'.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #f1f5f9; padding-bottom:10px; margin-bottom:12px;">
              <strong style="font-size:13px; color:#0f172a;">Central Operacional de Chips (1 a 100)</strong>
              <span style="background:#059669; color:#ffffff; padding:6px 12px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
                + Cadastrar Novo Chip Real &larr; CLIQUE AQUI
              </span>
            </div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; background:#f8fafc; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
              <div>
                <div style="font-size:10.5px; color:#64748b; font-weight:700;">Nome do Chip (usado em {{nome do chip}})</div>
                <div style="background:#fff; border:1px solid #cbd5e1; padding:6px 8px; border-radius:6px; font-size:12px; margin-top:3px; color:#0f172a;">Michelle Comercial</div>
              </div>
              <div>
                <div style="font-size:10.5px; color:#64748b; font-weight:700;">Numero do WhatsApp com DDD</div>
                <div style="background:#fff; border:1px solid #cbd5e1; padding:6px 8px; border-radius:6px; font-size:12px; margin-top:3px; color:#0f172a;">5511988887777</div>
              </div>
            </div>
          </div>
        `
      },
      {
        stepTitle: "Passo 2: Clique em 'Conectar QR Code' e escaneie com seu celular",
        caption: "No cartao do chip criado, aperte o botao verde 'Conectar QR Code' e aponte a camera do WhatsApp do seu celular.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="border:1px solid #cbd5e1; border-radius:8px; padding:12px; max-width:340px;">
              <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                <strong style="font-size:12px; color:#0f172a;">CHIP ATIVO 1 • Michelle Comercial</strong>
                <span style="background:#fef3c7; color:#92400e; font-size:10px; padding:2px 6px; border-radius:4px; font-weight:700;">Ler QR Code</span>
              </div>
              <div style="display:flex; gap:8px; margin-top:10px;">
                <span style="background:#fff; border:1px solid #cbd5e1; padding:6px 10px; border-radius:6px; font-size:11px; color:#0f172a;">Salvar Nome</span>
                <span style="background:#059669; color:#fff; padding:6px 14px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
                  Conectar QR Code &larr; CLIQUE AQUI
                </span>
              </div>
            </div>
          </div>
        `
      },
      {
        stepTitle: "Passo 3: Clique em 'Agrupar Telas em 1 Bloco' para nao encher a barra do PC",
        caption: "Para juntar todas as janelas abertas do WhatsApp em um unico icone na barra de tarefas do Windows, clique em 'Agrupar Telas em 1 Bloco'.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
              <strong style="font-size:12.5px; color:#0f172a;">Topo da Central de Chips:</strong>
              <span style="background:#ecfdf5; border:2px solid #059669; color:#047857; padding:6px 12px; border-radius:6px; font-size:11.5px; font-weight:800;">
                Agrupar Telas em 1 Bloco na Barra &larr; CLIQUE AQUI
              </span>
            </div>
            <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; padding:10px; font-size:12px; color:#334155;">
              Pronto! Mesmo que voce conecte 10, 50 ou 100 chips, todos ficam reunidos dentro de <strong>1 unico bloco</strong> na sua barra de tarefas.
            </div>
          </div>
        `
      }
    ]
  },
  {
    id: 1,
    title: "2. Como Extrair Contatos de Grupos e Disparar para Eles",
    targetTab: "tab-groups",
    targetNavIdx: 5,
    ctaLabel: "Abrir 6. Grupos (Extrair e Disparar)",
    scenes: [
      {
        stepTitle: "Passo 1: No menu '6. Grupos', clique em '1. Listar Meus Grupos'",
        caption: "Clique em '6. Grupos (Extrair e Disparar)' na esquerda e aperte o botao verde '1. Listar Meus Grupos do WhatsApp'.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
              <strong style="font-size:12.5px; color:#0f172a;">Extrator de Grupos do WhatsApp</strong>
              <span style="background:#059669; color:#fff; padding:6px 12px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
                1. Listar Meus Grupos &larr; CLIQUE AQUI
              </span>
            </div>
            <div style="font-size:12px; color:#475569;">O sistema busca automaticamente todos os grupos do seu chip conectado.</div>
          </div>
        `
      },
      {
        stepTitle: "Passo 2: Clique em 'Extrair Contatos' ao lado do grupo desejado",
        caption: "Na lista de grupos que aparecer na tela, clique em 'Extrair Contatos'. Ele puxa todos os numeros e nomes reais sem precisar abrir o grupo!",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; padding:10px; display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
              <div>
                <strong style="font-size:12.5px; color:#0f172a;">Grupo Networking SP</strong>
                <div style="font-size:11px; color:#64748b;">184 participantes</div>
              </div>
              <span style="background:#059669; color:#fff; padding:5px 12px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
                Extrair Contatos &larr; CLIQUE AQUI
              </span>
            </div>
            <div style="font-size:11.5px; color:#059669; font-weight:700;">Todos os contatos sao salvos com o nome real e com a etiqueta do grupo!</div>
          </div>
        `
      },
      {
        stepTitle: "Passo 3: Digite sua mensagem na direita e clique em 'Iniciar Disparo'",
        caption: "No painel da direita da mesma tela, escreva sua mensagem (as 15 variacoes IA sao geradas sozinhas) e clique em 'Iniciar Disparo'!",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="font-size:11.5px; font-weight:700; color:#0f172a; margin-bottom:6px;">Mensagem para os Contatos do Grupo (15 Variacoes IA Automaticas):</div>
            <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; padding:8px; font-size:11.5px; color:#0f172a; margin-bottom:10px;">
              Oi, <strong>{{primeiro nome}}</strong>, tudo bem? Me chamo <strong>{{nome do chip}}</strong>, vi que estamos no mesmo grupo...
            </div>
            <div style="background:#059669; color:#fff; text-align:center; padding:8px; border-radius:6px; font-size:12px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
              Iniciar Disparo para os Contatos Extraidos deste Grupo &larr; CLIQUE AQUI
            </div>
          </div>
        `
      }
    ]
  },
  {
    id: 2,
    title: "3. Como Criar e Disparar uma Campanha com 15 Variacoes IA e Link",
    targetTab: "tab-workspace",
    targetNavIdx: 0,
    ctaLabel: "Abrir 1. Multi-Campanhas e Disparos",
    scenes: [
      {
        stepTitle: "Passo 1: Suba seus Contatos ou Escolha uma Etiqueta",
        caption: "No menu '1. Multi-Campanhas e Disparos', clique em '+ Subir Contatos' na Coluna 1 (ou escolha uma Etiqueta na Coluna 2).",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
              <strong style="font-size:12.5px; color:#0f172a;">Coluna 1: Base de Contatos e Chips</strong>
              <span style="background:#ecfdf5; border:2px solid #059669; color:#047857; padding:5px 10px; border-radius:6px; font-size:11.5px; font-weight:800;">
                + Subir Contatos &larr; CLIQUE AQUI
              </span>
            </div>
            <div style="font-size:12px; color:#475569;">Cole sua lista do Excel/CSV ou deixe os contatos que voce ja extraiu dos grupos.</div>
          </div>
        `
      },
      {
        stepTitle: "Passo 2: Coloque o Link (com Previa) e Digite sua Mensagem",
        caption: "Na Coluna 2, cole o seu Link (a Previa Rica com imagem carrega automaticamente) e digite seu texto para gerar as 15 Variacoes IA.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="margin-bottom:8px;">
              <div style="font-size:11px; font-weight:700; color:#059669;">Link de Destino (Gera Previa Rica com Card no WhatsApp):</div>
              <div style="background:#f8fafc; border:1px solid #059669; padding:6px 8px; border-radius:6px; font-size:11.5px; color:#0f172a; margin-top:2px;">
                https://suaempresa.com.br/proposta
              </div>
            </div>
            <div style="background:#ecfdf5; border:1px solid #a7f3d0; padding:8px; border-radius:6px; font-size:11.5px; color:#065f46; font-weight:700;">
              15 Variacoes de Alto Nivel (V1 a V15) geradas com Coesao e Coerencia 99%!
            </div>
          </div>
        `
      },
      {
        stepTitle: "Passo 3: Clique em 'Iniciar Disparo da Campanha'",
        caption: "Selecione os chips que vao disparar e aperte o botao verde 'Iniciar Disparo da Campanha' na parte inferior da Coluna 2.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="font-size:12px; color:#334155; margin-bottom:10px;">
              O sistema envia no WhatsApp Real aguardando a Previa do Link carregar e alternando entre as 15 variacoes IA!
            </div>
            <div style="background:#059669; color:#fff; text-align:center; padding:10px; border-radius:6px; font-size:12.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
              Iniciar Disparo da Campanha &larr; CLIQUE AQUI
            </div>
          </div>
        `
      }
    ]
  },
  {
    id: 3,
    title: "4. Como Usar as Respostas Automaticas (IA) e o Funil CRM",
    targetTab: "tab-autoreply",
    targetNavIdx: 2,
    ctaLabel: "Abrir 3. Respostas Automaticas (IA)",
    scenes: [
      {
        stepTitle: "Passo 1: Digite a resposta automatica no menu '3. Respostas Automaticas'",
        caption: "Clique em '3. Respostas Automaticas (IA)' na esquerda e escreva o que o sistema deve responder quando um cliente mandar mensagem.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <strong style="font-size:12.5px; color:#0f172a; display:block; margin-bottom:6px;">Etapa 1 do Auto-Atendimento:</strong>
            <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; padding:8px; font-size:11.5px; color:#0f172a; margin-bottom:10px;">
              Ola, {{primeiro_nome}}! Que bom receber seu retorno. Aqui esta o link com todos os detalhes: {{link_unico}}
            </div>
            <span style="background:#059669; color:#fff; padding:6px 12px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
              Salvar e Ativar Fluxo Multi-Respostas &larr; CLIQUE AQUI
            </span>
          </div>
        `
      },
      {
        stepTitle: "Passo 2: Acompanhe seus clientes no menu '2. CRM, Etiquetas e Segmentacao'",
        caption: "Quando o cliente responde, ele avanca sozinho para a coluna 'Respondeu' no menu '2. CRM' e continua sendo atendido pelo mesmo chip!",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:8px; font-size:11px;">
              <div style="background:#f8fafc; border:1px solid #cbd5e1; padding:8px; border-radius:6px;"><strong>1. Novo Lead</strong><br/>Contatos importados</div>
              <div style="background:#f8fafc; border:1px solid #cbd5e1; padding:8px; border-radius:6px;"><strong>2. Enviado</strong><br/>Receberam disparo</div>
              <div style="background:#ecfdf5; border:2px solid #059669; padding:8px; border-radius:6px; color:#065f46;"><strong>3. Respondeu</strong><br/>Movido automaticamente!</div>
            </div>
          </div>
        `
      }
    ]
  },
  {
    id: 4,
    title: "5. Como Aquecer Chips Novos (Conversa Automatica Entre Seus Chips)",
    targetTab: "tab-warmup",
    targetNavIdx: 4,
    ctaLabel: "Abrir 5. Aquecimento Entre Chips",
    scenes: [
      {
        stepTitle: "Passo Unico: Conecte 2 ou mais chips e clique em 'Iniciar Aquecimento Real'",
        caption: "No menu '5. Aquecimento Entre Chips', basta clicar no botao verde 'Iniciar Aquecimento Real'. Seus chips conversam entre si automaticamente!",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
              <strong style="font-size:12.5px; color:#0f172a;">Maturador e Aquecedor de Chips</strong>
              <span style="background:#059669; color:#fff; padding:6px 12px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
                Iniciar Aquecimento Real &larr; CLIQUE AQUI
              </span>
            </div>
            <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; padding:10px; font-size:11.5px; color:#334155;">
              O Chip #1 envia uma mensagem natural para o Chip #2, e o Chip #2 responde sozinho no WhatsApp para blindar seus numeros contra bloqueios.
            </div>
          </div>
        `
      }
    ]
  },
  {
    id: 5,
    title: "6. Como Cobrar PIX, Liberar Login (De Qualquer Lugar), Mudar Senha e Judicializar",
    targetTab: "tab-access-pix",
    targetNavIdx: 6,
    ctaLabel: "Abrir 7. Logins e PIX Recorrente",
    scenes: [
      {
        stepTitle: "Passo 1: Configurar seu Banco e sua Chave PIX (Painel Direito do Menu 7)",
        caption: "No menu '7. Logins e PIX Recorrente', na coluna da direita, escolha seu banco (Inter, Mercado Pago ou Efi), digite sua Chave PIX e clique em 'Validar Conta' e 'Salvar'.",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="font-size:12px; font-weight:800; color:#0f172a; margin-bottom:6px;">Coluna Direita do Menu 7 — PIX Recorrente (2 Opcoes + Banco):</div>
            <div style="background:#ecfdf5; border:1px solid #a7f3d0; padding:8px; border-radius:6px; font-size:11.5px; color:#065f46; margin-bottom:8px;">
              Banco Selecionado: <strong>1. Banco Inter / 2. Mercado Pago</strong> • Valor: <strong>R$ 97,00</strong>
            </div>
            <span style="background:#059669; color:#fff; padding:6px 12px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0; display:inline-block;">
              Validar Conta Bancaria &amp; Salvar &larr; CLIQUE AQUI
            </span>
          </div>
        `
      },
      {
        stepTitle: "Passo 2: Liberar Login de Cliente ou Alterar Login e Senha (Coluna Esquerda)",
        caption: "Na tabela da esquerda, clique em 'Autorizar (+30d)' para liberar o cliente, 'Alterar Login / Senha' para trocar usuario/senha, ou gere uma 'Chave Remota' para liberar clientes em outro PC!",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="font-size:12px; font-weight:800; color:#0f172a; margin-bottom:8px;">Botoes na Tabela de Usuarios (Menu 7):</div>
            <div style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:10px;">
              <span style="background:#fff; border:2px solid #059669; color:#047857; padding:5px 10px; border-radius:6px; font-size:11px; font-weight:800;">
                Alterar Login / Senha &larr; Troca Usuario e Senha
              </span>
              <span style="background:#059669; color:#fff; padding:5px 10px; border-radius:6px; font-size:11px; font-weight:800;">
                Autorizar (+30d) &larr; Libera Acesso
              </span>
            </div>
            <div style="font-size:11px; color:#475569;">
              <strong>Cliente em outro computador?</strong> Digite o login dele em <em>"Gerar Chave Remota"</em> e mande o codigo <code>NEXZAP-30D-...</code> pelo WhatsApp!
            </div>
          </div>
        `
      },
      {
        stepTitle: "Passo 3: Emitir Contrato Assinado e Ficha Juridica se o Cliente Nao Pagar",
        caption: "Se o cliente nao pagar, clique no botao 'Ficha Juridica / Judicializar' ao lado do nome dele para imprimir o Contrato com CPF, Endereco e Assinatura SHA-256!",
        panelHtml: `
          <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
              <strong style="font-size:12px; color:#0f172a;">Cliente Inadimplente na Tabela:</strong>
              <span style="background:#fff; border:2px solid #059669; color:#047857; padding:5px 10px; border-radius:6px; font-size:11.5px; font-weight:800; box-shadow:0 0 0 3px #a7f3d0;">
                Ficha Juridica / Judicializar &larr; CLIQUE AQUI
              </span>
            </div>
            <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; padding:8px; font-size:11.5px; color:#334155;">
              Abre na hora o <strong>Titulo Executivo Extrajudicial (Art. 784, §4º do CPC)</strong> com CPF/CNPJ validado, Endereco de Citacao e Hash SHA-256 pronto para imprimir ou salvar em PDF!
            </div>
          </div>
        `
      }
    ]
  }
];

let activeSimVideoIdx = 0;
let activeSimSceneIdx = 0;
let simVideoPlaying = true;
let simVideoIntervalMs = 4200;
let simVideoTimer = null;

function selectSimulationVideo(videoIdx) {
  activeSimVideoIdx = videoIdx;
  activeSimSceneIdx = 0;
  for (let i = 0; i < SIMULATION_VIDEOS_CATALOG.length; i++) {
    const btn = document.getElementById(`sim-btn-${i}`);
    if (btn) {
      btn.className = i === videoIdx ? "btn btn-primary btn-sm" : "btn btn-outline btn-sm";
    }
  }
  renderSimulationVideoScene();
  resetSimulationVideoTimer();
}

function renderSimulationVideoScene() {
  const video = SIMULATION_VIDEOS_CATALOG[activeSimVideoIdx] || SIMULATION_VIDEOS_CATALOG[0];
  const scenes = video.scenes || [];
  if (activeSimSceneIdx >= scenes.length) activeSimSceneIdx = 0;
  if (activeSimSceneIdx < 0) activeSimSceneIdx = scenes.length - 1;
  const scene = scenes[activeSimSceneIdx];

  const headerTitle = document.getElementById("sim-video-Header-title");
  const stepCounter = document.getElementById("sim-video-step-counter");
  const stageEl = document.getElementById("sim-video-stage");
  const captionBar = document.getElementById("sim-video-caption-bar");
  const progressFill = document.getElementById("sim-video-progress-fill");
  const scenesListEl = document.getElementById("sim-video-scenes-list");
  const ctaBtn = document.getElementById("sim-video-cta-btn");

  if (headerTitle) headerTitle.textContent = video.title;
  if (stepCounter) stepCounter.textContent = `Passo ${activeSimSceneIdx + 1} de ${scenes.length}`;
  if (captionBar && scene) captionBar.textContent = scene.caption;
  if (progressFill && scenes.length > 0) {
    const pct = Math.round(((activeSimSceneIdx + 1) / scenes.length) * 100);
    progressFill.style.width = `${pct}%`;
  }

  if (stageEl && scene) {
    const sidebarHtml = USUAL_SIDEBAR_MENUS.map((mLabel, mIdx) => {
      const isSelected = mIdx === video.targetNavIdx;
      return `
        <div style="padding:7px 9px; border-radius:6px; font-size:10.5px; font-weight:${isSelected ? "800" : "600"}; background:${isSelected ? "#059669" : "transparent"}; color:${isSelected ? "#ffffff" : "#475569"}; margin-bottom:3px; display:flex; justify-content:space-between; align-items:center;">
          <span>${mLabel}</span>
          ${isSelected ? `<span style="font-size:9px; background:#ffffff; color:#059669; padding:1px 4px; border-radius:3px; font-weight:900;">ATIVO</span>` : ""}
        </div>
      `;
    }).join("");

    stageEl.innerHTML = `
      <div style="background:#ffffff; border-right:1px solid #e2e8f0; padding:10px;">
        <div style="font-size:9.5px; font-weight:800; color:#94a3b8; margin-bottom:6px;">MENU LATERAL ESQUERDO</div>
        ${sidebarHtml}
      </div>
      <div style="padding:16px; display:flex; flex-direction:column; justify-content:center;">
        <div style="font-size:13px; font-weight:800; color:#0f172a; margin-bottom:10px;">
          ${scene.stepTitle}
        </div>
        ${scene.panelHtml}
      </div>
    `;
  }

  if (scenesListEl) {
    scenesListEl.innerHTML = scenes.map((sc, idx) => {
      const isCurrent = idx === activeSimSceneIdx;
      return `
        <div onclick="jumpToSimulationScene(${idx})" style="cursor:pointer; padding:10px 12px; border-radius:8px; border:2px solid ${isCurrent ? "#059669" : "#e2e8f0"}; background:${isCurrent ? "#ecfdf5" : "#f8fafc"};">
          <div style="font-size:12px; font-weight:800; color:${isCurrent ? "#047857" : "#0f172a"};">
            ${sc.stepTitle}
          </div>
          <div style="font-size:11px; color:#475569; margin-top:3px; line-height:1.4;">
            ${sc.caption}
          </div>
        </div>
      `;
    }).join("");
  }

  if (ctaBtn) {
    ctaBtn.textContent = video.ctaLabel || "Ir para Esta Tela Agora";
    ctaBtn.onclick = () => switchTab(video.targetTab, document.querySelectorAll(".side-nav-link")[video.targetNavIdx]);
  }
}

function jumpToSimulationScene(sceneIdx) {
  activeSimSceneIdx = sceneIdx;
  renderSimulationVideoScene();
  resetSimulationVideoTimer();
}

function stepSimulationScene(delta) {
  const video = SIMULATION_VIDEOS_CATALOG[activeSimVideoIdx] || SIMULATION_VIDEOS_CATALOG[0];
  activeSimSceneIdx = (activeSimSceneIdx + delta + video.scenes.length) % video.scenes.length;
  renderSimulationVideoScene();
  resetSimulationVideoTimer();
}

function toggleSimulationVideoPlay() {
  simVideoPlaying = !simVideoPlaying;
  const btn = document.getElementById("btn-sim-play-pause");
  if (btn) btn.textContent = simVideoPlaying ? "Pausar Demonstracao" : "Continuar Demonstracao";
  resetSimulationVideoTimer();
}

function restartSimulationVideo() {
  activeSimSceneIdx = 0;
  simVideoPlaying = true;
  const btn = document.getElementById("btn-sim-play-pause");
  if (btn) btn.textContent = "Pausar Demonstracao";
  renderSimulationVideoScene();
  resetSimulationVideoTimer();
}

function changeSimulationSpeed(msVal) {
  simVideoIntervalMs = parseInt(msVal || "4200", 10);
  resetSimulationVideoTimer();
}

function seekSimulationVideo(evt, barEl) {
  if (!barEl) return;
  const rect = barEl.getBoundingClientRect();
  const ratio = Math.max(0, Math.min(1, (evt.clientX - rect.left) / Math.max(1, rect.width)));
  const video = SIMULATION_VIDEOS_CATALOG[activeSimVideoIdx] || SIMULATION_VIDEOS_CATALOG[0];
  activeSimSceneIdx = Math.min(video.scenes.length - 1, Math.floor(ratio * video.scenes.length));
  renderSimulationVideoScene();
  resetSimulationVideoTimer();
}

function resetSimulationVideoTimer() {
  if (simVideoTimer) clearInterval(simVideoTimer);
  if (!simVideoPlaying) return;
  simVideoTimer = setInterval(() => {
    const tutSection = document.getElementById("tab-tutorial");
    if (!tutSection || !tutSection.classList.contains("active")) return;
    const video = SIMULATION_VIDEOS_CATALOG[activeSimVideoIdx] || SIMULATION_VIDEOS_CATALOG[0];
    activeSimSceneIdx = (activeSimSceneIdx + 1) % video.scenes.length;
    renderSimulationVideoScene();
  }, simVideoIntervalMs);
}

/* ============================================================================
   CONTROLE DE TEMA (ADAPTAR À MÁQUINA / CLARO / ESCURO) E ACESSIBILIDADE VISUAL (FONTES GRANDES PROPORCIONAIS)
============================================================================ */
let systemDarkMediaQuery = null;

function resolveEffectiveTheme(themePref) {
  if (themePref === "dark") return "dark";
  if (themePref === "light") return "light";
  try {
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      return "dark";
    }
  } catch (e) {}
  return "light";
}

function applyVisualAccessibilitySettings(showFeedbackToast = false) {
  const themePref = localStorage.getItem("nexzap_theme_pref") || "auto";
  const fontScale = localStorage.getItem("nexzap_font_scale") || "100";

  const effectiveTheme = resolveEffectiveTheme(themePref);
  document.documentElement.setAttribute("data-theme", effectiveTheme);
  document.documentElement.setAttribute("data-theme-pref", themePref);
  document.documentElement.setAttribute("data-font-scale", fontScale);

  const topThemeEl = document.getElementById("topbar-theme-select");
  const authThemeEl = document.getElementById("auth-theme-select");
  if (topThemeEl && topThemeEl.value !== themePref) topThemeEl.value = themePref;
  if (authThemeEl && authThemeEl.value !== themePref) authThemeEl.value = themePref;

  const topFontEl = document.getElementById("topbar-font-select");
  const authFontEl = document.getElementById("auth-font-select");
  if (topFontEl && topFontEl.value !== fontScale) topFontEl.value = fontScale;
  if (authFontEl && authFontEl.value !== fontScale) authFontEl.value = fontScale;

  if (showFeedbackToast && typeof showToast === "function") {
    const themeNames = {
      auto: `Adaptado a Maquina (${effectiveTheme === "dark" ? "Escuro" : "Claro"})`,
      light: "Tela Clara",
      dark: "Tela Escura"
    };
    showToast(`Visual atualizado: ${themeNames[themePref] || "Padrao"} | Fonte: ${fontScale}%`);
  }
}

function setThemePreference(pref) {
  const valid = ["auto", "light", "dark"].includes(pref) ? pref : "auto";
  localStorage.setItem("nexzap_theme_pref", valid);
  applyVisualAccessibilitySettings(true);
}

function setFontScalePreference(scale) {
  const valid = ["100", "115", "130", "145"].includes(String(scale)) ? String(scale) : "100";
  localStorage.setItem("nexzap_font_scale", valid);
  applyVisualAccessibilitySettings(true);
}

function initVisualAccessibility() {
  applyVisualAccessibilitySettings(false);
  try {
    if (window.matchMedia) {
      systemDarkMediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
      const onSystemThemeChange = () => {
        const currentPref = localStorage.getItem("nexzap_theme_pref") || "auto";
        if (currentPref === "auto") {
          applyVisualAccessibilitySettings(false);
        }
      };
      if (typeof systemDarkMediaQuery.addEventListener === "function") {
        systemDarkMediaQuery.addEventListener("change", onSystemThemeChange);
      } else if (typeof systemDarkMediaQuery.addListener === "function") {
        systemDarkMediaQuery.addListener(onSystemThemeChange);
      }
    }
  } catch (e) {}
}

// Aplica imediatamente antes mesmo do DOMContentLoaded terminar para evitar piscar tela
initVisualAccessibility();

/* ============================================================================
   ABA 9 + BARRA LATERAL: MONITORAR E RESPONDER WHATSAPP SELECIONADO AO VIVO
============================================================================ */
let monitoredChipId = parseInt(localStorage.getItem("nexzap_monitored_chip_id") || "1", 10);
let monitorState = {
  wa_state: "closed",
  chats: [],
  active_chat: { title: "", subtitle: "", phone: "", messages: [] },
  screenshot: null,
  selected_title: "",
  selected_phone: ""
};
let monitorPollTimer = null;
let monitorAutoRefreshEnabled = true;
let monitorFetching = false;

function renderSidebarAndMonitorChipSelectors() {
  const chips = appData.chips || [];
  if (chips.length > 0 && !chips.some(c => c.id === monitoredChipId)) {
    monitoredChipId = chips[0].id;
    localStorage.setItem("nexzap_monitored_chip_id", String(monitoredChipId));
  }

  const fullSel = document.getElementById("sidebar-wa-chip-select");
  const compactSel = document.getElementById("sidebar-wa-chip-select-compact");
  const mainSel = document.getElementById("monitor-main-chip-select");
  const dotEl = document.getElementById("sidebar-wa-monitor-dot");

  const activeChipObj = chips.find(c => c.id === monitoredChipId) || { id: monitoredChipId, name: `Chip #${monitoredChipId}`, phone: "", live_wa_status: "closed" };
  if (dotEl) {
    dotEl.style.background = activeChipObj.live_wa_status === "connected" ? "#10b981" : "#f59e0b";
  }

  if (chips.length === 0) {
    const emptyFull = `<option value="1">Sem Chips — Cadastre na Aba 4</option>`;
    const emptyComp = `<option value="1">#1</option>`;
    if (fullSel && fullSel.innerHTML !== emptyFull) fullSel.innerHTML = emptyFull;
    if (compactSel && compactSel.innerHTML !== emptyComp) compactSel.innerHTML = emptyComp;
    if (mainSel && mainSel.innerHTML !== emptyFull) mainSel.innerHTML = emptyFull;
    return;
  }

  const fullOptionsHtml = chips.map(c => {
    const st = c.live_wa_status === "connected" ? "Conectado" : "Ler QR";
    const ph = c.phone ? ` (+${escapeHtml(c.phone)})` : "";
    return `<option value="${c.id}">#${c.id} ${escapeHtml(c.name)}${ph} • [${st}]</option>`;
  }).join("");

  const compactOptionsHtml = chips.map(c => {
    const dot = c.live_wa_status === "connected" ? "ON" : "QR";
    return `<option value="${c.id}">#${c.id} (${dot})</option>`;
  }).join("");

  [fullSel, mainSel].forEach(sel => {
    if (!sel) return;
    if (sel.innerHTML !== fullOptionsHtml) sel.innerHTML = fullOptionsHtml;
    sel.value = String(monitoredChipId);
  });

  if (compactSel) {
    if (compactSel.innerHTML !== compactOptionsHtml) compactSel.innerHTML = compactOptionsHtml;
    compactSel.value = String(monitoredChipId);
  }

  const chipTag = document.getElementById("monitor-active-chip-tag");
  if (chipTag) {
    chipTag.textContent = `#${activeChipObj.id} • ${activeChipObj.name}`;
  }
}

function onSelectSidebarMonitorChip(newChipIdVal, openMonitorTab = true) {
  const parsed = parseInt(newChipIdVal || "1", 10);
  if (!isNaN(parsed) && parsed > 0) {
    monitoredChipId = parsed;
    localStorage.setItem("nexzap_monitored_chip_id", String(monitoredChipId));
  }
  monitorState.selected_title = "";
  monitorState.selected_phone = "";
  renderSidebarAndMonitorChipSelectors();

  if (openMonitorTab) {
    const navBtn = document.getElementById("side-nav-wa-monitor");
    switchTab("tab-wa-monitor", navBtn);
  }
  refreshWhatsAppMonitorNow(true);
}

function openWhatsAppMonitorFromSidebar() {
  const navBtn = document.getElementById("side-nav-wa-monitor");
  switchTab("tab-wa-monitor", navBtn);
  refreshWhatsAppMonitorNow(true);
}

function openQrForMonitoredChip() {
  openQrModal(monitoredChipId || 1);
}

function toggleMonitorAutoRefresh(enabled) {
  monitorAutoRefreshEnabled = Boolean(enabled);
  if (monitorAutoRefreshEnabled) {
    refreshWhatsAppMonitorNow(false);
  }
}

async function refreshWhatsAppMonitorNow(manual = false) {
  if (monitorFetching && !manual) return;
  monitorFetching = true;
  try {
    const res = await fetch("/api/whatsapp/monitor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chip_id: monitoredChipId || 1,
        include_screenshot: true,
        chat_title: monitorState.selected_title || "",
        phone: monitorState.selected_phone || ""
      })
    });
    const data = await res.json();
    if (data && data.ok) {
      monitorState.wa_state = data.wa_state || "closed";
      monitorState.chats = data.chats || [];
      monitorState.active_chat = data.active_chat || { title: "", subtitle: "", phone: "", messages: [] };
      monitorState.screenshot = data.screenshot || null;
      if (!monitorState.selected_title && monitorState.active_chat.title) {
        monitorState.selected_title = monitorState.active_chat.title;
        monitorState.selected_phone = monitorState.active_chat.phone || "";
      }
      renderWhatsAppMonitorView();
    }
  } catch (e) {
    console.error("Erro ao atualizar Monitor do WhatsApp:", e);
  } finally {
    monitorFetching = false;
  }
}

function renderWhatsAppMonitorView() {
  const statusBadge = document.getElementById("monitor-wa-status-badge");
  if (statusBadge) {
    if (monitorState.wa_state === "connected") {
      statusBadge.className = "badge badge-sent";
      statusBadge.textContent = "WhatsApp Conectado Ao Vivo";
    } else if (monitorState.wa_state === "qr_ready") {
      statusBadge.className = "badge badge-warn";
      statusBadge.textContent = "Aguardando Leitura do QR Code";
    } else {
      statusBadge.className = "badge badge-pending";
      statusBadge.textContent = "Janela Fechada / Modo Local (Clique em Conectar QR)";
    }
  }

  renderMonitorChatList();
  renderMonitorActiveConversation();

  const imgEl = document.getElementById("monitor-live-screenshot-img");
  const placeholderEl = document.getElementById("monitor-live-screen-placeholder");
  if (imgEl && placeholderEl) {
    if (monitorState.screenshot) {
      imgEl.src = monitorState.screenshot;
      imgEl.style.display = "block";
      placeholderEl.style.display = "none";
    } else {
      imgEl.style.display = "none";
      placeholderEl.style.display = "block";
    }
  }
}

let monitorChatFilterMode = "all";
let monitorRightViewMode = "chat";

function setMonitorChatFilter(mode) {
  monitorChatFilterMode = mode === "unread" ? "unread" : "all";
  const btnAll = document.getElementById("wa-filter-btn-all") || document.getElementById("btn-mon-filter-all");
  const btnUnread = document.getElementById("wa-filter-btn-unread") || document.getElementById("btn-mon-filter-unread");
  if (btnAll) {
    btnAll.className = monitorChatFilterMode === "all" ? "wa-filter-pill active" : "wa-filter-pill";
  }
  if (btnUnread) {
    btnUnread.className = monitorChatFilterMode === "unread" ? "wa-filter-pill active" : "wa-filter-pill";
  }
  renderMonitorChatList();
}

function switchMonitorRightMode(mode) {
  monitorRightViewMode = mode === "screen" ? "screen" : "chat";
  const btnChat = document.getElementById("btn-wa-mode-chat") || document.getElementById("btn-mon-mode-chat");
  const btnScreen = document.getElementById("btn-wa-mode-screen") || document.getElementById("btn-mon-mode-screen");
  const boxChat = document.getElementById("monitor-native-chat-panel") || document.getElementById("monitor-messages-container");
  const boxScreen = document.getElementById("monitor-original-screen-panel") || document.getElementById("monitor-screen-container");

  if (btnChat) {
    btnChat.className = monitorRightViewMode === "chat" ? "wa-view-mode-btn active" : "wa-view-mode-btn";
  }
  if (btnScreen) {
    btnScreen.className = monitorRightViewMode === "screen" ? "wa-view-mode-btn active" : "wa-view-mode-btn";
  }
  if (boxChat) boxChat.style.display = monitorRightViewMode === "chat" ? "flex" : "none";
  if (boxScreen) boxScreen.style.display = monitorRightViewMode === "screen" ? "flex" : "none";

  if (monitorRightViewMode === "screen") {
    refreshWhatsAppMonitorNow(true);
  }
}

function getAvatarInitials(titleStr) {
  const s = String(titleStr || "").trim();
  if (!s) return "WA";
  const words = s.replace(/[^\p{L}\p{N}\s]/gu, " ").trim().split(/\s+/).filter(Boolean);
  if (words.length >= 2 && /[A-Za-zÀ-ÿ]/.test(words[0])) {
    return (words[0][0] + words[1][0]).toUpperCase();
  }
  if (words.length === 1 && /[A-Za-zÀ-ÿ]/.test(words[0])) {
    return words[0].slice(0, 2).toUpperCase();
  }
  const digits = s.replace(/\D/g, "");
  return digits.length >= 2 ? digits.slice(-2) : "WA";
}

function renderMonitorChatList() {
  const listEl = document.getElementById("monitor-chats-list");
  const countEl = document.getElementById("monitor-chat-count");
  const unreadEl = document.getElementById("monitor-unread-badge");
  const query = (document.getElementById("monitor-chat-search")?.value || "").trim().toLowerCase();

  const allChats = monitorState.chats || [];
  if (countEl) countEl.textContent = String(allChats.length);

  const totalUnread = allChats.reduce((acc, c) => acc + (parseInt(c.unread_count || 0, 10) || 0), 0);
  if (unreadEl) {
    unreadEl.textContent = `${totalUnread} nao lida(s)`;
    unreadEl.className = totalUnread > 0 ? "badge badge-sent" : "badge badge-pending";
  }

  if (!listEl) return;

  let filtered = allChats;
  if (monitorChatFilterMode === "unread") {
    filtered = filtered.filter(c => (parseInt(c.unread_count || 0, 10) || 0) > 0);
  }
  if (query) {
    filtered = filtered.filter(c =>
      (c.title || "").toLowerCase().includes(query) ||
      (c.phone || "").toLowerCase().includes(query) ||
      (c.last_message || "").toLowerCase().includes(query)
    );
  }

  if (filtered.length === 0) {
    updateHtmlPreservingScrollAndFocus(listEl, `
      <div style="padding:22px 16px; text-align:center; color:var(--text-muted); font-size:12px; line-height:1.5;">
        Nenhuma conversa encontrada neste filtro.<br/>
        Digite um numero com DDD no campo acima e clique em <strong>Abrir Nº</strong> ou conecte o QR Code deste WhatsApp.
      </div>
    `);
    return;
  }

  const listHtml = filtered.map(c => {
    const isSel = Boolean(
      (monitorState.selected_title && (c.title || "").toLowerCase() === monitorState.selected_title.toLowerCase()) ||
      (!monitorState.selected_title && c.is_active)
    );
    const safeTitle = JSON.stringify(c.title || "").replace(/"/g, "&quot;");
    const safePhone = JSON.stringify(c.phone || "").replace(/"/g, "&quot;");
    const dispName = c.title || c.phone || "Contato";
    const initials = getAvatarInitials(dispName);
    const unreadBadge = c.unread_count > 0
      ? `<span class="badge badge-sent" style="font-size:10px; padding:2px 6px; border-radius:999px;">${c.unread_count}</span>`
      : "";

    return `
      <div class="wa-chat-item ${isSel ? "active" : ""}" onclick="selectMonitorChat(${safeTitle}, ${safePhone})">
        <div class="wa-chat-avatar">${escapeHtml(initials)}</div>
        <div style="min-width:0; flex:1;">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:6px; margin-bottom:3px;">
            <strong style="font-size:13px; color:var(--text-main); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
              ${escapeHtml(dispName)}
            </strong>
            <div style="display:flex; align-items:center; gap:5px; flex-shrink:0;">
              <span style="font-size:10.5px; color:${c.unread_count > 0 ? "var(--primary)" : "var(--text-muted)"}; font-weight:${c.unread_count > 0 ? "700" : "500"};">
                ${escapeHtml(c.time || "")}
              </span>
              ${unreadBadge}
            </div>
          </div>
          <div style="font-size:11.5px; color:var(--text-secondary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
            ${escapeHtml(c.last_message || "Clique para abrir a conversa")}
          </div>
        </div>
      </div>
    `;
  }).join("");
  updateHtmlPreservingScrollAndFocus(listEl, listHtml);
}

async function selectMonitorChat(title, phone) {
  monitorState.selected_title = title || "";
  monitorState.selected_phone = phone || "";
  renderMonitorChatList();

  const titleEl = document.getElementById("monitor-active-chat-title");
  const subEl = document.getElementById("monitor-active-chat-subtitle");
  const avEl = document.getElementById("monitor-active-chat-avatar") || document.getElementById("monitor-active-avatar");
  if (titleEl) titleEl.textContent = title || phone || "Conversa Selecionada";
  if (subEl) subEl.textContent = "Sincronizando mensagens em tempo real...";
  if (avEl) avEl.textContent = getAvatarInitials(title || phone || "WA");

  try {
    const res = await fetch("/api/whatsapp/open-chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chip_id: monitoredChipId || 1,
        chat_title: title || "",
        phone: phone || "",
        include_screenshot: true
      })
    });
    const data = await res.json();
    if (data && data.ok) {
      monitorState.wa_state = data.wa_state || monitorState.wa_state;
      monitorState.chats = data.chats || monitorState.chats;
      monitorState.active_chat = data.active_chat || { title: title, subtitle: phone, phone: phone, messages: [] };
      if (data.screenshot) monitorState.screenshot = data.screenshot;
      renderWhatsAppMonitorView();
    }
  } catch (e) {}
}

function openNewPhoneInMonitor() {
  const raw = (document.getElementById("monitor-chat-search")?.value || "").trim();
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 10) {
    showToast("Digite um numero com DDD (ex: 11999998888) para abrir a conversa.");
    return;
  }
  const cleanPhone = digits.startsWith("55") ? digits : `55${digits}`;
  selectMonitorChat(cleanPhone, cleanPhone);
}

function formatMessageTextWithLinks(rawText) {
  const safe = escapeHtml(rawText || "");
  return safe.replace(/(https?:\/\/[^\s<]+)/gi, '<a href="$1" target="_blank" rel="noopener" style="color:#38bdf8; text-decoration:underline; font-weight:600;">$1</a>');
}

function renderMonitorActiveConversation() {
  const active = monitorState.active_chat || {};
  const titleEl = document.getElementById("monitor-active-chat-title");
  const subEl = document.getElementById("monitor-active-chat-subtitle");
  const avEl = document.getElementById("monitor-active-chat-avatar") || document.getElementById("monitor-active-avatar");
  const boxEl = document.getElementById("monitor-messages-container");

  const dispTitle = active.title || monitorState.selected_title || "Selecione uma conversa ao lado";
  if (titleEl) titleEl.textContent = dispTitle;
  if (avEl) avEl.textContent = getAvatarInitials(dispTitle);
  if (subEl) {
    subEl.textContent = active.subtitle || active.phone || monitorState.selected_phone || "Clique em um contato ou grupo na coluna esquerda para ler e responder";
  }

  if (!boxEl) return;
  const msgs = active.messages || [];
  if (msgs.length === 0) {
    updateHtmlPreservingScrollAndFocus(boxEl, `
      <div style="margin:auto; text-align:center; color:var(--text-secondary); font-size:13px; padding:28px; line-height:1.6; max-width:460px; background:var(--bg-card); border:1px solid var(--border); border-radius:12px;">
        ${dispTitle !== "Selecione uma conversa ao lado"
          ? `Conversa com <strong>${escapeHtml(dispTitle)}</strong> aberta.<br/>Digite sua resposta na barra inferior e pressione <strong>Enter</strong> para enviar.`
          : "Clique em qualquer contato ou grupo na lista da esquerda para visualizar as mensagens em tela ampla e responder na hora."}
      </div>
    `);
    return;
  }

  const wasNearBottom = (boxEl.scrollHeight - boxEl.scrollTop - boxEl.clientHeight) < 80;
  const msgsHtml = msgs.map(m => {
    const isOut = m.direction === "out";
    const rowClass = isOut ? "wa-msg-row-out" : "wa-msg-row-in";
    const checkIcon = isOut ? ` <span class="wa-msg-check">✓✓</span>` : "";
    const senderLabel = isOut ? "Voce" : (m.sender || dispTitle);
    return `
      <div class="${rowClass}">
        <div class="wa-msg-sender">${escapeHtml(senderLabel)}</div>
        <div style="white-space:pre-wrap; word-break:break-word;">${formatMessageTextWithLinks(m.text || "")}</div>
        <div class="wa-msg-meta">
          <span>${escapeHtml(m.time || "")}</span>${checkIcon}
        </div>
      </div>
    `;
  }).join("");

  const changed = updateHtmlPreservingScrollAndFocus(boxEl, msgsHtml);
  if (changed && wasNearBottom) {
    boxEl.scrollTop = boxEl.scrollHeight;
  }
}

function fillQuickMonitorReply(templateText) {
  const area = document.getElementById("monitor-reply-textarea");
  if (!area) return;
  area.value = templateText;
  area.focus();
}

async function sendLiveMonitorReply() {
  const area = document.getElementById("monitor-reply-textarea");
  const btn = document.getElementById("btn-monitor-send-reply");
  const fb = document.getElementById("monitor-reply-feedback");
  const msg = (area?.value || "").trim();
  if (!msg) {
    showToast("Digite a sua resposta antes de enviar.");
    return;
  }

  const targetTitle = monitorState.selected_title || monitorState.active_chat?.title || "__OPEN__";
  const targetPhone = monitorState.selected_phone || monitorState.active_chat?.phone || "";

  if (btn) btn.disabled = true;
  if (fb) fb.textContent = "Enviando resposta pelo WhatsApp selecionado...";

  try {
    const res = await fetch("/api/whatsapp/reply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chip_id: monitoredChipId || 1,
        chat_title: targetTitle,
        phone: targetPhone,
        message: msg
      })
    });
    const data = await res.json();
    if (data && data.ok) {
      if (area) area.value = "";
      showToast(data.detail || "Resposta enviada com sucesso!");
      if (fb) fb.textContent = data.detail || "Resposta enviada!";
      await refreshWhatsAppMonitorNow(true);
    } else {
      showToast(data?.detail || "Erro ao enviar resposta.");
      if (fb) fb.textContent = data?.detail || "Falha ao enviar.";
    }
  } catch (e) {
    showToast("Erro de comunicacao ao enviar resposta.");
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function onClickInternalWhatsAppScreen(evt, imgEl) {
  if (!imgEl) return;
  const rect = imgEl.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const relX = Math.max(0.01, Math.min(0.99, (evt.clientX - rect.left) / rect.width));
  const relY = Math.max(0.01, Math.min(0.99, (evt.clientY - rect.top) / rect.height));

  try {
    const res = await fetch("/api/whatsapp/click-screen", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chip_id: monitoredChipId || 1,
        rel_x: relX,
        rel_y: relY
      })
    });
    const data = await res.json();
    if (data && data.ok) {
      monitorState.wa_state = data.wa_state || monitorState.wa_state;
      monitorState.chats = data.chats || monitorState.chats;
      monitorState.active_chat = data.active_chat || monitorState.active_chat;
      if (data.screenshot) monitorState.screenshot = data.screenshot;
      renderWhatsAppMonitorView();
    }
  } catch (e) {}
}

document.addEventListener("DOMContentLoaded", () => {
  initVisualAccessibility();
  renderSidebarAndMonitorChipSelectors();
  setTimeout(() => {
    renderSimulationVideoScene();
    resetSimulationVideoTimer();
  }, 300);

  if (monitorPollTimer) clearInterval(monitorPollTimer);
  monitorPollTimer = setInterval(() => {
    const monSec = document.getElementById("tab-wa-monitor");
    if (monSec && monSec.classList.contains("active") && monitorAutoRefreshEnabled) {
      refreshWhatsAppMonitorNow(false);
    }
  }, 3200);
});

