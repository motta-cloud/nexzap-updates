#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NexZap PRO v4.8 — Motor Real de Automação WhatsApp Web Multi-Chip (CDP)
Recursos:
1. Janelas do Chrome agrupadas em UM ÚNICO BLOCO na Barra de Tarefas do Windows (AppUserModelID unificado).
2. Captura ao vivo do QR Code do WhatsApp Web para exibir direto dentro do painel.
3. Extração Direta de Grupos e Participantes (100% dos membros + Nome Real / Pushname + Telefone)
   via Store Interno do WhatsApp Web (WAWebCollections) + IndexedDB (model-storage) + Auto-Scroll DOM,
   sem precisar abrir manualmente o grupo no WhatsApp e sem confundir subtítulo de membros com nome do grupo.
4. Disparo Direto para Contatos de Grupos (com 15 Variações Automáticas da mensagem digitada) e Disparo no Grupo.
"""

import base64
import ctypes
from ctypes import wintypes
import json
import os
import re
import socket
import struct
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path

CHROME_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

UNIFIED_TASKBAR_APP_ID = "Google.Chrome.NexZapCluster"


def find_browser_executable() -> str:
    for p in CHROME_PATHS:
        if os.path.exists(p):
            return p
    return "chrome.exe"


def is_port_open(port: int) -> bool:
    """Verificação ultra-rápida (25ms) se a porta local do Chrome está aberta."""
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.03):
            return True
    except Exception:
        return False


# ==============================================================================
# AGRUPADOR NATIVO WIN32 PARA BARRA DE TAREFAS DO WINDOWS (BLOCO ÚNICO)
# ==============================================================================

if os.name == "nt":
    class GUID(ctypes.Structure):
        _fields_ = [
            ("Data1", wintypes.DWORD),
            ("Data2", wintypes.WORD),
            ("Data3", wintypes.WORD),
            ("Data4", ctypes.c_ubyte * 8)
        ]

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [
            ("fmtid", GUID),
            ("pid", wintypes.DWORD)
        ]

    class PROPVARIANT(ctypes.Structure):
        _fields_ = [
            ("vt", wintypes.USHORT),
            ("wReserved1", wintypes.USHORT),
            ("wReserved2", wintypes.USHORT),
            ("wReserved3", wintypes.USHORT),
            ("pwszVal", wintypes.LPWSTR),
            ("pad", ctypes.c_ulonglong)
        ]

    IID_IPropertyStore = GUID(
        0x886D8EEB, 0x8CF2, 0x4446,
        (ctypes.c_ubyte * 8)(0x8D, 0x02, 0xCD, 0xBA, 0x1D, 0xBD, 0xCF, 0x99)
    )
    PKEY_AppUserModel_ID = PROPERTYKEY(
        GUID(
            0x9F4C2855, 0x9F79, 0x4B39,
            (ctypes.c_ubyte * 8)(0xA8, 0xD0, 0xE1, 0xD4, 0x2D, 0xE1, 0xD5, 0xF3)
        ),
        5
    )


def _set_window_app_user_model_id(hwnd: int, app_id: str = UNIFIED_TASKBAR_APP_ID) -> bool:
    """Força a janela (HWND) a compartilhar o mesmo AppUserModelID na Barra de Tarefas do Windows."""
    if os.name != "nt":
        return False
    try:
        store = ctypes.c_void_p()
        hr = ctypes.windll.shell32.SHGetPropertyStoreForWindow(
            wintypes.HWND(hwnd),
            ctypes.byref(IID_IPropertyStore),
            ctypes.byref(store)
        )
        if hr != 0 or not store.value:
            return False

        vt_table = ctypes.cast(
            ctypes.cast(store, ctypes.POINTER(ctypes.c_void_p))[0],
            ctypes.POINTER(ctypes.c_void_p)
        )
        SetValueProto = ctypes.WINFUNCTYPE(
            ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT)
        )
        CommitProto = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)
        ReleaseProto = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)

        prop = PROPVARIANT()
        prop.vt = 31  # VT_LPWSTR
        prop.pwszVal = app_id

        SetValueProto(vt_table[6])(store, ctypes.byref(PKEY_AppUserModel_ID), ctypes.byref(prop))
        CommitProto(vt_table[7])(store)
        ReleaseProto(vt_table[2])(store)
        return True
    except Exception:
        return False


def unify_all_whatsapp_windows_taskbar_group(target_pids: set = None, minimize_all: bool = False) -> int:
    """
    Percorre todas as janelas abertas do WhatsApp Web / Chrome de Chips no Windows e aplica
    exatamente o mesmo AppUserModelID para que o Windows 10/11 empilhe todas (de 1 a 100 telas)
    dentro de UM ÚNICO BLOCO na Barra de Tarefas.
    """
    if os.name != "nt":
        return 0

    grouped_count = [0]
    user32 = ctypes.windll.user32

    EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def _callback(hwnd, lParam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            title = (buf.value or "").lower()

            cls_buf = ctypes.create_unicode_buffer(64)
            user32.GetClassNameW(hwnd, cls_buf, 64)
            cls_name = cls_buf.value or ""

            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))

            is_chrome_widget = "Chrome_WidgetWin" in cls_name
            is_wa_title = "whatsapp" in title or "web.whatsapp" in title
            is_target_pid = bool(target_pids and pid.value in target_pids)

            if is_chrome_widget and (is_wa_title or is_target_pid):
                if _set_window_app_user_model_id(hwnd, UNIFIED_TASKBAR_APP_ID):
                    grouped_count[0] += 1
                if minimize_all:
                    user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(EnumWindowsProc(_callback), 0)
    except Exception:
        pass
    return grouped_count[0]


def close_visible_whatsapp_chrome_windows() -> list:
    """
    Localiza e fecha imediatamente qualquer janela visivel do Chrome do WhatsApp Web
    na Barra de Tarefas do Windows (preservando a janela do painel NexZap PRO),
    para que toda a operacao rode 100% interna e invisivel sem pesar o computador.
    """
    if os.name != "nt":
        return []

    closed_pids = []
    user32 = ctypes.windll.user32
    WM_CLOSE = 0x0010
    EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def _cb(hwnd, lParam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            title = (buf.value or "").lower()

            if "nexzap" in title:
                try:
                    ico_file = str(Path(__file__).resolve().parent / "public" / "brand" / "nexzap_icon.ico")
                    if os.path.exists(ico_file):
                        IMAGE_ICON = 1
                        LR_LOADFROMFILE = 0x0010
                        WM_SETICON = 0x0080
                        h_icon_big = user32.LoadImageW(None, ico_file, IMAGE_ICON, 48, 48, LR_LOADFROMFILE)
                        h_icon_small = user32.LoadImageW(None, ico_file, IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
                        if h_icon_big:
                            user32.SendMessageW(hwnd, WM_SETICON, 1, h_icon_big)
                        if h_icon_small:
                            user32.SendMessageW(hwnd, WM_SETICON, 0, h_icon_small)
                        _set_window_app_user_model_id(hwnd, "NexZapPRO.Institutional.App")
                except Exception:
                    pass
                return True

            cls_buf = ctypes.create_unicode_buffer(64)
            user32.GetClassNameW(hwnd, cls_buf, 64)
            cls_name = cls_buf.value or ""

            if "Chrome_WidgetWin" in cls_name and ("whatsapp" in title or "web.whatsapp" in title):
                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
                if pid.value:
                    closed_pids.append(pid.value)
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(EnumWindowsProc(_cb), 0)
    except Exception:
        pass
    return closed_pids



# ==============================================================================
# CLIENTE CHROME DEVTOOLS PROTOCOL (CDP) EM PYTHON PURO
# ==============================================================================

class SimpleCDPClient:
    """Cliente WebSocket RFC-6455 em Python puro para controlar o Chrome DevTools Protocol."""

    def __init__(self, ws_url: str, timeout: float = 12.0):
        parsed = urllib.parse.urlparse(ws_url)
        self.host = parsed.hostname or "127.0.0.1"
        self.port = parsed.port or 9222
        self.path = parsed.path or "/"
        self.sock = socket.create_connection((self.host, self.port), timeout=timeout)
        self._handshake()
        self.msg_id = 0

    def _handshake(self):
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        req = (
            f"GET {self.path} HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            f"Upgrade: websocket\r\n"
            f"Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            f"Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(req.encode("ascii"))
        resp = b""
        while b"\r\n\r\n" not in resp:
            chunk = self.sock.recv(1024)
            if not chunk:
                break
            resp += chunk

    def send_command(self, method: str, params: dict = None) -> dict:
        self.msg_id += 1
        payload = json.dumps({"id": self.msg_id, "method": method, "params": params or {}}).encode("utf-8")
        self._send_frame(payload)
        while True:
            msg = self._recv_frame()
            if not msg:
                return {}
            data = json.loads(msg.decode("utf-8", errors="ignore"))
            if data.get("id") == self.msg_id:
                return data

    def _send_frame(self, data: bytes):
        mask_key = os.urandom(4)
        header = bytearray([0x81])
        length = len(data)
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
        header.extend(mask_key)
        masked = bytearray(b ^ mask_key[i % 4] for i, b in enumerate(data))
        self.sock.sendall(header + masked)

    def _recv_exact(self, n: int) -> bytes:
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                break
            buf += chunk
        return buf

    def _recv_frame(self) -> bytes:
        head = self._recv_exact(2)
        if len(head) < 2:
            return b""
        length = head[1] & 0x7F
        if length == 126:
            length = struct.unpack("!H", self._recv_exact(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", self._recv_exact(8))[0]
        masked = bool(head[1] & 0x80)
        mask_key = self._recv_exact(4) if masked else b""
        payload = self._recv_exact(length)
        if masked:
            payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        return payload

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


# ==============================================================================
# GERENCIADOR MULTI-CHIP DO WHATSAPP WEB (1 A 100 CHIPS SIMULTÂNEOS)
# ==============================================================================

class WhatsAppWebMultiChipManager:
    def __init__(self, base_data_dir: Path):
        self.sessions_dir = base_data_dir / "chrome_sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.processes = {}
        self.headless_ports = set()
        self.status_cache = {}
        self._lock = threading.Lock()

    def get_port(self, chip_id: int) -> int:
        return 9230 + int(chip_id)

    def _get_wa_target(self, chip_id: int) -> dict:
        port = self.get_port(chip_id)
        if not is_port_open(port):
            return {}
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=0.6) as resp:
                targets = json.loads(resp.read().decode("utf-8"))
                for t in targets:
                    if t.get("type") == "page" and "whatsapp.com" in t.get("url", ""):
                        return t
                for t in targets:
                    if t.get("type") == "page":
                        return t
        except Exception:
            pass
        return {}

    def close_chip_session(self, chip_id: int) -> bool:
        """Encerra o motor em segundo plano de um chip especifico, liberando 100% da memoria RAM (mantendo o login salvo em disco)."""
        port = self.get_port(chip_id)
        target = self._get_wa_target(chip_id)
        if target and target.get("webSocketDebuggerUrl"):
            try:
                cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=1.5)
                cdp.send_command("Browser.close")
                cdp.close()
            except Exception:
                pass
        proc = self.processes.pop(chip_id, None)
        if proc:
            try:
                proc.terminate()
            except Exception:
                pass
        self.headless_ports.discard(port)
        return True

    def hibernate_other_chips(self, keep_chip_ids: set):
        """
        Mantem apenas o chip ativo na memoria RAM e hiberna os demais (sem perder a sessao do QR Code),
        garantindo que o computador fique super leve e sem processos desnecessarios.
        """
        for cid in list(self.processes.keys()):
            if cid not in keep_chip_ids:
                self.close_chip_session(cid)

    def regroup_taskbar_windows(self, minimize_all: bool = False) -> dict:
        """
        Fecha qualquer janela externa visivel do Chrome do WhatsApp Web e mantem
        toda a operacao 100% interna e invisivel dentro do proprio NexZap PRO.
        """
        closed_vis = close_visible_whatsapp_chrome_windows()
        return {
            "ok": True,
            "grouped_windows": len(closed_vis),
            "minimized": True,
            "detail": "Janelas externas do Chrome encerradas! Operacao 100% interna e leve ativada."
        }

    def launch_chip_session(self, chip_id: int, hibernate_others: bool = False) -> dict:
        """
        Inicia o motor interno invisivel (--headless=new + CREATE_NO_WINDOW) para este chip:
        - ZERO janelas do Chrome abertas na Barra de Tarefas do Windows;
        - Baixissimo consumo de memoria RAM e CPU (sem interface grafica externa e 1 unico processo renderer);
        - Mantem todos os chips conectados ativos simultaneamente em segundo plano para nao interromper disparos Multi-Chip nem Auto-Respostas IA!
        """
        close_visible_whatsapp_chrome_windows()

        if hibernate_others:
            self.hibernate_other_chips({int(chip_id)})

        port = self.get_port(chip_id)
        if is_port_open(port):
            self.headless_ports.add(port)
            return {"ok": True, "status": "already_open_internal", "port": port}

        browser_exe = find_browser_executable()
        profile_dir = self.sessions_dir / f"chip_{chip_id}"
        profile_dir.mkdir(parents=True, exist_ok=True)

        # Remover arquivos de trava orfaos caso o processo anterior tenha sido fechado
        for lock_name in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
            lock_path = profile_dir / lock_name
            if lock_path.exists():
                try:
                    lock_path.unlink()
                except Exception:
                    pass

        args = [
            browser_exe,
            f"--user-data-dir={profile_dir}",
            f"--remote-debugging-port={port}",
            "--remote-allow-origins=*",
            "--headless=new",
            "--disable-gpu",
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-extensions",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-background-networking",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
            "--disable-sync",
            "--disable-translate",
            "--disable-component-update",
            "--disable-default-apps",
            "--mute-audio",
            "--window-size=1020,740",
            "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "https://web.whatsapp.com"
        ]
        creationflags = 0
        if os.name == "nt":
            creationflags = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
        proc = subprocess.Popen(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags
        )
        self.processes[chip_id] = proc
        self.headless_ports.add(port)
        self.status_cache[chip_id] = "loading"

        return {"ok": True, "status": "launched_internal_headless", "port": port}

    def check_chip_connection_fast(self, chip_id: int) -> str:
        """Retorna imediatamente sem bloquear a thread HTTP."""
        port = self.get_port(chip_id)
        if not is_port_open(port):
            self.status_cache[chip_id] = "closed"
            return "closed"
        return self.status_cache.get(chip_id, "qr_pending")

    def probe_live_state_and_screenshot(self, chip_id: int) -> dict:
        close_visible_whatsapp_chrome_windows()
        port = self.get_port(chip_id)
        if not is_port_open(port):
            self.status_cache[chip_id] = "closed"
            return {"status": "closed", "screenshot": None}

        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return {"status": "loading", "screenshot": None}

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=3.0)
            js_check = """
            (() => {
                try {
                    const dismissWords = ['continuar', 'continue', 'ok', 'entendi', 'got it', 'usar aqui', 'use here', 'agora não', 'not now'];
                    const btns = Array.from(document.querySelectorAll('div[role="dialog"] button, [data-animate-modal-popup="true"] button, button'));
                    for (const b of btns) {
                        const txt = (b.innerText || b.textContent || '').trim().toLowerCase();
                        if (dismissWords.includes(txt)) b.click();
                    }
                } catch (e) {}
                const hasPane = !!document.querySelector('#pane-side') || !!document.querySelector('[data-testid="chat-list"]');
                if (hasPane) return 'connected';
                const hasQr = !!document.querySelector('canvas') || document.body.innerText.includes('Aponte seu celular') || document.body.innerText.includes('Passos para acessar');
                return hasQr ? 'qr_ready' : 'loading';
            })()
            """
            res = cdp.send_command("Runtime.evaluate", {"expression": js_check, "returnByValue": True})
            state = res.get("result", {}).get("result", {}).get("value", "loading")
            self.status_cache[chip_id] = "connected" if state == "connected" else "qr_pending"

            try:
                cdp.send_command("Page.bringToFront")
            except Exception:
                pass
            shot_res = cdp.send_command("Page.captureScreenshot", {"format": "jpeg", "quality": 80})
            b64_img = shot_res.get("result", {}).get("data")
            cdp.close()
            return {
                "status": state,
                "state": state,
                "screenshot": f"data:image/jpeg;base64,{b64_img}" if b64_img else None,
                "screenshot_b64": b64_img
            }
        except Exception:
            return {"status": "loading", "state": "loading", "screenshot": None, "screenshot_b64": None}

    def check_unread_incoming_messages(self, chip_id: int) -> list:
        if self.check_chip_connection_fast(chip_id) != "connected":
            return []
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return []
        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=2.5)
            js_unread = """
            (() => {
                const results = [];
                const badges = document.querySelectorAll('span[aria-label*="não lida"], span[aria-label*="unread"]');
                badges.forEach(b => {
                    const row = b.closest('[role="listitem"]') || b.closest('[data-testid="cell-frame-container"]');
                    if (row) {
                        const titleEl = row.querySelector('span[title]');
                        const title = titleEl ? titleEl.getAttribute('title') : '';
                        const textLines = (row.innerText || '').split('\\n').filter(Boolean);
                        const lastMsg = textLines.length > 1 ? textLines[textLines.length - 1] : '';
                        if (title) results.push({ sender: title, text: lastMsg });
                    }
                });
                return JSON.stringify(results);
            })()
            """
            res = cdp.send_command("Runtime.evaluate", {"expression": js_unread, "returnByValue": True})
            cdp.close()
            raw_val = res.get("result", {}).get("result", {}).get("value", "[]")
            return json.loads(raw_val)
        except Exception:
            return []

    def ensure_chip_ready_for_dispatch(self, chip_id: int) -> str:
        """
        Garante que o chip esteja acordado no motor interno invisivel (--headless=new) antes de um disparo.
        Se o chip ja tem sessao salva em disco e estava fechado, acorda automaticamente sem interromper nenhum outro chip.
        """
        port = self.get_port(chip_id)
        if not is_port_open(port):
            profile_dir = self.sessions_dir / f"chip_{chip_id}"
            if profile_dir.exists():
                self.launch_chip_session(chip_id, hibernate_others=False)
                for _ in range(12):
                    time.sleep(0.5)
                    probe = self.probe_live_state_and_screenshot(chip_id)
                    if probe.get("state") == "connected":
                        return "connected"
            return "closed"
        st = self.check_chip_connection_fast(chip_id)
        if st != "connected":
            probe = self.probe_live_state_and_screenshot(chip_id)
            st = probe.get("state", "closed")
        return st

    def send_real_whatsapp_message(self, chip_id: int, phone: str, message: str) -> tuple:
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            self.ensure_chip_ready_for_dispatch(chip_id)
            target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return False, "Chip desconectado"

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=12.0)
            encoded_text = urllib.parse.quote(message)
            clean_phone = "".join(ch for ch in str(phone) if ch.isdigit())
            has_url = bool(re.search(r"https?://\S+", message or "", flags=re.IGNORECASE))

            open_chat_js = f"""
            (() => {{
                let a = document.getElementById('nexzap-spa-link');
                if (!a) {{
                    a = document.createElement('a');
                    a.id = 'nexzap-spa-link';
                    document.body.appendChild(a);
                }}
                a.href = 'https://web.whatsapp.com/send?phone={clean_phone}&text={encoded_text}';
                a.click();
                return true;
            }})()
            """
            cdp.send_command("Runtime.evaluate", {"expression": open_chat_js})

            # Etapa 1: Aguardar a caixa de mensagem ou botao de envio carregar
            chat_ready = False
            for _ in range(16):
                time.sleep(0.45)
                check_ready_js = """
                (() => {
                    const invalidModal = document.body.innerText.includes('número de telefone compartilhado por url é inválido')
                                      || document.body.innerText.includes('phone number shared via url is invalid');
                    if (invalidModal) return 'INVALID_NUMBER';
                    const box = document.querySelector('#main footer div[contenteditable="true"]')
                             || document.querySelector('div[contenteditable="true"][data-tab="10"]');
                    const sendBtn =
                        document.querySelector('span[data-icon="send"]') ||
                        document.querySelector('span[data-icon="wds-ic-send-filled"]') ||
                        document.querySelector('button[aria-label="Enviar"]') ||
                        document.querySelector('button[aria-label="Send"]');
                    if (box || sendBtn) return 'READY';
                    return 'WAITING';
                })()
                """
                res = cdp.send_command("Runtime.evaluate", {"expression": check_ready_js, "returnByValue": True})
                status_val = res.get("result", {}).get("result", {}).get("value", "WAITING")
                if status_val == "INVALID_NUMBER":
                    cdp.close()
                    return False, "Numero invalido"
                if status_val == "READY":
                    chat_ready = True
                    break

            # Etapa 2: Se a mensagem contem link (http/https), acionar detector de URL do WhatsApp Web
            # e aguardar o card de Previa do Link (OpenGraph Thumbnail + Titulo + Descricao) carregar antes de enviar!
            if chat_ready and has_url:
                trigger_link_preview_js = """
                (() => {
                    const box = document.querySelector('#main footer div[contenteditable="true"]')
                             || document.querySelector('div[contenteditable="true"][data-tab="10"]');
                    if (box) {
                        box.focus();
                        box.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ' ' }));
                    }
                    return true;
                })()
                """
                cdp.send_command("Runtime.evaluate", {"expression": trigger_link_preview_js})
                # Aguardar ate 3.2s pela renderizacao do cartao de previa de link do WhatsApp Web
                for step_wait in range(8):
                    time.sleep(0.4)
                    check_preview_js = """
                    (() => {
                        const mainEl = document.querySelector('#main');
                        if (!mainEl) return 'NO_MAIN';
                        const previewSelectors = [
                            '[data-testid*="link-preview"]',
                            '[data-testid*="media-url"]',
                            'footer a[href^="http"]',
                            '#main footer img',
                            '#main [role="button"] span[dir="auto"]'
                        ];
                        for (const sel of previewSelectors) {
                            const el = mainEl.querySelector(sel);
                            if (el && el.offsetHeight > 18) return 'PREVIEW_LOADED';
                        }
                        return 'LOADING_PREVIEW';
                    })()
                    """
                    p_res = cdp.send_command("Runtime.evaluate", {"expression": check_preview_js, "returnByValue": True})
                    p_val = p_res.get("result", {}).get("result", {}).get("value", "")
                    if p_val == "PREVIEW_LOADED" and step_wait >= 3:
                        time.sleep(0.35)
                        break

            # Etapa 3: Clicar no botao Enviar com a previa rica do link anexada
            sent = False
            for _ in range(6):
                click_send_js = """
                (() => {
                    const sendBtn =
                        document.querySelector('span[data-icon="send"]') ||
                        document.querySelector('span[data-icon="wds-ic-send-filled"]') ||
                        document.querySelector('button[aria-label="Enviar"]') ||
                        document.querySelector('button[aria-label="Send"]');
                    if (sendBtn) {
                        const clickable = sendBtn.closest('button') || sendBtn;
                        clickable.click();
                        return 'CLICKED_SEND';
                    }
                    return 'WAITING';
                })()
                """
                res = cdp.send_command("Runtime.evaluate", {"expression": click_send_js, "returnByValue": True})
                if res.get("result", {}).get("result", {}).get("value") == "CLICKED_SEND":
                    sent = True
                    break
                time.sleep(0.3)

            if not sent:
                cdp.send_command("Input.dispatchKeyEvent", {"type": "keyDown", "windowsVirtualKeyCode": 13, "key": "Enter", "code": "Enter"})
                cdp.send_command("Input.dispatchKeyEvent", {"type": "keyUp", "windowsVirtualKeyCode": 13, "key": "Enter", "code": "Enter"})

            time.sleep(0.5)
            cdp.close()
            return True, "Enviado via WhatsApp Real"
        except Exception as e:
            return False, str(e)[:50]

    def send_whatsapp_media_and_conversation(
        self,
        chip_id: int,
        phone: str,
        caption_or_text: str = "",
        media_type: str = "texto",
        media_base64: str = "",
        media_filename: str = "",
        media_mime: str = "",
        wait_sec: float = 0.0,
        typing_sec: float = 0.0,
        recording_sec: float = 0.0
    ) -> tuple:
        """
        Envia Mensagens, Imagens, Videos, Audios (formato conversa / PTT), Documentos, Figurinhas,
        PIX, Convite de Grupo, Cartao de Contato, Link com Banner ou Lista como uma conversa real do WhatsApp:
        - Aplica os Temporizadores configurados (Esperar em segundos, Exibir que esta digitando, Exibir que um audio esta sendo gravado);
        - Injeta o arquivo de midia (Imagem, Video, Audio, Documento ou Figurinha) diretamente no composer da conversa via DataTransfer / ClipboardEvent;
        - Insere a Legenda (com as 15 variacoes semanticas aplicadas) junto ao disparo!
        """
        if wait_sec and float(wait_sec) > 0:
            time.sleep(min(60.0, float(wait_sec)))

        m_type = (media_type or "texto").strip().lower()
        clean_b64 = (media_base64 or "").strip()
        if "," in clean_b64 and clean_b64.startswith("data:"):
            clean_b64 = clean_b64.split(",", 1)[1].strip()

        # Se nao ha arquivo binario anexado (ex: texto, pix, convite_grupo, lista, link_banner, respostas_rapidas, contato)
        if not clean_b64 or m_type in ("texto", "respostas_rapidas", "pix", "convite_grupo", "contato", "link_banner", "lista"):
            if typing_sec and float(typing_sec) > 0:
                self._simulate_chat_presence(chip_id, phone, mode="typing", duration_sec=float(typing_sec))
            elif recording_sec and float(recording_sec) > 0:
                self._simulate_chat_presence(chip_id, phone, mode="recording", duration_sec=float(recording_sec))
            return self.send_real_whatsapp_message(chip_id, phone, caption_or_text)

        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            self.ensure_chip_ready_for_dispatch(chip_id)
            target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return False, "Chip desconectado"

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=22.0)
            clean_phone = "".join(ch for ch in str(phone) if ch.isdigit())

            # 1. Abrir a conversa com o contato sem recarregar a SPA
            open_chat_js = f"""
            (() => {{
                let a = document.getElementById('nexzap-spa-link');
                if (!a) {{
                    a = document.createElement('a');
                    a.id = 'nexzap-spa-link';
                    document.body.appendChild(a);
                }}
                a.href = 'https://web.whatsapp.com/send?phone={clean_phone}';
                a.click();
                return true;
            }})()
            """
            cdp.send_command("Runtime.evaluate", {"expression": open_chat_js})

            chat_ready = False
            for _ in range(18):
                time.sleep(0.45)
                check_js = """
                (() => {
                    const invalidModal = document.body.innerText.includes('número de telefone compartilhado por url é inválido')
                                      || document.body.innerText.includes('phone number shared via url is invalid');
                    if (invalidModal) return 'INVALID_NUMBER';
                    const box = document.querySelector('#main footer div[contenteditable="true"]')
                             || document.querySelector('div[contenteditable="true"][data-tab="10"]');
                    return box ? 'READY' : 'WAITING';
                })()
                """
                res = cdp.send_command("Runtime.evaluate", {"expression": check_js, "returnByValue": True})
                val = res.get("result", {}).get("result", {}).get("value", "WAITING")
                if val == "INVALID_NUMBER":
                    cdp.close()
                    return False, "Numero invalido"
                if val == "READY":
                    chat_ready = True
                    break

            if not chat_ready:
                cdp.close()
                return False, "Conversa nao abriu a tempo"

            # 2. Simular Temporizadores de Presenca ("digitando..." ou "gravando audio...") na conversa aberta
            if m_type == "audio" and (not recording_sec or float(recording_sec) <= 0):
                recording_sec = 2.0
            if recording_sec and float(recording_sec) > 0:
                self._trigger_presence_in_open_chat(cdp, mode="recording", duration_sec=float(recording_sec))
            elif typing_sec and float(typing_sec) > 0:
                self._trigger_presence_in_open_chat(cdp, mode="typing", duration_sec=float(typing_sec))

            # 3. Determinar MIME e nome de arquivo no formato nativo de conversa do WhatsApp
            fname = (media_filename or "").strip()
            mime = (media_mime or "").strip().lower()
            if m_type == "imagem":
                mime = mime or "image/jpeg"
                fname = fname or "imagem_conversa.jpg"
            elif m_type == "video":
                mime = "video/mp4"
                fname = fname if fname.lower().endswith(".mp4") else "video_conversa.mp4"
            elif m_type == "audio":
                if not mime or "audio" not in mime:
                    mime = "audio/ogg; codecs=opus" if fname.lower().endswith(".ogg") else "audio/mpeg"
                fname = fname or "audio_conversa.ogg"
            elif m_type == "figurinha":
                mime = "image/webp" if fname.lower().endswith(".webp") else (mime or "image/png")
                fname = fname or "figurinha.webp"
            else:
                mime = mime or "application/pdf"
                fname = fname or "documento.pdf"

            safe_b64 = json.dumps(clean_b64)
            safe_fname = json.dumps(fname)
            safe_mime = json.dumps(mime)
            safe_caption = json.dumps((caption_or_text or "").strip())
            safe_mtype = json.dumps(m_type)

            # 4. Injetar o arquivo de midia na conversa e preencher a legenda variavel
            inject_media_js = f"""
            (async () => {{
                const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                const b64 = {safe_b64};
                const fileName = {safe_fname};
                const mimeType = {safe_mime};
                const captionText = {safe_caption};
                const mType = {safe_mtype};

                const byteChars = atob(b64);
                const byteNumbers = new Array(byteChars.length);
                for (let i = 0; i < byteChars.length; i++) {{
                    byteNumbers[i] = byteChars.charCodeAt(i);
                }}
                const byteArray = new Uint8Array(byteNumbers);
                const fileObj = new File([byteArray], fileName, {{ type: mimeType, lastModified: Date.now() }});
                const dt = new DataTransfer();
                dt.items.add(fileObj);

                const composerBox = document.querySelector('#main footer div[contenteditable="true"]')
                                 || document.querySelector('div[contenteditable="true"][data-tab="10"]');
                const mainPane = document.querySelector('#main') || document.body;

                // Tentar ClipboardEvent('paste') no composer (abre instantaneamente o preview de imagem/video/audio/doc no WhatsApp Web)
                let openedPreview = false;
                if (composerBox) {{
                    composerBox.focus();
                    const pasteEv = new ClipboardEvent('paste', {{
                        bubbles: true,
                        cancelable: true,
                        clipboardData: dt
                    }});
                    composerBox.dispatchEvent(pasteEv);
                    await sleep(950);
                }}

                // Verificar se a gaveta de preview de midia abriu
                const hasMediaDrawer = () => {{
                    return !!(
                        document.querySelector('[data-animate-media-viewer="true"]') ||
                        document.querySelector('div[aria-label*="Enviar"], div[aria-label*="Send"] span[data-icon="send"]') ||
                        document.querySelector('span[data-icon="send"], span[data-icon="wds-ic-send-filled"]') && !document.querySelector('#main footer span[data-icon="send"]')
                    );
                }};

                if (!hasMediaDrawer()) {{
                    // Fallback: Drag & Drop direto no painel #main da conversa
                    for (const evName of ['dragenter', 'dragover', 'drop']) {{
                        const dragEv = new DragEvent(evName, {{
                            bubbles: true,
                            cancelable: true,
                            dataTransfer: dt
                        }});
                        mainPane.dispatchEvent(dragEv);
                    }}
                    await sleep(1100);
                }}

                // Se houver legenda e for imagem/video/documento, inserir a legenda no campo de legenda do preview
                if (captionText && mType !== 'audio' && mType !== 'figurinha') {{
                    const allEditables = Array.from(document.querySelectorAll('div[contenteditable="true"]'));
                    const captionBox = allEditables.find(el => !el.closest('#main footer') && !el.closest('#pane-side'));
                    if (captionBox) {{
                        captionBox.focus();
                        document.execCommand('insertText', false, captionText);
                        await sleep(400);
                    }}
                }}

                // Clicar no botao Enviar do preview de midia
                for (let attempt = 0; attempt < 10; attempt++) {{
                    const sendIcons = Array.from(document.querySelectorAll(
                        'span[data-icon="send"], span[data-icon="wds-ic-send-filled"], div[role="button"][aria-label="Enviar"], button[aria-label="Enviar"], div[role="button"][aria-label="Send"]'
                    ));
                    // Priorizar botao de envio fora do #main footer (do modal de midia)
                    const mediaSend = sendIcons.find(el => !el.closest('#main footer')) || sendIcons[0];
                    if (mediaSend) {{
                        const btn = mediaSend.closest('[role="button"]') || mediaSend.closest('button') || mediaSend;
                        btn.click();
                        await sleep(750);
                        return 'MEDIA_SENT';
                    }}
                    await sleep(350);
                }}
                return 'MEDIA_TIMEOUT';
            }})()
            """
            res = cdp.send_command(
                "Runtime.evaluate",
                {"expression": inject_media_js, "awaitPromise": True, "returnByValue": True}
            )
            outcome = res.get("result", {}).get("result", {}).get("value", "MEDIA_TIMEOUT")
            cdp.close()

            # Se for Audio (ou Figurinha) e o operador tambem colocou Legenda Variavel junto ao disparo,
            # envia a legenda logo em seguida na mesma conversa!
            if outcome == "MEDIA_SENT":
                if caption_or_text and caption_or_text.strip() and m_type in ("audio", "figurinha"):
                    time.sleep(0.8)
                    if typing_sec and float(typing_sec) > 0:
                        self._simulate_chat_presence(chip_id, phone, mode="typing", duration_sec=min(5.0, float(typing_sec)))
                    self.send_real_whatsapp_message(chip_id, phone, caption_or_text.strip())
                return True, f"Midia ({m_type.upper()}) enviada na conversa com sucesso"

            # Fallback caso o arquivo nao tenha aberto o modal: envia a legenda/mensagem para nao perder o disparo
            if caption_or_text and caption_or_text.strip():
                return self.send_real_whatsapp_message(chip_id, phone, caption_or_text.strip())
            return False, f"Nao foi possivel anexar midia ({outcome})"
        except Exception as e:
            return False, str(e)[:60]

    def _trigger_presence_in_open_chat(self, cdp: SimpleCDPClient, mode: str = "typing", duration_sec: float = 2.0):
        """Aciona o estado real 'digitando...' ou 'gravando audio...' na conversa aberta do WhatsApp Web."""
        dur = max(0.5, min(15.0, float(duration_sec or 2.0)))
        safe_mode = json.dumps(mode)
        presence_js = f"""
        (() => {{
            try {{
                const mode = {safe_mode};
                if (typeof window.require === 'function') {{
                    const ChatCol = window.require('WAWebChatCollection')?.ChatCollection || window.require('WAWebCollections')?.Chat;
                    const ChatState = window.require('WAWebChatState');
                    if (ChatCol && ChatState) {{
                        const activeChat = ChatCol.getModelsArray().find(c => c?.active);
                        if (activeChat) {{
                            if (mode === 'recording' && typeof ChatState.sendChatStateRecording === 'function') {{
                                ChatState.sendChatStateRecording(activeChat.id);
                            }} else if (typeof ChatState.sendChatStateComposing === 'function') {{
                                ChatState.sendChatStateComposing(activeChat.id);
                            }}
                        }}
                    }}
                }}
                if (mode === 'typing') {{
                    const box = document.querySelector('#main footer div[contenteditable="true"]');
                    if (box) {{
                        box.focus();
                        box.dispatchEvent(new InputEvent('input', {{ bubbles: true, inputType: 'insertText', data: ' ' }}));
                    }}
                }}
            }} catch (e) {{}}
            return true;
        }})()
        """
        try:
            cdp.send_command("Runtime.evaluate", {"expression": presence_js})
            time.sleep(dur)
        except Exception:
            pass

    def _simulate_chat_presence(self, chip_id: int, phone: str, mode: str = "typing", duration_sec: float = 2.0):
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return
        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=6.0)
            self._trigger_presence_in_open_chat(cdp, mode=mode, duration_sec=duration_sec)
            cdp.close()
        except Exception:
            pass

    # ==========================================================================
    # EXTRAÇÃO DE GRUPOS E PARTICIPANTES DIRETO DO BANCO INTERNO DO WHATSAPP WEB
    # (WAWebCollections + IndexedDB model-storage + Auto-Scroll DOM)
    # ==========================================================================

    def list_whatsapp_groups(self, chip_id: int, filter_groups_tab: bool = False) -> dict:
        """
        Lista TODOS os grupos do WhatsApp conectado diretamente do Store Interno (WAWebCollections)
        e do IndexedDB (model-storage) do WhatsApp Web, sem precisar abrir os grupos na tela
        e nunca confundindo lista de participantes com nome de grupo!
        """
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return {"ok": False, "detail": "Chip desconectado ou janela fechada. Conecte via QR Code primeiro.", "groups": []}

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=10.0)

            scan_all_groups_js = """
            (async () => {
                const isParticipantSubtitle = (txt) => {
                    if (!txt) return true;
                    const s = String(txt).trim();
                    if (s.length > 95 && s.includes(',')) return true;
                    const commaCount = (s.match(/,/g) || []).length;
                    if (commaCount >= 3) return true;
                    if (/\\+\\d{1,3}[\\s.-]?\\d{2}/.test(s) && s.includes(',')) return true;
                    if (/^(clique aqui|click here|dados do grupo|group info|online|visto por)/i.test(s)) return true;
                    if (s.endsWith(', Você') || s.endsWith(', Voce') || s.endsWith(', You')) return true;
                    return false;
                };

                const groupsMap = new Map();

                // 1. Tentar Store Interno do WhatsApp Web (window.require)
                try {
                    if (typeof window.require === 'function') {
                        let ChatCol = null;
                        let GrpMetaCol = null;
                        try { ChatCol = window.require('WAWebChatCollection')?.ChatCollection || window.require('WAWebCollections')?.Chat; } catch (e) {}
                        try { GrpMetaCol = window.require('WAWebGroupMetadataCollection')?.GroupMetadataCollection || window.require('WAWebCollections')?.GroupMetadata; } catch (e) {}

                        if (ChatCol && typeof ChatCol.getModelsArray === 'function') {
                            for (const c of ChatCol.getModelsArray()) {
                                const idStr = c?.id?._serialized || String(c?.id || '');
                                const isGrp = Boolean(c?.isGroup || idStr.endsWith('@g.us'));
                                if (!isGrp) continue;
                                const rawName = (c.name || c.formattedTitle || c.groupMetadata?.subject || '').trim();
                                if (!rawName || isParticipantSubtitle(rawName)) continue;
                                const count = c.groupMetadata?.participants?.length || 0;
                                groupsMap.set(idStr, {
                                    id: idStr,
                                    name: rawName,
                                    members_count: count,
                                    preview: count > 0 ? `${count} participantes no grupo` : 'Grupo do WhatsApp'
                                });
                            }
                        }

                        if (GrpMetaCol && typeof GrpMetaCol.getModelsArray === 'function') {
                            for (const gm of GrpMetaCol.getModelsArray()) {
                                const idStr = gm?.id?._serialized || String(gm?.id || '');
                                if (!idStr.endsWith('@g.us')) continue;
                                const count = gm?.participants?.length || 0;
                                const existing = groupsMap.get(idStr);
                                const rawName = (gm.subject || existing?.name || '').trim();
                                if (rawName && !isParticipantSubtitle(rawName)) {
                                    groupsMap.set(idStr, {
                                        id: idStr,
                                        name: rawName,
                                        members_count: count || existing?.members_count || 0,
                                        preview: (count || existing?.members_count) ? `${count || existing.members_count} participantes no grupo` : 'Grupo do WhatsApp'
                                    });
                                }
                            }
                        }
                    }
                } catch (e) {}

                // 2. Ler diretamente do IndexedDB ('model-storage') do WhatsApp Web
                try {
                    const idbGroups = await new Promise((resolve) => {
                        const req = indexedDB.open('model-storage');
                        req.onerror = () => resolve([]);
                        req.onsuccess = (ev) => {
                            const db = ev.target.result;
                            const storeNames = Array.from(db.objectStoreNames || []);
                            const out = [];
                            const chatMap = {};
                            const partCountMap = {};

                            const readStore = (sName) => new Promise((resStore) => {
                                if (!storeNames.includes(sName)) return resStore([]);
                                try {
                                    const tx = db.transaction([sName], 'readonly');
                                    const st = tx.objectStore(sName);
                                    const getAllReq = st.getAll();
                                    getAllReq.onsuccess = () => resStore(getAllReq.result || []);
                                    getAllReq.onerror = () => resStore([]);
                                } catch (err) { resStore([]); }
                            });

                            Promise.all([
                                readStore('chat'),
                                readStore('group-metadata'),
                                readStore('participant')
                            ]).then(([chats, metas, parts]) => {
                                (parts || []).forEach(p => {
                                    const gid = p.groupId || p.id || '';
                                    if (gid && Array.isArray(p.participants)) {
                                        partCountMap[gid] = p.participants.length;
                                    }
                                });
                                (chats || []).forEach(c => {
                                    const cid = c.id || '';
                                    if (String(cid).endsWith('@g.us')) {
                                        const nm = (c.name || c.subject || c.formattedTitle || '').trim();
                                        if (nm && !isParticipantSubtitle(nm)) {
                                            chatMap[cid] = nm;
                                        }
                                    }
                                });
                                (metas || []).forEach(m => {
                                    const mid = m.id || '';
                                    if (String(mid).endsWith('@g.us')) {
                                        const nm = (m.subject || chatMap[mid] || '').trim();
                                        if (nm && !isParticipantSubtitle(nm)) {
                                            chatMap[mid] = nm;
                                        }
                                        if (Array.isArray(m.participants) && !partCountMap[mid]) {
                                            partCountMap[mid] = m.participants.length;
                                        }
                                    }
                                });
                                Object.keys(chatMap).forEach(gid => {
                                    out.push({
                                        id: gid,
                                        name: chatMap[gid],
                                        members_count: partCountMap[gid] || 0
                                    });
                                });
                                db.close();
                                resolve(out);
                            }).catch(() => { db.close(); resolve([]); });
                        };
                    });

                    for (const g of idbGroups) {
                        const existing = groupsMap.get(g.id);
                        const cnt = Math.max(g.members_count || 0, existing?.members_count || 0);
                        groupsMap.set(g.id, {
                            id: g.id,
                            name: existing?.name || g.name,
                            members_count: cnt,
                            preview: cnt > 0 ? `${cnt} participantes no grupo` : 'Grupo do WhatsApp'
                        });
                    }
                } catch (e) {}

                // 3. Complementar com a lista lateral (#pane-side) caso haja grupos visiveis ainda nao indexados
                try {
                    const existingNames = new Set(Array.from(groupsMap.values()).map(x => x.name.toLowerCase()));
                    const rows = document.querySelectorAll('#pane-side [role="listitem"], #pane-side [data-testid="cell-frame-container"]');
                    rows.forEach(row => {
                        const spans = Array.from(row.querySelectorAll('span[title], span[dir="auto"]'));
                        for (const sp of spans) {
                            const candidate = (sp.getAttribute('title') || sp.innerText || '').trim();
                            if (!candidate || candidate.length < 2 || candidate.length > 80) continue;
                            if (isParticipantSubtitle(candidate)) continue;
                            if (/^\\d{1,2}:\\d{2}/.test(candidate) || /^(ontem|hoje|yesterday|today)$/i.test(candidate)) continue;
                            const onlyDigits = candidate.replace(/\\D/g, '');
                            if (candidate.startsWith('+') && onlyDigits.length >= 10) continue;
                            if (!existingNames.has(candidate.toLowerCase())) {
                                existingNames.add(candidate.toLowerCase());
                                groupsMap.set('dom:' + candidate, {
                                    id: '',
                                    name: candidate,
                                    members_count: 0,
                                    preview: 'Grupo na lista lateral'
                                });
                            }
                            break;
                        }
                    });
                } catch (e) {}

                const finalGroups = Array.from(groupsMap.values()).sort((a, b) => (b.members_count - a.members_count));
                return JSON.stringify(finalGroups);
            })()
            """
            res = cdp.send_command(
                "Runtime.evaluate",
                {"expression": scan_all_groups_js, " returnByValue": True, "awaitPromise": True, "returnByValue": True}
            )
            cdp.close()
            raw_val = res.get("result", {}).get("result", {}).get("value", "[]")
            groups = json.loads(raw_val) if raw_val else []
            return {"ok": True, "groups": groups}
        except Exception as e:
            return {"ok": False, "detail": str(e)[:80], "groups": []}

    def extract_group_participants(self, chip_id: int, group_name: str = "", group_id: str = "") -> dict:
        """
        Extrai 100% dos participantes do grupo diretamente da memória/IndexedDB do WhatsApp Web
        (WAWebCollections + model-storage) SEM precisar que o operador abra o grupo no WhatsApp,
        capturando o Nome Real (Agenda ou ~ Pushname do WhatsApp) e o Telefone de cada participante,
        e nunca confundindo a lista de participantes com o nome do grupo!
        """
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return {"ok": False, "detail": "Conecte o chip via QR Code antes de extrair contatos de grupos.", "members": []}

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=18.0)
            safe_group_name = json.dumps((group_name or "").strip())
            safe_group_id = json.dumps((group_id or "").strip())

            deep_extract_js = f"""
            (async () => {{
                const targetName = {safe_group_name};
                const targetId = {safe_group_id};

                const isParticipantSubtitle = (txt) => {{
                    if (!txt) return true;
                    const s = String(txt).trim();
                    if (s.length > 95 && s.includes(',')) return true;
                    if ((s.match(/,/g) || []).length >= 3) return true;
                    if (/\\+\\d{{1,3}}[\\s.-]?\\d{{2}}/.test(s) && s.includes(',')) return true;
                    if (s.endsWith(', Você') || s.endsWith(', Voce') || s.endsWith(', You')) return true;
                    return false;
                }};

                const cleanPersonName = (raw) => {{
                    if (!raw) return '';
                    let s = String(raw).replace(/^~\\s*/, '').trim();
                    if (!s) return '';
                    if (/^\\+?\\d[\\d\\s().-]+$/.test(s)) return '';
                    if (/^(voce|você|you|admin|administrador|membro|cliente|dados do grupo)$/i.test(s)) return '';
                    if (isParticipantSubtitle(s)) return '';
                    return s.slice(0, 45);
                }};

                const normalizeDigits = (raw) => {{
                    if (!raw) return '';
                    let d = String(raw).split('@')[0].replace(/\\D/g, '').replace(/^0+/, '');
                    if (d.length === 10 || d.length === 11) d = '55' + d;
                    if (d.length >= 11 && d.length <= 15) return d;
                    return '';
                }};

                let resolvedGroupName = (!isParticipantSubtitle(targetName) && targetName !== '__OPEN__') ? targetName : '';
                let resolvedGroupId = targetId;
                const membersByPhone = new Map(); // phone -> {{ name, phone }}
                const nameToPhoneDirectory = new Map(); // lowercase name -> phone

                const addMember = (phoneRaw, nameRaw) => {{
                    const ph = normalizeDigits(phoneRaw);
                    if (!ph) return;
                    const nm = cleanPersonName(nameRaw);
                    const existing = membersByPhone.get(ph);
                    if (!existing) {{
                        membersByPhone.set(ph, {{ name: nm, phone: ph }});
                    }} else if (!existing.name && nm) {{
                        existing.name = nm;
                    }}
                }};

                // PASSO 1: Ler todos os contatos e participantes do IndexedDB ('model-storage')
                try {{
                    await new Promise((resolve) => {{
                        const req = indexedDB.open('model-storage');
                        req.onerror = () => resolve();
                        req.onsuccess = (ev) => {{
                            const db = ev.target.result;
                            const storeNames = Array.from(db.objectStoreNames || []);

                            const readStore = (sName) => new Promise((resStore) => {{
                                if (!storeNames.includes(sName)) return resStore([]);
                                try {{
                                    const tx = db.transaction([sName], 'readonly');
                                    const st = tx.objectStore(sName);
                                    const getAllReq = st.getAll();
                                    getAllReq.onsuccess = () => resStore(getAllReq.result || []);
                                    getAllReq.onerror = () => resStore([]);
                                }} catch (err) {{ resStore([]); }}
                            }});

                            Promise.all([
                                readStore('contact'),
                                readStore('chat'),
                                readStore('group-metadata'),
                                readStore('participant')
                            ]).then(([contacts, chats, metas, parts]) => {{
                                const contactById = new Map();

                                (contacts || []).forEach(c => {{
                                    const cid = String(c.id || '');
                                    const phCandidate = c.phoneNumber || (cid.endsWith('@c.us') || cid.endsWith('@s.whatsapp.net') ? cid : '');
                                    const ph = normalizeDigits(phCandidate);
                                    const bestName = cleanPersonName(c.name || c.pushname || c.verifiedName || c.shortName || '');
                                    if (cid) {{
                                        contactById.set(cid, {{ phone: ph, name: bestName }});
                                        contactById.set(cid.split('@')[0], {{ phone: ph, name: bestName }});
                                    }}
                                    if (ph && bestName) {{
                                        nameToPhoneDirectory.set(bestName.toLowerCase(), ph);
                                    }}
                                }});

                                // Identificar o grupo alvo no IndexedDB se ainda nao tiver ID
                                const allGroupTitles = new Map();
                                (chats || []).forEach(c => {{
                                    const cid = String(c.id || '');
                                    if (cid.endsWith('@g.us')) {{
                                        const nm = (c.name || c.subject || c.formattedTitle || '').trim();
                                        if (nm && !isParticipantSubtitle(nm)) allGroupTitles.set(cid, nm);
                                    }}
                                }});
                                (metas || []).forEach(m => {{
                                    const mid = String(m.id || '');
                                    if (mid.endsWith('@g.us')) {{
                                        const nm = (m.subject || allGroupTitles.get(mid) || '').trim();
                                        if (nm && !isParticipantSubtitle(nm)) allGroupTitles.set(mid, nm);
                                    }}
                                }});

                                if (!resolvedGroupId && resolvedGroupName) {{
                                    const tLow = resolvedGroupName.toLowerCase();
                                    for (const [gid, gnm] of allGroupTitles.entries()) {{
                                        if (gnm.toLowerCase() === tLow || gnm.toLowerCase().includes(tLow)) {{
                                            resolvedGroupId = gid;
                                            resolvedGroupName = gnm;
                                            break;
                                        }}
                                    }}
                                }} else if (resolvedGroupId && allGroupTitles.has(resolvedGroupId)) {{
                                    resolvedGroupName = allGroupTitles.get(resolvedGroupId);
                                }}

                                // Extrair participantes daquele grupo no IndexedDB
                                if (resolvedGroupId) {{
                                    const extractFromList = (pList) => {{
                                        if (!Array.isArray(pList)) return;
                                        pList.forEach(item => {{
                                            const pid = typeof item === 'string' ? item : String(item?.id || item?.user || item?.wid || '');
                                            const itemPhone = typeof item === 'object' ? (item?.phoneNumber || item?.phone || '') : '';
                                            const itemName = typeof item === 'object' ? (item?.name || item?.pushname || item?.notifyName || '') : '';
                                            const cInfo = contactById.get(pid) || contactById.get(pid.split('@')[0]) || {{}};
                                            const finalPh = itemPhone || cInfo.phone || (pid.endsWith('@c.us') || pid.endsWith('@s.whatsapp.net') ? pid : '');
                                            const finalNm = itemName || cInfo.name || '';
                                            addMember(finalPh, finalNm);
                                        }});
                                    }};

                                    (parts || []).forEach(p => {{
                                        if ((p.groupId || p.id) === resolvedGroupId) {{
                                            extractFromList(p.participants);
                                        }}
                                    }});
                                    (metas || []).forEach(m => {{
                                        if (m.id === resolvedGroupId) {{
                                            extractFromList(m.participants);
                                        }}
                                    }});
                                }}
                                db.close();
                                resolve();
                            }}).catch(() => {{ db.close(); resolve(); }});
                        }};
                    }});
                }} catch (e) {{}}

                // PASSO 2: Extrair do Store em Memória do WhatsApp Web (WAWebCollections)
                try {{
                    if (typeof window.require === 'function') {{
                        let ChatCol = null;
                        let GrpMetaCol = null;
                        let ContactCol = null;
                        let ApiContact = null;
                        try {{ ChatCol = window.require('WAWebChatCollection')?.ChatCollection || window.require('WAWebCollections')?.Chat; }} catch (e) {{}}
                        try {{ GrpMetaCol = window.require('WAWebGroupMetadataCollection')?.GroupMetadataCollection || window.require('WAWebCollections')?.GroupMetadata; }} catch (e) {{}}
                        try {{ ContactCol = window.require('WAWebContactCollection')?.ContactCollection || window.require('WAWebCollections')?.Contact; }} catch (e) {{}}
                        try {{ ApiContact = window.require('WAWebApiContact'); }} catch (e) {{}}

                        if (ContactCol && typeof ContactCol.getModelsArray === 'function') {{
                            for (const c of ContactCol.getModelsArray()) {{
                                const cid = c?.id?._serialized || '';
                                const phObj = c?.phoneNumber || (ApiContact?.getPhoneNumber ? ApiContact.getPhoneNumber(c.id) : null);
                                const ph = normalizeDigits(phObj?.user || phObj?._serialized || (c?.id?.server === 'c.us' ? c?.id?.user : ''));
                                const nm = cleanPersonName(c?.name || c?.pushname || c?.verifiedName || c?.shortName || '');
                                if (ph && nm) nameToPhoneDirectory.set(nm.toLowerCase(), ph);
                            }}
                        }}

                        let targetChat = null;
                        if (ChatCol && typeof ChatCol.getModelsArray === 'function') {{
                            const chats = ChatCol.getModelsArray();
                            if (resolvedGroupId) {{
                                targetChat = chats.find(c => (c?.id?._serialized || '') === resolvedGroupId);
                            }}
                            if (!targetChat && resolvedGroupName) {{
                                const tLow = resolvedGroupName.toLowerCase();
                                targetChat = chats.find(c => {{
                                    const nm = (c?.name || c?.formattedTitle || c?.groupMetadata?.subject || '').trim();
                                    return nm && !isParticipantSubtitle(nm) && (nm.toLowerCase() === tLow || nm.toLowerCase().includes(tLow));
                                }});
                            }}
                            if (!targetChat && targetName === '__OPEN__') {{
                                targetChat = chats.find(c => c?.active && (c?.isGroup || (c?.id?._serialized || '').endsWith('@g.us')));
                            }}
                        }}

                        let gm = targetChat?.groupMetadata || (GrpMetaCol && resolvedGroupId ? GrpMetaCol.get(resolvedGroupId) : null);
                        if (gm) {{
                            if (!resolvedGroupName && gm.subject && !isParticipantSubtitle(gm.subject)) {{
                                resolvedGroupName = gm.subject.trim();
                            }}
                            try {{
                                if (typeof gm.update === 'function') {{
                                    await Promise.race([gm.update(), new Promise(r => setTimeout(r, 2500))]);
                                }}
                            }} catch (e) {{}}

                            const pModels = gm.participants && typeof gm.participants.getModelsArray === 'function'
                                ? gm.participants.getModelsArray()
                                : (Array.isArray(gm.participants) ? gm.participants : []);

                            for (const p of pModels) {{
                                const c = p?.contact || (ContactCol && p?.id ? ContactCol.get(p.id._serialized || p.id) : null) || {{}};
                                let phRaw = '';
                                if (p?.id?.server === 'c.us' || p?.id?.server === 's.whatsapp.net') {{
                                    phRaw = p.id.user;
                                }} else if (p?.phoneNumber) {{
                                    phRaw = p.phoneNumber.user || p.phoneNumber._serialized || p.phoneNumber;
                                }} else if (c?.phoneNumber) {{
                                    phRaw = c.phoneNumber.user || c.phoneNumber._serialized || c.phoneNumber;
                                }} else if (ApiContact && typeof ApiContact.getPhoneNumber === 'function' && p?.id) {{
                                    try {{
                                        const widPh = ApiContact.getPhoneNumber(p.id);
                                        if (widPh) phRaw = widPh.user || widPh._serialized || String(widPh);
                                    }} catch (e) {{}}
                                }}
                                const nmRaw = c.name || c.pushname || c.notifyName || c.verifiedName || c.shortName || p?.name || p?.pushname || '';
                                addMember(phRaw, nmRaw);
                            }}
                        }}
                    }}
                }} catch (e) {{}}

                // PASSO 3: Se o grupo ainda tiver poucos membros extraidos ou se for extraido via UI,
                // abrir e rolar a lista de participantes do grupo para capturar todos os itens (Telefone + ~ Pushname)
                if (membersByPhone.size < 3) {{
                    const sleep = (ms) => new Promise(r => setTimeout(r, ms));

                    if (resolvedGroupName && targetName !== '__OPEN__') {{
                        const tLow = resolvedGroupName.toLowerCase();
                        const spans = Array.from(document.querySelectorAll('#pane-side span[title], #pane-side span[dir="auto"]'));
                        const match = spans.find(s => {{
                            const txt = (s.getAttribute('title') || s.innerText || '').trim();
                            return txt && !isParticipantSubtitle(txt) && (txt.toLowerCase() === tLow || txt.toLowerCase().includes(tLow));
                        }});
                        if (match) {{
                            const row = match.closest('[role="listitem"]') || match.closest('[data-testid="cell-frame-container"]') || match;
                            row.click();
                            await sleep(900);
                        }}
                    }}

                    // Ler o VERDADEIRO nome do grupo no #main header (ignorando o subtitulo de participantes!)
                    const mainHeader = document.querySelector('#main header');
                    if (mainHeader) {{
                        const headerSpans = Array.from(mainHeader.querySelectorAll('span[dir="auto"], span[title]'));
                        for (const hs of headerSpans) {{
                            const candidate = (hs.getAttribute('title') || hs.innerText || '').trim();
                            if (candidate && !isParticipantSubtitle(candidate)) {{
                                resolvedGroupName = candidate;
                                break;
                            }}
                        }}

                        // Se o subtitulo do header tiver nomes ou telefones separados por virgula, extrair tambem
                        for (const hs of headerSpans) {{
                            const sub = (hs.getAttribute('title') || hs.innerText || '').trim();
                            if (isParticipantSubtitle(sub) && sub.includes(',')) {{
                                sub.split(',').forEach(part => {{
                                    const piece = part.trim();
                                    if (!piece) return;
                                    const ph = normalizeDigits(piece);
                                    if (ph) {{
                                        addMember(ph, '');
                                    }} else {{
                                        const cleanNm = cleanPersonName(piece);
                                        if (cleanNm && nameToPhoneDirectory.has(cleanNm.toLowerCase())) {{
                                            addMember(nameToPhoneDirectory.get(cleanNm.toLowerCase()), cleanNm);
                                        }}
                                    }}
                                }});
                            }}
                        }}

                        // Abrir a gaveta de Dados do Grupo
                        const clickable = mainHeader.querySelector('[role="button"]') || mainHeader;
                        clickable.click();
                        await sleep(900);
                    }}

                    // Clicar em "Ver tudo (X)" se existir para abrir o modal completo de membros
                    const allBtns = Array.from(document.querySelectorAll('button, [role="button"], span'));
                    const seeAllBtn = allBtns.find(b => /^(ver tud|ver tod|see all|mostrar tud)/i.test((b.innerText || '').trim()));
                    if (seeAllBtn) {{
                        seeAllBtn.click();
                        await sleep(700);
                    }}

                    // Rolar a lista de membros passo a passo coletando Nome / ~Pushname + Telefone de cada linha
                    const harvestVisibleRows = () => {{
                        const rows = document.querySelectorAll('[role="listitem"], [data-testid="cell-frame-container"]');
                        rows.forEach(r => {{
                            if (r.closest('#pane-side')) return;
                            const lines = (r.innerText || '').split('\\n').map(x => x.trim()).filter(Boolean);
                            if (lines.length === 0) return;

                            let foundPhone = '';
                            let foundName = '';

                            for (const ln of lines) {{
                                const phMatch = ln.match(/(?:\\+?\\d{{1,3}}[\\s.-]?)?\\(?\\d{{2}}\\)?[\\s.-]?\\d{{4,5}}[\\s.-]?\\d{{4}}/);
                                if (phMatch && !foundPhone) {{
                                    foundPhone = normalizeDigits(phMatch[0]);
                                }}
                                if (ln.startsWith('~')) {{
                                    const pushNm = cleanPersonName(ln);
                                    if (pushNm) foundName = pushNm;
                                }} else if (!phMatch && !foundName) {{
                                    const cand = cleanPersonName(ln);
                                    if (cand && !/^(admin|grupo|recado|online|visto)/i.test(cand)) {{
                                        foundName = cand;
                                    }}
                                }}
                            }}

                            if (!foundPhone && foundName && nameToPhoneDirectory.has(foundName.toLowerCase())) {{
                                foundPhone = nameToPhoneDirectory.get(foundName.toLowerCase());
                            }}
                            if (foundPhone) {{
                                addMember(foundPhone, foundName);
                            }}
                        }});
                    }};

                    harvestVisibleRows();
                    const scrollers = Array.from(document.querySelectorAll('div')).filter(el => {{
                        if (el.closest('#pane-side') || el.closest('#main')) return false;
                        return el.scrollHeight > el.clientHeight + 80 && el.clientHeight > 150;
                    }});

                    for (let step = 0; step < 15; step++) {{
                        scrollers.forEach(sc => {{ sc.scrollTop += 380; }});
                        await sleep(120);
                        harvestVisibleRows();
                    }}
                }}

                if (!resolvedGroupName || isParticipantSubtitle(resolvedGroupName)) {{
                    resolvedGroupName = 'Grupo WhatsApp';
                }}

                return JSON.stringify({{
                    group_id: resolvedGroupId || '',
                    group_name: resolvedGroupName,
                    members: Array.from(membersByPhone.values())
                }});
            }})()
            """
            res = cdp.send_command(
                "Runtime.evaluate",
                {"expression": deep_extract_js, "returnByValue": True, "awaitPromise": True}
            )
            cdp.close()

            raw_json = res.get("result", {}).get("result", {}).get("value", "{}")
            parsed = json.loads(raw_json) if raw_json else {}
            detected_group = (parsed.get("group_name") or "Grupo WhatsApp").strip()
            members = parsed.get("members") or []

            return {
                "ok": True,
                "group_id": parsed.get("group_id") or group_id,
                "group_name": detected_group,
                "members": members,
                "total": len(members)
            }
        except Exception as e:
            return {"ok": False, "detail": str(e)[:80], "members": []}

    def send_message_to_whatsapp_group(self, chip_id: int, group_name: str, message: str) -> tuple:
        """
        Abre o grupo pelo nome (ou usa o grupo aberto no momento) e envia uma mensagem
        diretamente dentro do chat do grupo no WhatsApp Web.
        """
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return False, "Chip desconectado ou janela fechada"

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=10.0)

            if group_name and group_name != "__OPEN__":
                safe_name = json.dumps(group_name)
                open_group_js = f"""
                (() => {{
                    const targetName = {safe_name}.toLowerCase().trim();
                    const spans = Array.from(document.querySelectorAll('#pane-side span[title], #pane-side span[dir="auto"]'));
                    const match = spans.find(s => (s.getAttribute('title') || s.innerText || '').toLowerCase().trim() === targetName)
                               || spans.find(s => (s.getAttribute('title') || s.innerText || '').toLowerCase().includes(targetName));
                    if (match) {{
                        const clickable = match.closest('[role="listitem"]') || match.closest('[data-testid="cell-frame-container"]') || match;
                        clickable.click();
                        return 'CLICKED';
                    }}
                    return 'NOT_FOUND';
                }})()
                """
                cdp.send_command("Runtime.evaluate", {"expression": open_group_js, "returnByValue": True})
                time.sleep(1.0)

            focus_input_js = """
            (() => {
                const box = document.querySelector('#main footer div[contenteditable="true"]')
                         || document.querySelector('div[contenteditable="true"][data-tab="10"]');
                if (!box) return 'NO_INPUT';
                box.focus();
                return 'FOCUSED';
            })()
            """
            res = cdp.send_command("Runtime.evaluate", {"expression": focus_input_js, "returnByValue": True})
            state = res.get("result", {}).get("result", {}).get("value", "NO_INPUT")
            if state == "NO_INPUT":
                cdp.close()
                return False, "Abra ou selecione um grupo no WhatsApp Web primeiro"

            cdp.send_command("Input.insertText", {"text": message})
            has_url = bool(re.search(r"https?://\S+", message or "", flags=re.IGNORECASE))
            if has_url:
                cdp.send_command("Input.insertText", {"text": " "})
                for step_wait in range(7):
                    time.sleep(0.4)
                    check_preview_js = """
                    (() => {
                        const mainEl = document.querySelector('#main');
                        if (!mainEl) return 'NO_MAIN';
                        const previewSelectors = [
                            '[data-testid*="link-preview"]',
                            '[data-testid*="media-url"]',
                            'footer a[href^="http"]',
                            '#main footer img'
                        ];
                        for (const sel of previewSelectors) {
                            const el = mainEl.querySelector(sel);
                            if (el && el.offsetHeight > 18) return 'PREVIEW_LOADED';
                        }
                        return 'LOADING';
                    })()
                    """
                    p_res = cdp.send_command("Runtime.evaluate", {"expression": check_preview_js, "returnByValue": True})
                    if p_res.get("result", {}).get("result", {}).get("value") == "PREVIEW_LOADED" and step_wait >= 3:
                        time.sleep(0.3)
                        break
            else:
                time.sleep(0.35)

            click_send_js = """
            (() => {
                const sendBtn =
                    document.querySelector('span[data-icon="send"]') ||
                    document.querySelector('span[data-icon="wds-ic-send-filled"]') ||
                    document.querySelector('button[aria-label="Enviar"]') ||
                    document.querySelector('button[aria-label="Send"]');
                if (sendBtn) {
                    const clickable = sendBtn.closest('button') || sendBtn;
                    clickable.click();
                    return 'SENT';
                }
                return 'ENTER';
            })()
            """
            s_res = cdp.send_command("Runtime.evaluate", {"expression": click_send_js, "returnByValue": True})
            if s_res.get("result", {}).get("result", {}).get("value") != "SENT":
                cdp.send_command("Input.dispatchKeyEvent", {"type": "keyDown", "windowsVirtualKeyCode": 13, "key": "Enter", "code": "Enter"})
                cdp.send_command("Input.dispatchKeyEvent", {"type": "keyUp", "windowsVirtualKeyCode": 13, "key": "Enter", "code": "Enter"})

            time.sleep(0.4)
            cdp.close()
            return True, "Mensagem enviada no grupo com sucesso"
        except Exception as e:
            return False, str(e)[:60]

    # ==========================================================================
    # MONITORAMENTO E RESPOSTA AO VIVO DO WHATSAPP SELECIONADO NA BARRA LATERAL
    # ==========================================================================

    def click_internal_screen(self, chip_id: int, rel_x: float, rel_y: float) -> dict:
        """
        Permite ao usuario clicar diretamente na imagem da Tela Interna do WhatsApp
        dentro da Aba 9 do programa (sem nenhuma janela externa do Chrome).
        """
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return {"ok": False, "detail": "Sessao interna nao iniciada."}
        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=4.0)
            vp_res = cdp.send_command("Runtime.evaluate", {
                "expression": "JSON.stringify({w: window.innerWidth || 1020, h: window.innerHeight || 740})",
                "returnByValue": True
            })
            vp_raw = vp_res.get("result", {}).get("result", {}).get("value", '{"w":1020,"h":740}')
            vp = json.loads(vp_raw)
            x = int(max(5, min(vp.get("w", 1020) - 5, float(rel_x) * vp.get("w", 1020))))
            y = int(max(5, min(vp.get("h", 740) - 5, float(rel_y) * vp.get("h", 740))))

            cdp.send_command("Input.dispatchMouseEvent", {
                "type": "mousePressed",
                "x": x,
                "y": y,
                "button": "left",
                "clickCount": 1
            })
            cdp.send_command("Input.dispatchMouseEvent", {
                "type": "mouseReleased",
                "x": x,
                "y": y,
                "button": "left",
                "clickCount": 1
            })
            time.sleep(0.35)
            cdp.close()
            return self.get_live_monitor_snapshot(chip_id, include_screenshot=True)
        except Exception as e:
            return {"ok": False, "detail": str(e)[:70]}

    def get_live_monitor_snapshot(self, chip_id: int, include_screenshot: bool = True, auto_wake: bool = True) -> dict:
        """
        Captura em tempo real do WhatsApp Web do chip selecionado (100% interno em modo headless):
        - Fecha imediatamente qualquer janela visivel externa do Chrome do WhatsApp na Barra de Tarefas;
        - Fecha automaticamente popups de boas-vindas do WhatsApp Web (ex: botao 'Continuar');
        - Lista conversas recentes (#pane-side + WAWebChatCollection) com contador de nao lidas;
        - Extrai a conversa aberta (#main) com as ultimas mensagens recebidas e enviadas;
        - Captura a tela interna ao vivo (JPEG).
        """
        # Garantir que nenhuma janela externa visivel do WhatsApp fique na Barra de Tarefas
        closed_vis = close_visible_whatsapp_chrome_windows()
        port = self.get_port(chip_id)

        if is_port_open(port):
            self.headless_ports.add(port)
        elif closed_vis:
            time.sleep(0.25)

        if not is_port_open(port):
            profile_dir = self.sessions_dir / f"chip_{chip_id}"
            if auto_wake and profile_dir.exists():
                self.launch_chip_session(chip_id, hibernate_others=False)
                time.sleep(0.9)
            else:
                self.status_cache[chip_id] = "closed"
                return {
                    "ok": True,
                    "wa_state": "closed",
                    "chats": [],
                    "active_chat": {"title": "", "subtitle": "", "messages": []},
                    "screenshot": None
                }

        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return {
                "ok": True,
                "wa_state": "loading",
                "chats": [],
                "active_chat": {"title": "", "subtitle": "", "messages": []},
                "screenshot": None
            }

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=4.5)
            monitor_js = """
            (() => {
                // 0. Auto-fechar modais de boas-vindas do WhatsApp Web (ex: "Continuar para o WhatsApp Web" -> botao "Continuar")
                try {
                    const dismissWords = ['continuar', 'continue', 'ok', 'entendi', 'got it', 'usar aqui', 'use here', 'agora não', 'not now'];
                    const btns = Array.from(document.querySelectorAll('div[role="dialog"] button, [data-animate-modal-popup="true"] button, button'));
                    for (const b of btns) {
                        const txt = (b.innerText || b.textContent || '').trim().toLowerCase();
                        if (dismissWords.includes(txt)) {
                            b.click();
                        }
                    }
                } catch (e) {}

                const hasPane = !!document.querySelector('#pane-side') || !!document.querySelector('[data-testid="chat-list"]');
                const hasQr = !!document.querySelector('canvas') || document.body.innerText.includes('Aponte seu celular') || document.body.innerText.includes('Passos para acessar');
                const state = hasPane ? 'connected' : (hasQr ? 'qr_ready' : 'loading');

                if (state !== 'connected') {
                    return JSON.stringify({ state, chats: [], active_chat: { title: '', subtitle: '', messages: [] } });
                }

                // Se nenhum chat estiver aberto ainda em #main, clicar automaticamente na primeira conversa visivel de #pane-side
                if (!document.querySelector('#main header')) {
                    const firstRow = document.querySelector('#pane-side [role="listitem"], #pane-side [data-testid="cell-frame-container"]');
                    if (firstRow) {
                        try { firstRow.click(); } catch (e) {}
                    }
                }

                // 1. Extrair cabecalho e mensagens da conversa aberta em #main
                let activeTitle = '';
                let activeSubtitle = '';
                const mainEl = document.querySelector('#main');
                if (mainEl) {
                    const headerEl = mainEl.querySelector('header');
                    if (headerEl) {
                        const titleSpans = Array.from(headerEl.querySelectorAll('span[title], span[dir="auto"]'));
                        for (const sp of titleSpans) {
                            const txt = (sp.getAttribute('title') || sp.innerText || '').trim();
                            if (!txt) continue;
                            if (!activeTitle) {
                                activeTitle = txt;
                            } else if (!activeSubtitle && txt !== activeTitle) {
                                activeSubtitle = txt;
                                break;
                            }
                        }
                    }
                }

                const messages = [];
                if (mainEl) {
                    const rawNodes = Array.from(
                        mainEl.querySelectorAll('div.message-in, div.message-out, [data-testid="msg-container"]')
                    );
                    // Evitar duplicar quando [data-testid="msg-container"] esta dentro de div.message-in/out
                    const msgNodes = rawNodes.filter(n => {
                        if (n.getAttribute('data-testid') === 'msg-container' && n.closest('.message-in, .message-out')) {
                            return false;
                        }
                        return true;
                    }).slice(-40);

                    for (const node of msgNodes) {
                        const dataIdNode = node.closest('[data-id]') || node.querySelector('[data-id]');
                        const dataIdStr = dataIdNode ? (dataIdNode.getAttribute('data-id') || '') : '';
                        const hasOutIcon = !!node.querySelector('span[data-icon^="msg-dblcheck"], span[data-icon^="msg-check"], span[data-icon="msg-time"], span[aria-label*="Entregue"], span[aria-label*="Lida"], span[aria-label*="Enviada"]');
                        const isOut = Boolean(
                            node.classList.contains('message-out') ||
                            node.closest('.message-out') ||
                            dataIdStr.startsWith('true_') ||
                            hasOutIcon
                        );

                        const copyable = node.querySelector('.copyable-text[data-pre-plain-text]');
                        const prePlain = copyable ? (copyable.getAttribute('data-pre-plain-text') || '') : '';

                        let textVal = '';
                        const textContainer = node.querySelector('span.selectable-text') || node.querySelector('[data-testid="conversation-text-content"]');
                        if (textContainer) {
                            textVal = (textContainer.innerText || '').trim();
                        } else {
                            const lines = (node.innerText || '').split('\\n').map(s => s.trim()).filter(Boolean);
                            if (lines.length > 0) {
                                textVal = lines.slice(0, Math.max(1, lines.length - 1)).join(' ');
                            }
                        }
                        if (!textVal) continue;

                        let timeStr = '';
                        const timeMatch = prePlain.match(/\\[(\\d{1,2}:\\d{2})/);
                        if (timeMatch) {
                            timeStr = timeMatch[1];
                        } else {
                            const allSpans = Array.from(node.querySelectorAll('span'));
                            for (let i = allSpans.length - 1; i >= 0; i--) {
                                const st = (allSpans[i].innerText || '').trim();
                                if (/^\\d{1,2}:\\d{2}(\\s*[AP]M)?$/i.test(st)) {
                                    timeStr = st;
                                    break;
                                }
                            }
                        }

                        let senderName = '';
                        const senderMatch = prePlain.match(/\\]\\s*([^:]+):/);
                        if (senderMatch) {
                            senderName = senderMatch[1].trim();
                        }

                        messages.push({
                            direction: isOut ? 'out' : 'in',
                            sender: isOut ? 'Voce' : (senderName || activeTitle),
                            text: textVal.slice(0, 1000),
                            time: timeStr
                        });
                    }
                }

                // 2. Extrair PRIMEIRO as linhas visiveis em #pane-side (ordenadas de cima para baixo como na tela real!)
                const chats = [];
                const seenTitles = new Set();

                const rawRows = Array.from(document.querySelectorAll('#pane-side [role="listitem"], #pane-side [data-testid="cell-frame-container"]'));
                rawRows.sort((a, b) => (a.getBoundingClientRect().top || 0) - (b.getBoundingClientRect().top || 0));

                for (const row of rawRows) {
                    const titleEl = row.querySelector('span[title]');
                    const title = titleEl ? (titleEl.getAttribute('title') || titleEl.innerText || '').trim() : '';
                    if (!title || seenTitles.has(title.toLowerCase())) continue;
                    seenTitles.add(title.toLowerCase());

                    const unreadBadge = row.querySelector('span[aria-label*="não lida"], span[aria-label*="unread"]');
                    let unreadCount = 0;
                    if (unreadBadge) {
                        const num = parseInt((unreadBadge.innerText || '1').replace(/\\D/g, ''), 10);
                        unreadCount = isNaN(num) ? 1 : Math.max(1, num);
                    }

                    const lines = (row.innerText || '').split('\\n').map(s => s.trim()).filter(Boolean);
                    let timeVal = '';
                    let previewVal = '';
                    if (lines.length >= 2) {
                        if (/^(\\d{1,2}:\\d{2}(\\s*[AP]M)?|ontem|yesterday|hoje|seg|ter|qua|qui|sex|sáb|dom|mon|tue|wed|thu|fri|sat|sun|\\d{1,2}\\/\\d{1,2})/i.test(lines[1])) {
                            timeVal = lines[1];
                            previewVal = lines.slice(2).join(' ');
                        } else {
                            previewVal = lines.slice(1).join(' ');
                        }
                    }

                    const digits = title.replace(/\\D/g, '');
                    chats.push({
                        id: '',
                        title: title,
                        phone: digits.length >= 10 ? digits : '',
                        last_message: (previewVal || 'Conversa recente').slice(0, 140),
                        time: timeVal,
                        unread_count: unreadCount,
                        is_group: false,
                        is_active: Boolean(activeTitle && title.toLowerCase() === activeTitle.toLowerCase())
                    });
                }

                // 3. Complementar com WAWebChatCollection (apenas conversas com nome ou nao lidas)
                try {
                    if (typeof window.require === 'function') {
                        const ChatCol = window.require('WAWebChatCollection')?.ChatCollection || window.require('WAWebCollections')?.Chat;
                        if (ChatCol && typeof ChatCol.getModelsArray === 'function') {
                            const arr = ChatCol.getModelsArray().slice(0, 45);
                            for (const c of arr) {
                                const idStr = c?.id?._serialized || String(c?.id || '');
                                const title = (c?.name || c?.formattedTitle || c?.contact?.name || c?.contact?.pushname || '').trim();
                                if (!title) continue;
                                const unread = Number(c?.unreadCount || 0);
                                const cleanDigits = idStr.endsWith('@c.us') ? idStr.replace(/\\D/g, '') : '';
                                const existingIdx = chats.findIndex(x => x.title.toLowerCase() === title.toLowerCase());
                                if (existingIdx >= 0) {
                                    if (!chats[existingIdx].id) chats[existingIdx].id = idStr;
                                    if (!chats[existingIdx].phone && cleanDigits) chats[existingIdx].phone = cleanDigits;
                                    if (unread > chats[existingIdx].unread_count) chats[existingIdx].unread_count = unread;
                                    chats[existingIdx].is_group = Boolean(c?.isGroup || idStr.endsWith('@g.us'));
                                } else if (!seenTitles.has(title.toLowerCase())) {
                                    seenTitles.add(title.toLowerCase());
                                    const lastMsg = (c?.msgs?.last?.()?.body || '').slice(0, 120);
                                    chats.push({
                                        id: idStr,
                                        title: title,
                                        phone: cleanDigits,
                                        last_message: lastMsg || 'Conversa no WhatsApp',
                                        time: '',
                                        unread_count: unread > 0 ? unread : 0,
                                        is_group: Boolean(c?.isGroup || idStr.endsWith('@g.us')),
                                        is_active: Boolean(activeTitle && title.toLowerCase() === activeTitle.toLowerCase())
                                    });
                                }
                            }
                        }
                    }
                } catch (e) {}

                return JSON.stringify({
                    state,
                    chats: chats.slice(0, 45),
                    active_chat: {
                        title: activeTitle,
                        subtitle: activeSubtitle,
                        messages: messages
                    }
                });
            })()
            """
            res = cdp.send_command("Runtime.evaluate", {"expression": monitor_js, "returnByValue": True})
            raw_val = res.get("result", {}).get("result", {}).get("value", "{}")
            parsed = json.loads(raw_val) if raw_val else {}
            state = parsed.get("state", "loading")
            self.status_cache[chip_id] = "connected" if state == "connected" else "qr_pending"

            screenshot_uri = None
            if include_screenshot:
                try:
                    cdp.send_command("Page.bringToFront")
                except Exception:
                    pass
                shot_res = cdp.send_command("Page.captureScreenshot", {"format": "jpeg", "quality": 80})
                b64_img = shot_res.get("result", {}).get("data")
                if b64_img:
                    screenshot_uri = f"data:image/jpeg;base64,{b64_img}"

            cdp.close()
            return {
                "ok": True,
                "wa_state": state,
                "chats": parsed.get("chats") or [],
                "active_chat": parsed.get("active_chat") or {"title": "", "subtitle": "", "messages": []},
                "screenshot": screenshot_uri
            }
        except Exception as e:
            return {
                "ok": False,
                "wa_state": "loading",
                "detail": str(e)[:80],
                "chats": [],
                "active_chat": {"title": "", "subtitle": "", "messages": []},
                "screenshot": None
            }

    def open_chat_in_whatsapp(self, chip_id: int, chat_title: str = "", phone: str = "") -> dict:
        """
        Seleciona e abre uma conversa específica dentro do WhatsApp Web do chip monitorado
        para que o usuário possa ler todas as mensagens e responder diretamente.
        """
        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return {"ok": False, "detail": "Chip desconectado ou janela fechada."}

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=6.0)
            safe_title = json.dumps((chat_title or "").strip())
            clean_phone = "".join(ch for ch in str(phone or "") if ch.isdigit())

            click_chat_js = f"""
            (() => {{
                const targetTitle = {safe_title}.toLowerCase().trim();
                if (targetTitle) {{
                    const spans = Array.from(document.querySelectorAll('#pane-side span[title], #pane-side span[dir="auto"]'));
                    const exact = spans.find(s => (s.getAttribute('title') || s.innerText || '').toLowerCase().trim() === targetTitle)
                               || spans.find(s => (s.getAttribute('title') || s.innerText || '').toLowerCase().includes(targetTitle));
                    if (exact) {{
                        const row = exact.closest('[role="listitem"]') || exact.closest('[data-testid="cell-frame-container"]') || exact;
                        row.click();
                        const eventOpts = {{ bubbles: true, cancelable: true, view: window }};
                        row.dispatchEvent(new MouseEvent('mousedown', eventOpts));
                        row.dispatchEvent(new MouseEvent('mouseup', eventOpts));
                        row.dispatchEvent(new MouseEvent('click', eventOpts));
                        return 'CLICKED_ROW';
                    }}
                }}
                return 'NOT_IN_PANE';
            }})()
            """
            res = cdp.send_command("Runtime.evaluate", {"expression": click_chat_js, "returnByValue": True})
            outcome = res.get("result", {}).get("result", {}).get("value", "NOT_IN_PANE")

            if outcome == "NOT_IN_PANE" and len(clean_phone) >= 10:
                open_spa_js = f"""
                (() => {{
                    let a = document.getElementById('nexzap-spa-link');
                    if (!a) {{
                        a = document.createElement('a');
                        a.id = 'nexzap-spa-link';
                        document.body.appendChild(a);
                    }}
                    a.href = 'https://web.whatsapp.com/send?phone={clean_phone}';
                    a.click();
                    return 'OPENED_BY_PHONE';
                }})()
                """
                cdp.send_command("Runtime.evaluate", {"expression": open_spa_js, "returnByValue": True})
                time.sleep(0.9)
            else:
                time.sleep(0.45)

            cdp.close()
            return self.get_live_monitor_snapshot(chip_id, include_screenshot=True)
        except Exception as e:
            return {"ok": False, "detail": str(e)[:80]}

    def reply_in_open_or_target_chat(self, chip_id: int, message: str, chat_title: str = "", phone: str = "") -> tuple:
        """
        Envia uma resposta imediata na conversa atualmente aberta no Monitor do WhatsApp
        (ou abre o contato/grupo indicado e envia a resposta).
        """
        msg_clean = (message or "").strip()
        if not msg_clean:
            return False, "Digite uma mensagem para responder."

        target = self._get_wa_target(chip_id)
        if not target or not target.get("webSocketDebuggerUrl"):
            return False, "Chip desconectado do WhatsApp Web."

        try:
            cdp = SimpleCDPClient(target["webSocketDebuggerUrl"], timeout=10.0)

            # Verificar se ja existe conversa aberta em #main e se corresponde ao chat_title
            safe_title = json.dumps((chat_title or "").strip())
            ensure_chat_js = f"""
            (() => {{
                const desired = {safe_title}.toLowerCase().trim();
                const mainHeader = document.querySelector('#main header');
                let currentOpen = '';
                if (mainHeader) {{
                    const sp = mainHeader.querySelector('span[title], span[dir="auto"]');
                    if (sp) currentOpen = (sp.getAttribute('title') || sp.innerText || '').toLowerCase().trim();
                }}
                if (desired && desired !== '__open__' && currentOpen !== desired) {{
                    const spans = Array.from(document.querySelectorAll('#pane-side span[title], #pane-side span[dir="auto"]'));
                    const match = spans.find(s => (s.getAttribute('title') || s.innerText || '').toLowerCase().trim() === desired)
                               || spans.find(s => (s.getAttribute('title') || s.innerText || '').toLowerCase().includes(desired));
                    if (match) {{
                        const row = match.closest('[role="listitem"]') || match.closest('[data-testid="cell-frame-container"]') || match;
                        row.click();
                        return 'SWITCHED_CHAT';
                    }}
                    return 'NEED_PHONE_FALLBACK';
                }}
                const box = document.querySelector('#main footer div[contenteditable="true"]')
                         || document.querySelector('div[contenteditable="true"][data-tab="10"]');
                return box ? 'READY_OPEN' : 'NO_OPEN_CHAT';
            }})()
            """
            chk = cdp.send_command("Runtime.evaluate", {"expression": ensure_chat_js, "returnByValue": True})
            chk_state = chk.get("result", {}).get("result", {}).get("value", "")

            if chk_state == "SWITCHED_CHAT":
                time.sleep(0.6)
            elif chk_state in ("NEED_PHONE_FALLBACK", "NO_OPEN_CHAT"):
                clean_ph = "".join(ch for ch in str(phone or "") if ch.isdigit())
                if len(clean_ph) >= 10:
                    cdp.close()
                    return self.send_real_whatsapp_message(chip_id, clean_ph, msg_clean)
                cdp.close()
                return False, "Selecione uma conversa na lista lateral do monitor antes de responder."

            focus_js = """
            (() => {
                const box = document.querySelector('#main footer div[contenteditable="true"]')
                         || document.querySelector('div[contenteditable="true"][data-tab="10"]');
                if (!box) return false;
                box.focus();
                return true;
            })()
            """
            f_res = cdp.send_command("Runtime.evaluate", {"expression": focus_js, "returnByValue": True})
            if not f_res.get("result", {}).get("result", {}).get("value"):
                cdp.close()
                return False, "Caixa de mensagem nao encontrada na conversa aberta."

            cdp.send_command("Input.insertText", {"text": msg_clean})
            time.sleep(0.25)

            click_send_js = """
            (() => {
                const sendBtn =
                    document.querySelector('span[data-icon="send"]') ||
                    document.querySelector('span[data-icon="wds-ic-send-filled"]') ||
                    document.querySelector('button[aria-label="Enviar"]') ||
                    document.querySelector('button[aria-label="Send"]');
                if (sendBtn) {
                    const clickable = sendBtn.closest('button') || sendBtn;
                    clickable.click();
                    return 'SENT';
                }
                return 'ENTER';
            })()
            """
            s_res = cdp.send_command("Runtime.evaluate", {"expression": click_send_js, "returnByValue": True})
            if s_res.get("result", {}).get("result", {}).get("value") != "SENT":
                cdp.send_command("Input.dispatchKeyEvent", {"type": "keyDown", "windowsVirtualKeyCode": 13, "key": "Enter", "code": "Enter"})
                cdp.send_command("Input.dispatchKeyEvent", {"type": "keyUp", "windowsVirtualKeyCode": 13, "key": "Enter", "code": "Enter"})

            time.sleep(0.35)
            cdp.close()
            return True, "Resposta enviada no WhatsApp em tempo real!"
        except Exception as e:
            return False, str(e)[:70]

