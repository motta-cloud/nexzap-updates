@echo off
chcp 65001 >nul
title NexZap PRO v5.7 - Plataforma Institucional Multi-Chip (Auto-Update Nativo)
color 0A

echo ============================================================================
echo   NEXZAP PRO v5.7 - OPERACAO 100%% INTERNA + AUTO-UPDATE NATIVO + ICONE WIN
echo ============================================================================
echo.

cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [AVISO] Python nao encontrado no PATH desta maquina.
    echo Abrindo pagina oficial do Python 3.11+ para instalacao rapida...
    start https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/5] Registrando Icone Institucional Oficial na Area de Trabalho e Menu Iniciar...
wscript //B "CRIAR_ATALHO_AREA_DE_TRABALHO.vbs" --silent >nul 2>nul

echo [2/5] Encerrando versoes anteriores que possam estar abertas na porta 8090...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8090 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>nul
)

echo [3/5] Verificando banco de dados local e motor de Atualizacao Automatica (OTA)...
if not exist "data" mkdir "data"

echo [4/5] Abrindo Aplicativo NexZap PRO v5.7 com Icone Institucional...
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="http://127.0.0.1:8090/?v=5.7"
) else if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app="http://127.0.0.1:8090/?v=5.7"
) else (
    start "" "http://127.0.0.1:8090/?v=5.7"
)

echo [5/5] Servidor NexZap PRO v5.7 em execucao na porta 8090!
echo ============================================================================
python server.py
pause
