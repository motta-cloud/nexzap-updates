On Error Resume Next
Set oWS = WScript.CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
sCurrentDir = fso.GetParentFolderName(WScript.ScriptFullName)
sIconPath = sCurrentDir & "\public\brand\nexzap_icon.ico, 0"

' 1. Criar Atalho Oficial na Area de Trabalho com o Icone Institucional (.ICO)
sDesktop = oWS.SpecialFolders("Desktop")
sLinkDesktop = sDesktop & "\NexZap PRO.lnk"
Set oLink = oWS.CreateShortcut(sLinkDesktop)
oLink.TargetPath = sCurrentDir & "\INSTALAR_E_ABRIR_NEXZAP.bat"
oLink.WorkingDirectory = sCurrentDir
oLink.Description = "NexZap PRO — Plataforma Institucional Multi-Chip, IA e CRM (Clique com botao direito para Fixar na Barra de Tarefas)"
oLink.IconLocation = sIconPath
oLink.WindowStyle = 7
oLink.Save

' 2. Criar Atalho Oficial no Menu Iniciar do Windows (Permite Fixar na Barra de Tarefas com 1 clique)
sStartMenu = oWS.SpecialFolders("Programs")
sLinkStart = sStartMenu & "\NexZap PRO.lnk"
Set oLink2 = oWS.CreateShortcut(sLinkStart)
oLink2.TargetPath = sCurrentDir & "\INSTALAR_E_ABRIR_NEXZAP.bat"
oLink2.WorkingDirectory = sCurrentDir
oLink2.Description = "NexZap PRO — Plataforma Institucional Multi-Chip"
oLink2.IconLocation = sIconPath
oLink2.WindowStyle = 7
oLink2.Save

If WScript.Arguments.Count = 0 Then
    MsgBox "Atalho Oficial 'NexZap PRO' com Icone Institucional criado na Area de Trabalho e no Menu Iniciar!" & vbCrLf & vbCrLf & "Dica: Clique com o botao direito no icone 'NexZap PRO' e escolha 'Fixar na barra de tarefas'.", 64, "NexZap PRO — Identidade Institucional"
End If
